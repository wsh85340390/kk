package com.yiyongcloud.base.client.account.pojo;


import lombok.*;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserSmartPojo {

    //////////公共属性
    private String id;
    private String pubUidid;
    private String userLoginName;
    private String _username;

    private String userAccount;
    private String userOrg;


    //// 登录成功之后，更新登录信息
    /**
     * 最后登录时间
     */
    private String iamUserlastlogondate;


    /**
     * 是否首次登录  iam_userbusinessextend
     */
    private String iamUserfirstmodpwd;
    /**
     * 最后登录ip  iam_userbusinessextend
     */
    private String iamUserlastloginip;
    /**
     * 用户登录次数  iam_userbusinessextend
     */
    private Integer iamLogincount;

    ////////修改用户密码
    /**
     * 新的密码  pub_user
     * <p>
     * 如果修改了密码，需要调用  checkSpellPwd方法，关联更新--用户的历史密码
     */
    private String userLoginPassword;
    /**
     * 修改时间 ：yyyy-MM-dd HH:mm:ss  iam_userbaseinfoextend
     */
    private String iamModifydate;
    /**
     * 设置用户密码修改日期 yyyy-MM-dd HH:mm:ss   iam_userbusinessextend
     */
    private String iamPasswordmodifieddate;

    //修改临时手机号
    /**
     * 临时手机号 iam_userbaseinfoextend
     */
    private String iamTempTelephone;
    /**
     * 临时手机号 过期 时间  iam_userbaseinfoextend
     */
    private String iamTempTelephoneExpired;

    ////处理密码正确的情况&&处理密码错误的情况
    /**
     * 密码失败次数  iam_userbusinessextend
     */
    private Integer iamUserLoginFailCount;
    /**
     * 用户允许登录时间  iam_userbusinessextend
     */
    private String iamUserAllowLoginDate;


}
