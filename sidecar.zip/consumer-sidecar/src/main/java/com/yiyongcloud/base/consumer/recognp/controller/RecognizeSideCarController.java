package com.yiyongcloud.base.consumer.recognp.controller;


import com.alibaba.fastjson.JSONObject;
import com.yiyongcloud.base.client.psidecar.IRecognPmodeClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;


@RestController
@RequestMapping(value = "/sidecar")
public class RecognizeSideCarController {

    @Autowired
    IRecognPmodeClient iRecognPmodeClient;


    @Autowired
    private RestTemplate restTemplate;


    @RequestMapping(value = "/recogn/{modename}", method = {RequestMethod.POST,RequestMethod.GET})
    public String recognApi(@PathVariable("modename") String modename, @RequestBody String context){
        System.out.println("=======sidecar==modename========="+modename);
        String result= restTemplate.postForObject(Constants.getRecognizeApiUrl(modename),context,
                String.class);
        return result;
    }


    @RequestMapping(value = "/recogn/feign/{modename}", method = {RequestMethod.POST,RequestMethod.GET})
    public String recognApiFeign(@PathVariable("modename") String modename, @RequestBody String context){
        System.out.println("=======sidecar==modename========="+modename);
        String result= iRecognPmodeClient.callRecognizeApi(modename,context);
        return result;
    }

}
