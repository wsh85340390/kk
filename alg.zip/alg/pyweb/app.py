import json
from typing import Optional, Awaitable
import tornado.ioloop
import tornado.web
import nacos


class HealthHandler(tornado.web.RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    def get(self):
        self.write(json.dumps({'status': 'UP'}))


if __name__ == "__main__":
    app = tornado.web.Application([
        (r"/health", HealthHandler),
    ])
    client = nacos.NacosClient("127.0.0.1:8488", namespace="ai-backend", username="nacos", password="nacos")
    app.listen(8099)
    tornado.ioloop.IOLoop.current().start()
