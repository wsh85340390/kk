# 使用说明

### 使用步骤
####本地测试-进入nacos目录下单节点启动Nacos
nacos\bin> ./startup.cmd -m standalone
####启动python服务
python pyweb/app.py
####启动sideCar服务
java -jar server-0.0.1-SNAPSHOT.jar

####发布步骤
* cd pyweb
* docker build -t yiyong/ai-backend .
* docker tag ****.com/yiyong/ai-backend
* docker push ****.com/yiyong/ai-backend

####部署步骤
* docker pull ****.com/yiyong/ai-backend
* docker run -p 8090:8090 -v /app:/app -d ****.com/yiyong/ai-backend
