package com.yiyongcloud.base.client;

public class SystemFeignMain {
    public static void main(String[] args) {

    }
}
