package com.yiyongcloud.base.client;

public class Constant {

    /**
     * 项目模块：算法识别P模型sidecar
     */
    public static final String CLIENT_RECOGN_P_SIDECAR = "recogn-p-sidecar";

    /**
     * 项目模块：算法识别P模型sidecar
     */
    public static final String CLIENT_RECOGN_SIDECAR = "ai-provider";


    public static final String RECOGN_API_URL = "/ai/data/shelldoctor_data_gov/";

    public static String getRecognizeApiUrl(String modeName){
        StringBuilder sb = new StringBuilder().append("http://")
                .append(CLIENT_RECOGN_SIDECAR).append(RECOGN_API_URL).append(modeName);
        return sb.toString();
    }

    /**
     * 项目模块：hospital-manage
     */
    public static final String CLIENT_HOSPITAL_MANAGE = "hospital-manage";
    /**
     * 分布式锁，默认有效期
     */
    public static final Long REDIS_LOCK_EXPIRETIME = 5L;
    /**
     * 项目模块：tag-api
     */
    public static final String CLIENT_TAG_API = "tag-api";
    /**
     * 项目模块：rule-canvas
     */
    public static final String CLIENT_RULE_CANVAS = "rule-canvas";


}
