package com.yiyongcloud.base.client.account.pojo;


import com.yiyongcloud.base.common.entity.BaseEntity;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Description: 主帐号全景视图 组织机构信息实体类<br>
 * Create Date: 2020年02月26日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2018 boco.com.cn All Right Reserved.<br>
 *
 * @author ZhaoWenBin
 * @version 1.0
 */
public class OrgInfoEntity extends BaseEntity {
    /**
     * ID
     */
    @ApiModelProperty(value = "ID")
    private String id;

    /**
     * 组织机构ID
     */
    @ApiModelProperty(value = "组织机构ID")
    private String iamOrgid;

    /**
     * 组织简称
     */
    @ApiModelProperty(value = "组织简称")
    private String iamInitials;

    /**
     * 所属地市
     */
    @ApiModelProperty(value = "所属地市")
    private String iamLocation;

    /**
     * 组织形态
     */
    @ApiModelProperty(value = "组织形态")
    private String iamStyle;

    /**
     * 组织级别
     */
    @ApiModelProperty(value = "组织级别")
    private Integer iamOrglevel;

    /**
     * ERP编码
     */
    @ApiModelProperty(value = "ERP编码")
    private String iamErpid;

    /**
     * 辅负责人
     */
    @ApiModelProperty(value = "辅负责人")
    private String iamVicemanager;

    /**
     * 职能组织
     */
    @ApiModelProperty(value = "职能组织")
    private String iamManageorgid;

    /**
     * 上级领导
     */
    @ApiModelProperty(value = "上级领导")
    private String iamSupervisor;

    /**
     * 管理员
     */
    @ApiModelProperty(value = "管理员")
    private String iamAdmin;

    /**
     * 电话
     */
    @ApiModelProperty(value = "电话")
    private String iamTelephonenumber;

    /**
     * 传真
     */
    @ApiModelProperty(value = "传真")
    private String iamFacsimiletelephonenumber;

    /**
     * 邮政编码
     */
    @ApiModelProperty(value = "邮政编码")
    private String iamPostalcode;

    /**
     * 显示位置
     */
    @ApiModelProperty(value = "显示位置")
    private Integer iamDisplayorder;

    /**
     * 通讯地址
     */
    @ApiModelProperty(value = "通讯地址")
    private String iamPostaladdress;

    /**
     * 描述
     */
    @ApiModelProperty(value = "描述")
    private String iamDescription;

    /**
     * 组织状态
     */
    @ApiModelProperty(value = "组织状态")
    private Integer iamStatus;

    /**
     * 创建日期
     */
    @ApiModelProperty(value = "创建日期")
    private Date iamCreatedate;

    /**
     * 创建者
     */
    @ApiModelProperty(value = "创建者")
    private String iamCreateuserkey;

    /**
     * 修改者
     */
    @ApiModelProperty(value = "修改者")
    private String iamModifyuserkey;

    /**
     * 修改日期
     */
    @ApiModelProperty(value = "修改日期")
    private Date iamModifydate;

    /**
     * 组织编码路径
     */
    @ApiModelProperty(value = "组织编码路径")
    private String iamOrgidpath;

    /**
     * 开始生效时间
     */
    @ApiModelProperty(value = "开始生效时间")
    private Date iamStarttime;

    /**
     * 结束生效时间
     */
    @ApiModelProperty(value = "结束生效时间")
    private Date iamEndtime;

    private String isFlow;
    /**
     * 是否具有权限（0 没有 1有）
     */
    private String isAuditor;

    public String getIsAuditor() {
        return isAuditor;
    }

    public void setIsAuditor(String isAuditor) {
        this.isAuditor = isAuditor;
    }

    public String getIsFlow() {
        return isFlow;
    }

    public void setIsFlow(String isFlow) {
        this.isFlow = isFlow;
    }

    /**
     * IAM_ORGANIZATIONEXTEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID
     *
     * @return ID ID
     */
    public String getId() {
        return id;
    }

    /**
     * ID
     *
     * @param id ID
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 组织机构ID
     *
     * @return IAM_ORGID 组织机构ID
     */
    public String getIamOrgid() {
        return iamOrgid;
    }

    /**
     * 组织机构ID
     *
     * @param iamOrgid 组织机构ID
     */
    public void setIamOrgid(String iamOrgid) {
        this.iamOrgid = iamOrgid;
    }

    /**
     * 组织简称
     *
     * @return IAM_INITIALS 组织简称
     */
    public String getIamInitials() {
        return iamInitials;
    }

    /**
     * 组织简称
     *
     * @param iamInitials 组织简称
     */
    public void setIamInitials(String iamInitials) {
        this.iamInitials = iamInitials;
    }

    /**
     * 所属地市
     *
     * @return IAM_LOCATION 所属地市
     */
    public String getIamLocation() {
        return iamLocation;
    }

    /**
     * 所属地市
     *
     * @param iamLocation 所属地市
     */
    public void setIamLocation(String iamLocation) {
        this.iamLocation = iamLocation;
    }

    /**
     * 组织形态
     *
     * @return IAM_STYLE 组织形态
     */
    public String getIamStyle() {
        return iamStyle;
    }

    /**
     * 组织形态
     *
     * @param iamStyle 组织形态
     */
    public void setIamStyle(String iamStyle) {
        this.iamStyle = iamStyle;
    }

    /**
     * 组织级别
     *
     * @return IAM_ORGLEVEL 组织级别
     */
    public Integer getIamOrglevel() {
        return iamOrglevel;
    }

    /**
     * 组织级别
     *
     * @param iamOrglevel 组织级别
     */
    public void setIamOrglevel(Integer iamOrglevel) {
        this.iamOrglevel = iamOrglevel;
    }

    /**
     * ERP编码
     *
     * @return IAM_ERPID ERP编码
     */
    public String getIamErpid() {
        return iamErpid;
    }

    /**
     * ERP编码
     *
     * @param iamErpid ERP编码
     */
    public void setIamErpid(String iamErpid) {
        this.iamErpid = iamErpid;
    }

    /**
     * 辅负责人
     *
     * @return IAM_VICEMANAGER 辅负责人
     */
    public String getIamVicemanager() {
        return iamVicemanager;
    }

    /**
     * 辅负责人
     *
     * @param iamVicemanager 辅负责人
     */
    public void setIamVicemanager(String iamVicemanager) {
        this.iamVicemanager = iamVicemanager;
    }

    /**
     * 职能组织
     *
     * @return IAM_MANAGEORGID 职能组织
     */
    public String getIamManageorgid() {
        return iamManageorgid;
    }

    /**
     * 职能组织
     *
     * @param iamManageorgid 职能组织
     */
    public void setIamManageorgid(String iamManageorgid) {
        this.iamManageorgid = iamManageorgid;
    }

    /**
     * 上级领导
     *
     * @return IAM_SUPERVISOR 上级领导
     */
    public String getIamSupervisor() {
        return iamSupervisor;
    }

    /**
     * 上级领导
     *
     * @param iamSupervisor 上级领导
     */
    public void setIamSupervisor(String iamSupervisor) {
        this.iamSupervisor = iamSupervisor;
    }

    /**
     * 管理员
     *
     * @return IAM_ADMIN 管理员
     */
    public String getIamAdmin() {
        return iamAdmin;
    }

    /**
     * 管理员
     *
     * @param iamAdmin 管理员
     */
    public void setIamAdmin(String iamAdmin) {
        this.iamAdmin = iamAdmin;
    }

    /**
     * 电话
     *
     * @return IAM_TELEPHONENUMBER 电话
     */
    public String getIamTelephonenumber() {
        return iamTelephonenumber;
    }

    /**
     * 电话
     *
     * @param iamTelephonenumber 电话
     */
    public void setIamTelephonenumber(String iamTelephonenumber) {
        this.iamTelephonenumber = iamTelephonenumber;
    }

    /**
     * 传真
     *
     * @return IAM_FACSIMILETELEPHONENUMBER 传真
     */
    public String getIamFacsimiletelephonenumber() {
        return iamFacsimiletelephonenumber;
    }

    /**
     * 传真
     *
     * @param iamFacsimiletelephonenumber 传真
     */
    public void setIamFacsimiletelephonenumber(String iamFacsimiletelephonenumber) {
        this.iamFacsimiletelephonenumber = iamFacsimiletelephonenumber;
    }

    /**
     * 邮政编码
     *
     * @return IAM_POSTALCODE 邮政编码
     */
    public String getIamPostalcode() {
        return iamPostalcode;
    }

    /**
     * 邮政编码
     *
     * @param iamPostalcode 邮政编码
     */
    public void setIamPostalcode(String iamPostalcode) {
        this.iamPostalcode = iamPostalcode;
    }

    /**
     * 显示位置
     *
     * @return IAM_DISPLAYORDER 显示位置
     */
    public Integer getIamDisplayorder() {
        return iamDisplayorder;
    }

    /**
     * 显示位置
     *
     * @param iamDisplayorder 显示位置
     */
    public void setIamDisplayorder(Integer iamDisplayorder) {
        this.iamDisplayorder = iamDisplayorder;
    }

    /**
     * 通讯地址
     *
     * @return IAM_POSTALADDRESS 通讯地址
     */
    public String getIamPostaladdress() {
        return iamPostaladdress;
    }

    /**
     * 通讯地址
     *
     * @param iamPostaladdress 通讯地址
     */
    public void setIamPostaladdress(String iamPostaladdress) {
        this.iamPostaladdress = iamPostaladdress;
    }

    /**
     * 描述
     *
     * @return IAM_DESCRIPTION 描述
     */
    public String getIamDescription() {
        return iamDescription;
    }

    /**
     * 描述
     *
     * @param iamDescription 描述
     */
    public void setIamDescription(String iamDescription) {
        this.iamDescription = iamDescription;
    }

    /**
     * 组织状态
     *
     * @return IAM_STATUS 组织状态
     */
    public Integer getIamStatus() {
        return iamStatus;
    }

    /**
     * 组织状态
     *
     * @param iamStatus 组织状态
     */
    public void setIamStatus(Integer iamStatus) {
        this.iamStatus = iamStatus;
    }

    /**
     * 创建日期
     *
     * @return IAM_CREATEDATE 创建日期
     */
    public Date getIamCreatedate() {
        return iamCreatedate;
    }

    /**
     * 创建日期
     *
     * @param iamCreatedate 创建日期
     */
    public void setIamCreatedate(Date iamCreatedate) {
        this.iamCreatedate = iamCreatedate;
    }

    /**
     * 创建者
     *
     * @return IAM_CREATEUSERKEY 创建者
     */
    public String getIamCreateuserkey() {
        return iamCreateuserkey;
    }

    /**
     * 创建者
     *
     * @param iamCreateuserkey 创建者
     */
    public void setIamCreateuserkey(String iamCreateuserkey) {
        this.iamCreateuserkey = iamCreateuserkey;
    }

    /**
     * 修改者
     *
     * @return IAM_MODIFYUSERKEY 修改者
     */
    public String getIamModifyuserkey() {
        return iamModifyuserkey;
    }

    /**
     * 修改者
     *
     * @param iamModifyuserkey 修改者
     */
    public void setIamModifyuserkey(String iamModifyuserkey) {
        this.iamModifyuserkey = iamModifyuserkey;
    }

    /**
     * 修改日期
     *
     * @return IAM_MODIFYDATE 修改日期
     */
    public Date getIamModifydate() {
        return iamModifydate;
    }

    /**
     * 修改日期
     *
     * @param iamModifydate 修改日期
     */
    public void setIamModifydate(Date iamModifydate) {
        this.iamModifydate = iamModifydate;
    }

    /**
     * 组织编码路径
     *
     * @return IAM_ORGIDPATH 组织编码路径
     */
    public String getIamOrgidpath() {
        return iamOrgidpath;
    }

    /**
     * 组织编码路径
     *
     * @param iamOrgidpath 组织编码路径
     */
    public void setIamOrgidpath(String iamOrgidpath) {
        this.iamOrgidpath = iamOrgidpath;
    }

    /**
     * 开始生效时间
     *
     * @return IAM_STARTTIME 开始生效时间
     */
    public Date getIamStarttime() {
        return iamStarttime;
    }

    /**
     * 开始生效时间
     *
     * @param iamStarttime 开始生效时间
     */
    public void setIamStarttime(Date iamStarttime) {
        this.iamStarttime = iamStarttime;
    }

    /**
     * 结束生效时间
     *
     * @return IAM_ENDTIME 结束生效时间
     */
    public Date getIamEndtime() {
        return iamEndtime;
    }

    /**
     * 结束生效时间
     *
     * @param iamEndtime 结束生效时间
     */
    public void setIamEndtime(Date iamEndtime) {
        this.iamEndtime = iamEndtime;
    }

    /**
     * 组织机构名称
     */
    @ApiModelProperty(value = "组织机构名称")
    private String orgName;

    /**
     * 上级组织机构ID
     */
    @ApiModelProperty(value = "上级组织机构ID")
    private String parentOrgId;

    /**
     * 安全责任人
     */
    @ApiModelProperty(value = "安全责任人")
    private String dutyUser;

    /**
     * 安全责任人名称
     */
    @ApiModelProperty(value = "安全责任人名称")
    private String dutyUserName;

    /**
     * 是否存在子节点：0无，1有
     */
    @ApiModelProperty(value = "是否存在子节点：0无，1有")
    private String childrootExist;

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getParentOrgId() {
        return parentOrgId;
    }

    public void setParentOrgId(String parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public String getDutyUser() {
        return dutyUser;
    }

    public void setDutyUser(String dutyUser) {
        this.dutyUser = dutyUser;
    }

    public String getDutyUserName() {
        return dutyUserName;
    }

    public void setDutyUserName(String dutyUserName) {
        this.dutyUserName = dutyUserName;
    }

    public String getChildrootExist() {
        return childrootExist;
    }

    public void setChildrootExist(String childrootExist) {
        this.childrootExist = childrootExist;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", iamOrgid=").append(iamOrgid);
        sb.append(", iamInitials=").append(iamInitials);
        sb.append(", iamLocation=").append(iamLocation);
        sb.append(", iamStyle=").append(iamStyle);
        sb.append(", iamOrglevel=").append(iamOrglevel);
        sb.append(", iamErpid=").append(iamErpid);
        sb.append(", iamVicemanager=").append(iamVicemanager);
        sb.append(", iamManageorgid=").append(iamManageorgid);
        sb.append(", iamSupervisor=").append(iamSupervisor);
        sb.append(", iamAdmin=").append(iamAdmin);
        sb.append(", iamTelephonenumber=").append(iamTelephonenumber);
        sb.append(", iamFacsimiletelephonenumber=").append(iamFacsimiletelephonenumber);
        sb.append(", iamPostalcode=").append(iamPostalcode);
        sb.append(", iamDisplayorder=").append(iamDisplayorder);
        sb.append(", iamPostaladdress=").append(iamPostaladdress);
        sb.append(", iamDescription=").append(iamDescription);
        sb.append(", iamStatus=").append(iamStatus);
        sb.append(", iamCreatedate=").append(iamCreatedate);
        sb.append(", iamCreateuserkey=").append(iamCreateuserkey);
        sb.append(", iamModifyuserkey=").append(iamModifyuserkey);
        sb.append(", iamModifydate=").append(iamModifydate);
        sb.append(", iamOrgidpath=").append(iamOrgidpath);
        sb.append(", iamStarttime=").append(iamStarttime);
        sb.append(", iamEndtime=").append(iamEndtime);
        sb.append(", orgName=").append(orgName);
        sb.append(", parentOrgId=").append(parentOrgId);
        sb.append(", dutyUser=").append(dutyUser);
        sb.append(", dutyUser=").append(dutyUserName);
        sb.append(", childrootExist=").append(childrootExist);
        sb.append("]");
        return sb.toString();
    }

    /**
     * 辅负责人名称
     */
    @ApiModelProperty(value = "辅负责人名称")
    private String iamVicemanagerName;

    /**
     * 上级领导名称
     */
    @ApiModelProperty(value = "上级领导名称")
    private String iamSupervisorName;

    /**
     * 管理员名称
     */
    @ApiModelProperty(value = "管理员名称")
    private String iamAdminName;

    public String getIamVicemanagerName() {
        return iamVicemanagerName;
    }

    public void setIamVicemanagerName(String iamVicemanagerName) {
        this.iamVicemanagerName = iamVicemanagerName;
    }

    public String getIamSupervisorName() {
        return iamSupervisorName;
    }

    public void setIamSupervisorName(String iamSupervisorName) {
        this.iamSupervisorName = iamSupervisorName;
    }

    public String getIamAdminName() {
        return iamAdminName;
    }

    public void setIamAdminName(String iamAdminName) {
        this.iamAdminName = iamAdminName;
    }
}