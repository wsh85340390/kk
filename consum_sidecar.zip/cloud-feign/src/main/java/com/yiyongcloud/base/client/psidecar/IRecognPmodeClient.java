package com.yiyongcloud.base.client.psidecar;

import com.alibaba.fastjson.JSONObject;
import com.yiyongcloud.base.client.Constant;
import com.yiyongcloud.base.client.account.pojo.UserBaseInfoExtendEntity;
import com.yiyongcloud.base.client.psidecar.fallback.RecognPmodeClientFallback;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

/**
 * Description: 医院管理客户端<br>
 * Create Date: 2022/02/09<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C)   All Right Reserved.<br>
 *
 * @author tangww
 * @version 1.0
 */

@FeignClient(name = Constant.CLIENT_RECOGN_SIDECAR, fallbackFactory = RecognPmodeClientFallback.class)
public interface IRecognPmodeClient {


    /**
     * Description: 根据登录名查询用户信息
     *
     * @param modeName 模型名称
     * @param context 文本内容
     * @return
     * @author
     * @date 2022/03/02
     */
    @RequestMapping(value = Constant.RECOGN_API_URL+"{modeName}", method = {RequestMethod.GET,RequestMethod.POST})
    public String  callRecognizeApi(@PathVariable("modeName") String modeName,@RequestBody String context);

    /**
     * Description: 根据登录名查询用户信息
     *
     * @param userloginname 登录名
     * @return
     * @author LiuJianli
     * @date 2018/11/5
     */
    @RequestMapping(value = "/apilog/sidecar_tmp/{userloginname}", method = RequestMethod.GET)
    public Map<String,String>  sidecarTmp(@PathVariable("userloginname") String userloginname);



    /**
     * Description: 查询用户列表
     *
     * @param json
     * @return
     * @author XieJinLong
     * @date 2019年8月12日下午2:42:46
     */
    @RequestMapping(value = "/apilog/sidecar", method = RequestMethod.POST)
    Map<String,String>  sidecarJson(@RequestBody JSONObject json);


}
