package com.yiyongcloud.base.client.hostialmanage.feign;

import com.alibaba.fastjson.JSONObject;
import com.yiyongcloud.base.client.Constant;
import com.yiyongcloud.base.client.account.pojo.OrgInfoEntity;
import com.yiyongcloud.base.client.account.pojo.UserBaseInfoExtendEntity;
import com.yiyongcloud.base.client.account.pojo.UserSmartPojo;
import com.yiyongcloud.base.client.hostialmanage.feign.fallback.HospitalManageClientFallback;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

/**
 * Description: 医院管理客户端<br>
 * Create Date: 2022/02/09<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C)   All Right Reserved.<br>
 *
 * @author tangww
 * @version 1.0
 */

@FeignClient(name = Constant.CLIENT_HOSPITAL_MANAGE, fallbackFactory = HospitalManageClientFallback.class)
public interface IHosptailManageClient {

    /**
     * Description: 根据登录名查询用户信息
     *
     * @param userloginname 登录名
     * @return
     * @author LiuJianli
     * @date 2018/11/5
     */
    @RequestMapping(value = "/users/findSubUsersByUserkey/{userloginname}", method = RequestMethod.POST)
    public Map findSubUsersByUserkey(@PathVariable("userloginname") String userloginname);


    /**
     * Description: 根据用户id查询用户绑定策略信息<br>
     * Created date: 2018年12月11日
     *
     * @param json
     * @return
     * @author HuoYaochao
     */
    @RequestMapping(value = "/users/findPolicyByUserId", method = RequestMethod.POST)
    public Map<String, Object> findPolicyByUserId(@PathVariable("json") String json);


    /**
     * Description: 查询用户列表
     *
     * @param json
     * @return
     * @author XieJinLong
     * @date 2019年8月12日下午2:42:46
     */
    @RequestMapping(value = "/hmgApi/hospital/selAllHospital", method = RequestMethod.POST)
    List<UserBaseInfoExtendEntity> selAllHospital(@RequestBody JSONObject json);


    /**
     * Description: 查询当前主账号列表<br>
     * Created date: 2019年4月10日下午3:37:45
     *
     * @param entity
     * @return
     * @author XieJinLong
     */
    @RequestMapping(value = "/users/list", method = RequestMethod.POST)
    public List<UserBaseInfoExtendEntity> queryAccountBySub(@RequestBody
                                                                          UserBaseInfoExtendEntity entity);

}
