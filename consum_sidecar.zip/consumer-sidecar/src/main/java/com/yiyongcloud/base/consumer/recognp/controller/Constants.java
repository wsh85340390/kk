package com.yiyongcloud.base.consumer.recognp.controller;

public class Constants {

    /**
     * 项目模块：算法识别P模型sidecar
     */
    public static final String CLIENT_RECOGN_SIDECAR = "ai-provider";


    public static final String RECOGN_API_URL = "/ai/data/shelldoctor_data_gov/";

    public static String getRecognizeApiUrl(String modeName){
        StringBuilder sb = new StringBuilder().append("http://")
                .append(CLIENT_RECOGN_SIDECAR).append(RECOGN_API_URL).append(modeName);
        return sb.toString();
    }
}
