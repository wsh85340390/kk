package com.yiyong.ai.alg.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author LiJian
 */
@SpringBootApplication
public class AlgApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlgApplication.class, args);
    }

}
