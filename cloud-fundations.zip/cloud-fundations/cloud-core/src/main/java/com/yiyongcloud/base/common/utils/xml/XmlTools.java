package com.yiyongcloud.base.common.utils.xml;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import com.yiyongcloud.base.common.Constants;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.springframework.util.StringUtils;


/**
 * Description:XML操作工具类
 * Copyright (C) 2014 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2014年12月3日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class XmlTools {

    /**
     * 默认编码格式
     */
    private String defaultCharset = Constants.CHARSET_UTF8;

    /**
     * Document对象
     */
    private Document doc;

    /**
     * 根节点
     */
    private Element rootEle;

    /**
     * Definition:获取XML根节点
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public Element getRootEle() {
        return rootEle;
    }

    /**
     * Description :构造方法，实例化XmlTools对象，初始化Document对象，构造根节点
     *
     * @param charset  字符编码
     * @param rootName 根节点名
     */
    private XmlTools(String charset, String rootName) {
        if (!StringUtils.isEmpty(charset)) {
            defaultCharset = charset;
        }
        doc = DocumentHelper.createDocument();
        rootEle = doc.addElement(rootName);
    }


    /**
     * Definition: 初始化构造XML工具
     *
     * @param charset  字符编码
     * @param rootName 根节点名
     * @return XmlTools实例
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static XmlTools initCreateTools(String charset, String rootName) {
        return new XmlTools(charset, rootName);
    }

    /**
     * Definition:获得格式化对象
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    private OutputFormat getFormater() {
        OutputFormat format = OutputFormat.createPrettyPrint();
        format.setEncoding(defaultCharset);
        return format;
    }

    /**
     * Definition:生成XML字符串
     *
     * @return XML字符串
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public String buildXmlString() {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            XMLWriter writer = new XMLWriter(bos, getFormater());
            writer.write(doc);
            writer.close();
            return new String(bos.toByteArray(), defaultCharset);
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Definition: 生成XML文件
     *
     * @param file 要生成的文件对象
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public boolean buildXmlFile(File file) {
        try {
            XMLWriter writer = new XMLWriter(new FileWriter(file), getFormater());
            writer.write(doc);
            writer.close();
            return true;
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Description : 构造方法，实例化XmlTools对象，初始化Document对象，读取根节点
     *
     * @param xml
     */
    private XmlTools(String xml) {
        SAXReader saxReader = new SAXReader();
        try {
            doc = saxReader.read(new StringReader(xml.trim()));
            rootEle = doc.getRootElement();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    /**
     * Definition: 初始化解析XML工具
     *
     * @param xml 要解析的XML
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static XmlTools initParseTools(String xml) {
        return new XmlTools(xml);
    }
}

	