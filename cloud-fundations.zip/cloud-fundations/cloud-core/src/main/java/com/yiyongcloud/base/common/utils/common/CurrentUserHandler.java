package com.yiyongcloud.base.common.utils.common;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yiyongcloud.base.common.pojo.PubUserPOJO;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import com.yiyongcloud.base.common.utils.common.JWTUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * 当前用户信息获取类，暂时放core包
 *
 * @author tangww
 * @since 2021/4/17 16:08
 */
@Slf4j
@Component
public class CurrentUserHandler {
    public static final String AUTHORIZATION = "Authorization";
    public static final String JWT_FLAG = "Bearer ";

    /**
     * 获取当前请求的用户信息
     * 经过网关时，直接调用 即可
     *
     * @return
     */
    public PubUserPOJO getCurrentUser() {
        HttpServletRequest httpServletRequest = getRequest();
        try {
            String token = findToken(httpServletRequest);
            Claims claims = JWTUtils.parse(token);
            JSONObject obj = JSON.parseObject(claims.getSubject());
            //这里不应当从redis拿token，jwt就是为了不在服务端存token。没有存的必要
            PubUserPOJO pubUserPOJO = PubUserPOJO.builder().id(obj.getLong("id"))
                    .userLoginName(obj.getString("uid")).userName(obj.getString("userCnName"))
                    .tenantIndex(obj.getString("tenantIndex")).clientIP(obj.getString("clientIP"))
                    .build();
            return pubUserPOJO;
        } catch (Exception e) {
            log.error("获取当前用户信息失败：{}", e.getMessage());
        }
        return null;
    }

    /**
     * 获取token的值
     *
     * @param exchange
     * @return
     */
    private String findToken(HttpServletRequest exchange) {
        try {
            String token = null;
            if (exchange.getMethod().equalsIgnoreCase(HttpMethod.GET.name())) {
                token = exchange.getParameter(AUTHORIZATION);
            } else {
                token = exchange.getHeader(AUTHORIZATION).substring(JWT_FLAG.length());
            }
            return token;
        } catch (Exception e) {
            log.error("获取token失败{}", e.getMessage());
            return null;
        }
    }

    private static HttpServletRequest getRequest() {
        if (RequestContextHolder.getRequestAttributes() != null) {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                    .getRequest();
            return request;
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        Claims claims = JWTUtils.parse("eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIyOWUzZmViZS1kYjUwLTRiYzQtYmZmZi05NWUwNGE3MTE4NzkiLCJpYXQiOjE2Mjg2NTI3NzUsImlzcyI6ImJvY28tc2VjdXJpdHkiLCJzdWIiOiJ7XCJjbGllbnRJUFwiOlwiMTAuMzIuMy4zXCIsXCJmdW5jdGlvblBPSk9MaXN0XCI6W10sXCJpZFwiOjM5MjEzODIxNDQ5MDYwNjcyLFwicmVUb2tlblwiOlwiXCIsXCJyZWRpcmVjdFwiOlwiXCIsXCJydEtleVwiOlwiNzNhMmVmMWQ0NGU1MmFlZDRkZGU1NDJmZmFmNzY3ZTA1NzMyZTg4M2MwMjA4MWFhMTJlYzZmNTMwNzEwYjcwOGZjYTUwOWI2MGFmZDQ3ZTY4ZDYxZWI0YzFhNTBlM2RhXCIsXCJ0ZW5hbnRJbmRleFwiOlwiMTAwMFwiLFwidG9rZW5cIjpcIlwiLFwidWlkXCI6XCJ0b25namllXCIsXCJ1c2VyQ25OYW1lXCI6XCLnq6XmnbBcIn0iLCJleHAiOjE2Mjg2NTMwNzV9.mi_WU7NcAOjPOGMrID6K-nXQzMhiPwdB-raeu85r1qo");
        System.out.println(claims.toString());
        JSONObject obj = JSON.parseObject(claims.getSubject());
        System.out.println(obj.toString());
    }
}