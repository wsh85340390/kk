package com.yiyongcloud.base.common.utils.cache;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/**
 * Description:缓存处理类
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2021年5月19日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class CacheHandler {

    /**
     * 定时器
     */
    public static ScheduledExecutorService timer = new ScheduledThreadPoolExecutor(5);
}
