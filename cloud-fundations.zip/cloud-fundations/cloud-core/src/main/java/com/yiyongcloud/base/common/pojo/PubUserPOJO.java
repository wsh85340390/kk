package com.yiyongcloud.base.common.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Description: 用户管理POJO
 * Create Date: 2021-04-14
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 *
 * @author
 * @version 1.0
 */

@Data
@SuperBuilder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PubUserPOJO extends BasePOJO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 租户唯一索引
     */
    private String tenantIndex;

    /**
     * 人员姓名
     */
    private String userName;

    /**
     * 登录账号
     */
    private String userLoginName;

    /**
     * 登录密码
     */
    private String userLoginPassword;


    /**
     * 人员类型
     */
    private String userType;

    /**
     * 用户所属的用户组
     */
    private List<String> userGroupList;

    /**
     * 所属组织id
     */
    private String userOrg;

    /**
     * 职位
     */
    private String userPosition;

    /**
     * 电话
     */
    private String userTel;

    /**
     * 邮箱
     */
    private String userMail;

    /**
     * 是否管理员 0普通用户 1管理
     */
    private Double isAdmin;

    /**
     * 登录失败次数
     */
    private Double userLoginFailures;

    /**
     * 允许登录时间
     */
    private Date allowLoginTime;

    /**
     * 是否审计管理员 0普通用户 1管理
     */
    private Double superAuditFlag;


    /**
     * jwt 的token
     * 仅用于返回给前端，jwt 的token 有效性只有 5分钟，不需要更新缓存
     */
    private String token;

    /**
     * 刷新token
     */
    private String reToken;

    /**
     * clientIp客户端
     */
    private String clientIP;
    /**
     * 非超级用户的角色json对象
     */
    private String roleJson;
}
