package com.yiyongcloud.base.common.utils.common;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description: 反射工具类<br>
 * Create Date: 2017年12月4日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class ReflectHelper {

    /**
     * Definition:获取obj对象fieldName的Field
     *
     * @param obj
     * @param fieldName
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月8日
     */
    public static Field getFieldByFieldName(Object obj, String fieldName) {
        for (Class<?> superClass = obj.getClass(); superClass != Object.class; superClass = superClass
                .getSuperclass()) {
            try {
                return superClass.getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
            }
        }
        return null;
    }

    /**
     * Definition:获取obj对象fieldName的属性值
     *
     * @param obj
     * @param fieldName
     * @return
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     * @Author: Tangwenwu
     * @Created date: 2014年12月8日
     */
    public static Object getValueByFieldName(Object obj, String fieldName)
            throws SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        Field field = getFieldByFieldName(obj, fieldName);
        Object value = null;
        if (field != null) {
            if (field.isAccessible()) {
                value = field.get(obj);
            } else {
                field.setAccessible(true);
                value = field.get(obj);
                field.setAccessible(false);
            }
        }
        return value;
    }

    /**
     * Definition:设置obj对象fieldName的属性值
     *
     * @param obj
     * @param fieldName
     * @param value
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     * @Author: Tangwenwu
     * @Created date: 2014年12月8日
     */
    public static void setValueByFieldName(Object obj, String fieldName,
                                           Object value) throws SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        Field field = obj.getClass().getDeclaredField(fieldName);
        if (field.isAccessible()) {
            field.set(obj, value);
        } else {
            field.setAccessible(true);
            field.set(obj, value);
            field.setAccessible(false);
        }
    }


    /**
     * 获取同一路径下所有子类或接口实现类
     *
     * @param intf
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static List<Class<?>> getAllAssignedClass(Class<?> cls) throws IOException,
            ClassNotFoundException {
        List<Class<?>> classes = new ArrayList<Class<?>>();
        for (Class<?> c : getClasses(cls)) {
            if (cls.isAssignableFrom(c) && !cls.equals(c)) {
                classes.add(c);
            }
        }
        return classes;
    }

    /**
     * 取得当前类路径下的所有类
     *
     * @param cls
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static List<Class<?>> getClasses(Class<?> cls) throws IOException,
            ClassNotFoundException {
        String pk = cls.getPackage().getName();
        String path = pk.replace('.', '/');
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        URL url = classloader.getResource(path);
        return getClasses(new File(url.getFile()), pk);
    }

    /**
     * 迭代查找类
     *
     * @param dir
     * @param pk
     * @return
     * @throws ClassNotFoundException
     */
    private static List<Class<?>> getClasses(File dir, String pk)
            throws ClassNotFoundException {
        List<Class<?>> classes = new ArrayList<Class<?>>();
        if (!dir.exists()) {
            return classes;
        }
        File[] fs = dir.listFiles();
        if (fs != null && fs.length > 0) {
            for (File f : fs) {
                if (f.isDirectory()) {
                    classes.addAll(getClasses(f, pk + "." + f.getName()));
                }
                String name = f.getName();
                if (name.endsWith(".class")) {
                    classes.add(Class.forName(pk + "." + name.substring(0, name.length() - 6)));
                }
            }
        }
        return classes;
    }


    /**
     * Definition:获取本类的调用者<br>适用于纯java工程使用，不适用于web容器启动的工程
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年1月14日
     */
    public static String getFinalCallerClass() {
        StackTraceElement stack[] = Thread.currentThread().getStackTrace();
        StackTraceElement ele = stack[stack.length - 1];
        String className = ele.getClassName();
        if (className.contains("$")) { //存在匿名内部类
            className = className.substring(0, className.indexOf("$"));
        }
        return className;
    }

    /**
     * Definition: 将集合以集合元素内某个字段值进行分组
     *
     * @param groupFieldName 分组属性名称
     * @param fieldType      分组属性类型
     * @param datas          待分组的集合
     * @return
     * @throws Exception
     * @Author: Tangwenwu
     * @Created date: 2016-12-2
     */
    @SuppressWarnings("unchecked")
    public static <T, D> Map<T, List<D>> groupBy(String groupFieldName, Class<T> fieldType, List<D> datas) throws Exception {
        if (datas == null || datas.isEmpty()) {
            return null;
        }
        Map<T, List<D>> map = new HashMap<T, List<D>>();
        for (D d : datas) {
            T key = (T) getValueByFieldName(d, groupFieldName);
            List<D> list = map.get(key);
            if (list == null) {
                list = new ArrayList<D>();
            }
            list.add(d);
            map.put(key, list);
        }
        return map;
    }


}