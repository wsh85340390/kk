package com.yiyongcloud.base.common.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * Description: 多ID 删除 form<br>
 * Create Date: 2021年4月26日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author XieJinLong
 * @version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("多ID删除入参")
public class DeleteByIdsForm extends BaseForm {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "IDS列表不能为空")
    @ApiModelProperty("ID列表")
    private List<Long> ids;
}
