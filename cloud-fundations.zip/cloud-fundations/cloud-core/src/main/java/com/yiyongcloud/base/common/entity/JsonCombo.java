package com.yiyongcloud.base.common.entity;

/**
 * Description:下拉框数据结构
 * Copyright (C) 2014 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2014年12月3日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class JsonCombo extends BaseEntity {

    private static final long serialVersionUID = -1380307231202583399L;

    /**
     * 显示的内容
     */
    private String text;

    /**
     * 实际值
     */
    private String value;

    /**
     * 值的ID
     */
    private String id;

    public JsonCombo() {
    }

    /**
     * Description :实例化JsonComboVo对象
     *
     * @param text  下拉列表显示文本
     * @param value 下拉列表值
     */
    public JsonCombo(String text, String value) {
        this.text = text;
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

	