package com.yiyongcloud.base.common.config;

import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.RSA;
import cn.hutool.crypto.symmetric.AES;
import cn.hutool.crypto.symmetric.SymmetricAlgorithm;

import com.yiyongcloud.base.common.db.encrypt.Encryptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.nio.charset.StandardCharsets;

/**
 * 加解密Aes工具配置类
 *
 * @author
 * @date 2021/1/29
 */
@Configuration
@Slf4j
public class EncryptUtilConfig {

    @Value("${encrypt.aes.key}")
    private String aesKey;

    /**
     * AES对称加密工具实例,
     *
     * @return
     */
    @Bean
    public AES aesSymmetricCrypto() {
        try {
            //先把密钥解密
            String aesKeyStr = Encryptor.decrypt(aesKey);
            byte[] key = SecureUtil.generateKey(SymmetricAlgorithm.AES.getValue(), aesKeyStr.getBytes(StandardCharsets.UTF_8))
                    .getEncoded();
            return new AES(key);
        } catch (Exception e) {
            log.error("系统错误！！！", e);
            throw new IllegalStateException("系统错误！");
        }
    }


    /**
     * 非对称加密实例，用于加密解密前后端交互的非对称密钥数据
     *
     * @return
     */
    @Bean
    @Primary
    public RSA rsaForPassword() {
        String priKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAL2Kt3k3WYZqNEctqkiAcV8aTYm/e8dPkB2ICgaX1en6PZn21JmL49DSF9jzUGdXcRU7r+3QDQ4YJq7gbfGF0QuOTUUha/v3RmrXl5/N0tQ4eDs1nWhDPWKWDoOEA1cP3TitVUfXtQlgN+WB2rdYCzYbVOFL+EKLzkcwjtGHuP43AgMBAAECgYAMFDmCC5F0e/Mt8A6QhUL0VRhI5X+NYZglEaTV67oxqYVgePbufBg+GA12AXeHxm5J9J5PEPmsAsUAUwQeprD+J9efECNacPZhHcsTB+pftKMAsRYyhGRG0qwhJsMhtEzSIzlFE+fDeViaVb6PIwITzv2NMjJVGijll5PGK3V7fQJBAPFJ4npTjoKaoGBNQTOqVSHtFNs1xCuoFoAogCUHav0ivihOlmd2zI4A1591yVU4g0oWttkM4zDQBWA4RE/HBsMCQQDJGSaoyUJ/vvDbX8W7coimRLOKntTBUpg/hVx4b1flVnLLLzDcWOC32nTesT/tmgrNe1O/K0kDhlkTtbpo2Xt9AkEA4T1xd3OsouqpL3yukwY8dnEUeRWVzJMafgRQq0BjdW4LSSEjce4KQb0zi52uliktFepiQfev1Y86lXmw+y/1dQJBAJzV6LiqfhpzKBVvVB8k7D4ARqZNyVAcwnCH6d5juAE8srqUS18OUfQRhCRJyLnd8Z7gGCh38bG2DbK5gHBVbWECQQDM9uUDVq3Nkna6Kb6KbRgOaQecCjg5ZRL0jEFfv0xdKG/2LiMZx/jhvAGvJMHNnrImi46WzCjdjxXqyO9IlBPo";
        String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC9ird5N1mGajRHLapIgHFfGk2Jv3vHT5AdiAoGl9Xp+j2Z9tSZi+PQ0hfY81BnV3EVO6/t0A0OGCau4G3xhdELjk1FIWv790Zq15efzdLUOHg7NZ1oQz1ilg6DhANXD904rVVH17UJYDflgdq3WAs2G1ThS/hCi85HMI7Rh7j+NwIDAQAB";
        RSA rsa = new RSA(priKey, pubKey);
        return rsa;
    }

 /*   public static void main(String[] args) {
        EncryptUtilConfig encryptUtilConfig= new EncryptUtilConfig();
        String enString  = encryptUtilConfig.rsaForPassword().encryptHex("boco2019", KeyType.PublicKey);

        String deString  = encryptUtilConfig.rsaForPassword().decryptStr(enString, KeyType.PrivateKey);
        log.warn("==\n\r{} RSA加密：{}",deString,enString);

    }*/

    public static void main(String[] args) {

        String aesKeyStr = "yycloudhosptailvipkey";
        byte[] key = SecureUtil.generateKey(SymmetricAlgorithm.AES.getValue(), aesKeyStr.getBytes(StandardCharsets.UTF_8))
                .getEncoded();
        //7278c47b6d80f4c8b8f7dc15fac928ede93ff94b6f0e888f4f0f95023e6e67e0
        // System.out.println(decodeSecurityKey("7278c47b6d80f4c8b8f7dc15fac928ede93ff94b6f0e888f4f0f95023e6e67e0"));
        AES aes = new AES(key);
        System.out.println(aes.encryptHex("123456"));
    }

}