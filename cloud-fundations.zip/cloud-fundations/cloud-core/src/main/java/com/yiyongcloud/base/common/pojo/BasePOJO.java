package com.yiyongcloud.base.common.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;


/**
 * Description: 公共基本 POJO
 * Create Date: 2021-04-14
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 *
 * @author ：tangwenwu
 * @version 1.0
 */
@SuperBuilder
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BasePOJO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 需要缓存的reids key 值，
     * 如果 redisKey 不为空，则服务方进行缓存，默认缓存 10 分钟
     * 如果 redisKey 为空，则服务方不进行缓存
     */
    private String redisKey;

    /**
     * 缓存过期时间长度，默认 10
     */
    private Long expired;

    /**
     * 缓存过期时间单位，默认 分钟
     */
    private TimeUnit timeUnit;


    public boolean needRedisCache() {
        return StringUtils.isNotBlank(this.redisKey);
    }


}
