package com.yiyongcloud.base.common.pojo;

/**
 * json响应结果包装类
 *
 * @author tangww
 */
public class ResponseResult<T> {
    private boolean success;
    private String code = "0";
    private String msg;
    private T data;
    private long count = 0L;

    public ResponseResult() {
    }

    /**
     * @param data 数据实体
     * @return
     */
    public ResponseResult<T> ofSuccess(T data) {
        return this.setSuccess(true).setMsg("成功").setData(data);
    }


    /**
     * @param data  数据，集合类
     * @param total 数据总条数（前端分页计算page）
     * @return
     */
    public ResponseResult<T> ofSuccess(T data, long total) {
        return this.setSuccess(true).setMsg("成功").setData(data).setCount(total);
    }

    /**
     * @param data 数据实体
     * @param msg  消息提示
     * @return
     */
    public ResponseResult<T> ofSuccess(T data, String msg) {
        return this.setSuccess(true).setMsg(msg).setData(data);
    }


    /**
     * @param data  数据实体
     * @param msg   消息提示
     * @param total 前端分页需要的总条数
     * @return
     */
    public ResponseResult<T> ofSuccess(T data, String msg, long total) {
        return this.setSuccess(true).setMsg(msg).setData(data).setCount(total);
    }

    public ResponseResult<T> ofSuccessMsg(String msg) {
        return this.setSuccess(true).setMsg(msg);
    }

    /**
     * 为了兼容以前的int code，后面考虑移除该方法
     *
     * @param code
     * @param msg
     * @return
     */
    @Deprecated
    public ResponseResult<T> ofFail(int code, String msg) {
        this.setSuccess(false);
        this.setCode(code);
        this.setMsg(msg);
        return this;
    }

    public ResponseResult<T> ofFail(String code, String msg) {
        this.setSuccess(false);
        this.setCode(code);
        this.setMsg(msg);
        return this;
    }

    public ResponseResult<T> ofThrowable(String code, Throwable throwable) {
        this.setSuccess(false);
        this.setCode(code);
        this.setMsg(throwable.getClass().getName() + ", " + throwable.getMessage());
        return this;
    }

    /**
     * 为了兼容以前的int code，后面考虑移除该方法
     *
     * @param code
     * @param throwable
     * @return
     */
    @Deprecated
    public ResponseResult<T> ofThrowable(int code, Throwable throwable) {
        this.setSuccess(false);
        this.setCode(code);
        this.setMsg(throwable.getClass().getName() + ", " + throwable.getMessage());
        return this;
    }

    public boolean isSuccess() {
        return this.success;
    }

    public ResponseResult<T> setSuccess(boolean success) {
        this.success = success;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    @Deprecated
    public ResponseResult<T> setCode(int code) {
        this.code = String.valueOf(code);
        return this;
    }

    public ResponseResult<T> setCode(String code) {
        this.code = code;
        return this;
    }

    public String getMsg() {
        return this.msg;
    }

    public ResponseResult<T> setMsg(String msg) {
        this.msg = msg;
        return this;
    }

    public T getData() {
        return this.data;
    }

    public ResponseResult<T> setData(T data) {
        this.data = data;
        return this;
    }

    public ResponseResult<T> setCount(long count) {
        this.count = count;
        return this;
    }

    public long getCount() {
        return this.count;
    }

    @Override
    public String toString() {
        return "Result{success=" + this.success + ", code=" + this.code + ", count=" + this.count + ", msg='" + this.msg + '\'' + ", data=" + this.data + '}';
    }
}