package com.yiyongcloud.base.common.config;

import com.baomidou.mybatisplus.core.incrementer.IdentifierGenerator;

import com.yiyongcloud.base.common.utils.common.SnowFlake;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 主键自动生成配置类，适用于mybatisplus。mybatisplus会拦截，调用nextId自动注入到id字段
 * 如果entity设置了id字段到值，那设置到值不会被该nextId方法覆盖。
 *
 * @author
 * @date 2021/2/26
 */
@Slf4j
@Component
public class MybatisPlusCustomIdGenerator implements IdentifierGenerator {

    @Autowired
    private SnowFlake snowFlakeIdGenerator;

    /**
     * 全局自增的分布式Id
     *
     * @param entity
     * @return
     */
    @Override
    public Long nextId(Object entity) {
        return snowFlakeIdGenerator.nextId();
    }
}
