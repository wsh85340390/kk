package com.yiyongcloud.base.common.utils.cache;

/**
 * Description:缓存未命中时调用该函数，处理后结果自动放入缓存中
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2021年5月19日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public interface ComputingFunction<K, V> {

    /**
     * Definition:缓存未命中时处理函数
     *
     * @param from 缓存Map的Key
     * @return 对应该Key的Value
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public V apply(K from);

}
