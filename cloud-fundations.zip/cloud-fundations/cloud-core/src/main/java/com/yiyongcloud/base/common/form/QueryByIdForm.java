package com.yiyongcloud.base.common.form;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author
 * @date 2021/3/28
 */
@Data
public class QueryByIdForm extends BaseForm {

    @NotNull(message = "ID不能为空")
    private Long id;
}
