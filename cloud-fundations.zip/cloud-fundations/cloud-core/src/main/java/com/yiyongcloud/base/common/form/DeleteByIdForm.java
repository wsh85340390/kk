package com.yiyongcloud.base.common.form;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @author
 * @date 2021/3/28
 */
@Data
public class DeleteByIdForm extends BaseForm {

    @NotNull(message = "ID不能为空")
    @Min(value = 100000, message = "初始化数据不允许删除")
    private Long id;
}
