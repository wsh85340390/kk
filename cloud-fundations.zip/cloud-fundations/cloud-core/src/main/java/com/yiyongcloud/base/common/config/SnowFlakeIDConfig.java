package com.yiyongcloud.base.common.config;

import com.alibaba.cloud.nacos.NacosDiscoveryProperties;
import com.yiyongcloud.base.common.utils.common.SnowFlake;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Objects;

/**
 * @author
 * @date 2021/1/29
 * 用于计算当前机器的snowflakeid的机器id，并实例化它。
 * 如果配置了app.snowflake.machine.id: 就以该配置为准，注意该配置不能在配置中心配置，否则所有服务实例都是同一个机器Id。
 * 如果没配置，那么就以当前服务注入到nacos的ipv4地址的后16位来计算机器id。这样保证各服务在不同机器上的id不同。
 */
@Configuration
@Slf4j
public class SnowFlakeIDConfig {

    @Autowired
    private NacosDiscoveryProperties nacosDiscoveryProperties;

    @Bean
    public SnowFlake createSnowflake(MathineIdConfig mathineIdConfig) {
        if (Objects.isNull(mathineIdConfig.machine)) {
            String ip = nacosDiscoveryProperties.getIp();
            log.info("注册IP：{}", ip);
            String[] ip2 = ip.split("\\.");
            Integer mathineId = (Integer.parseInt(ip2[2]) << 8) + Integer.parseInt(ip2[3]);
            log.info("snowflake machine ip's id:{}", mathineId);
            return new SnowFlake(mathineId.longValue());
        } else {
            log.info("mathineIdConfig.id:{}", mathineIdConfig.machine);
            return new SnowFlake(mathineIdConfig.machine);
        }
    }

    @Configuration
    @Data
    class MathineIdConfig {
        @Value("${app.snowflake.machine.id:#{null}}")
        private Long machine;
    }
}
