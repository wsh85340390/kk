package com.yiyongcloud.base.common.utils.cache;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;


/**
 * Description:基于ConcurrentMap实现的定时缓存Map
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2021年5月19日
 * Modified By： Modified
 * Date： Why & What is modified： Version 1.0
 */
public class StandaloneMapMaker {

    /**
     * 缓存元素超时时间
     */
    private long expirationTime = 0;

    /**
     * 缓存元素超时时间单位
     */
    private TimeUnit expirationUnit = null;

    /**
     * 缓存元素过期移除时的回调函数
     */
    private ExpirationCallback expirationCallback = null;

    /**
     * 初始化缓存长度
     */
    private int initialCapacity = 16;

    /**
     * Definition:设置缓存元素超时时间
     *
     * @param duration 超时时间
     * @param unit     时间单位
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public StandaloneMapMaker expiration(long duration, TimeUnit unit) {
        if (this.expirationTime != 0) {
            throw new IllegalStateException("expiration time of " + this.expirationTime + " ns was already set");
        }
        if (duration <= 0) {
            throw new IllegalArgumentException("invalid duration: " + duration);
        }
        if (unit == null) {
            throw new IllegalArgumentException("invalid TimeUnit: " + unit);
        }
        this.expirationTime = duration;
        this.expirationUnit = unit;
        return this;
    }

    /**
     * Definition:设置缓存元素超时后的回调函数
     *
     * @param expirationCallback
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月26日
     */
    public StandaloneMapMaker expirationCallback(ExpirationCallback expirationCallback) {
        if (this.expirationCallback != null) {
            throw new IllegalArgumentException("expirationCallback was already set");
        }
        if (expirationCallback == null) {
            throw new IllegalArgumentException("invalid expirationCallback: " + expirationCallback);
        }
        this.expirationCallback = expirationCallback;
        return this;
    }

    /**
     * Definition: 设置缓存元素超时时间
     *
     * @param duration           超时时间
     * @param unit               时间单位
     * @param expirationCallback 元素移除时触发的回调函数
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public StandaloneMapMaker expiration(long duration, TimeUnit unit, ExpirationCallback expirationCallback) {
        if (this.expirationTime != 0) {
            throw new IllegalStateException("expiration time of " + this.expirationTime + " ns was already set");
        }
        if (duration <= 0) {
            throw new IllegalArgumentException("invalid duration: " + duration);
        }
        if (unit == null) {
            throw new IllegalArgumentException("invalid TimeUnit: " + unit);
        }
        if (expirationCallback == null) {
            throw new IllegalArgumentException("invalid expirationCallback: " + expirationCallback);
        }
        this.expirationTime = duration;
        this.expirationUnit = unit;
        this.expirationCallback = expirationCallback;
        return this;
    }

    /**
     * Definition:初始化缓存长度
     *
     * @param initialCapacity
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public StandaloneMapMaker initialCapacity(int initialCapacity) {
        if (initialCapacity <= 0) {
            throw new IllegalArgumentException("invalid initialCapacity: " + initialCapacity);
        }
        this.initialCapacity = initialCapacity;
        return this;
    }

    /**
     * Definition:构造缓存Map
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public <K, V> StandaloneMap<K, V> makeMap() {
        return new CustomConcurrentHashMap<K, V>(this);
    }

    /**
     * Definition:构造缓存Map
     *
     * @param computingFunction 当从缓存中get元素为空时进行逻辑处理，并把处理后返回的值放入缓存中
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public <K, V> StandaloneMap<K, V> makeComputingMap(ComputingFunction<? super K, ? extends V> computingFunction) {
        if (computingFunction == null) {
            throw new IllegalArgumentException("invalid computingFunction: " + computingFunction);
        }
        return new CustomConcurrentHashMap<K, V>(this, computingFunction);
    }

    /**
     * Description:扩展ConcurrentHashMap
     * Copyright (C) 2021 1yongcloud.com All Right Reserved.
     * Author：Tangwenwu
     * Create Date: 2021年5月19日
     * Modified By：
     * Modified Date：
     * Why & What is modified：
     * Version 1.0
     */
    public class CustomConcurrentHashMap<K, V> extends ConcurrentHashMap<K, V> implements StandaloneMap<K, V> {

        private static final long serialVersionUID = -7658928898733196374L;

        /**
         * 缓存元素超时时间
         */
        private long expirationTime = 0;

        /**
         * 缓存元素超时时间单位
         */
        private TimeUnit expirationUnit = null;

        /**
         * 缓存元素过期移除时的回调函数
         */
        private ExpirationCallback expirationCallback = null;

        /**
         * 当从缓存中get元素为空时进行的逻辑处理
         */
        private ComputingFunction<? super K, ? extends V> computingFunction = null;

        private ConcurrentMap<K, V> map = this;

        private CustomConcurrentHashMap(StandaloneMapMaker maker) {
            super(maker.initialCapacity);
            this.expirationTime = maker.expirationTime;
            this.expirationUnit = maker.expirationUnit;
            this.expirationCallback = maker.expirationCallback;
        }

        private CustomConcurrentHashMap(StandaloneMapMaker maker, ComputingFunction<? super K, ? extends V> computingFunction) {
            super(maker.initialCapacity);
            this.expirationTime = maker.expirationTime;
            this.expirationUnit = maker.expirationUnit;
            this.expirationCallback = maker.expirationCallback;
            this.computingFunction = computingFunction;
        }

        /**
         * Definition:加入超时调度
         *
         * @param duration 超时时间
         * @param unit     时间单位
         * @param key
         * @param value
         * @Author: Tangwenwu
         * @Created date: 2021年5月26日
         */
        private void addExpiration(long duration, TimeUnit unit, final K key, final V value) {
            if (duration <= 0) {
                return;
            }
            CacheHandler.timer.schedule(new Runnable() {
                @Override
                public void run() {
                    if (key != null) {
                        map.remove(key, value);
                        if (expirationCallback != null) {
                            expirationCallback.doAfterExpire(key, value);
                        }
                    }
                }
            }, duration, unit);
        }

        @Override
        public V put(K key, V value, long duration, TimeUnit unit) {
            V v = super.put(key, value);
            if (duration > 0 && unit != null) {
                this.addExpiration(duration, unit, key, value);
            } else {
                this.addExpiration(this.expirationTime, this.expirationUnit, key, value);
            }
            return v;
        }

        @Override
        public V put(K key, V value) {
            V v = super.put(key, value);
            this.addExpiration(this.expirationTime, this.expirationUnit, key, value);
            return v;
        }

        @Override
        public V putIfAbsent(K key, V value) {
            if (!this.containsKey(key)) {
                return this.put(key, value);
            } else {
                return super.get(key);
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        public V get(Object key) {
            V v = super.get(key);
            if (v == null && this.computingFunction != null) {
                v = this.computingFunction.apply((K) key);
                this.put((K) key, v);
            }
            return v;
        }

    }
}
