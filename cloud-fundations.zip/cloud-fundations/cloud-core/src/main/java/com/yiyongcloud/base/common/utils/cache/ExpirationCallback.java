package com.yiyongcloud.base.common.utils.cache;


/**
 * Description:缓存元素过期移除时的回调函数
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2021年5月19日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public interface ExpirationCallback {

    /**
     * Definition:缓存元素过期移除回调函数
     *
     * @param key   移除的key
     * @param value 该key对应的value
     * @Author: Tangwenwu
     * @Created date: 2021年5月19日
     */
    public void doAfterExpire(Object key, Object value);
}
