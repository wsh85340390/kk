package com.yiyongcloud.base.common.utils.cache;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * Description:自定义Map缓存，不支持集群
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2021年5月26日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public interface StandaloneMap<K, V> extends ConcurrentMap<K, V> {

    /**
     * Definition:为每个元素指定不同的超时时间
     *
     * @param key      元素key
     * @param value    元素值
     * @param duration 超时时间
     * @param unit     超时单位
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年5月26日
     */
    public V put(K key, V value, long duration, TimeUnit unit);
}
