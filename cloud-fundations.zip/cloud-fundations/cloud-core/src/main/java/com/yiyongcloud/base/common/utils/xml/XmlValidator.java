package com.yiyongcloud.base.common.utils.xml;

import java.io.File;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

/**
 * Description: 根据XSD验证XML格式工具类
 * Copyright (C) 2015 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2015年4月29日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class XmlValidator {

    /**
     * Description: 通过xsd验证xml<br>
     * Created date: 2018年8月23日
     *
     * @param xsdPath xsd文件路径
     * @param xmlPath xml文件路径
     * @return
     * @throws Exception
     * @author Tangwenwu
     */
    public static boolean validateXml(String xsdPath, String xmlPath) throws Exception {
        return validateXml(new File(xsdPath), new File(xmlPath));
    }

    /**
     * Description: 通过xsd验证xml<br>
     * Created date: 2018年8月23日
     *
     * @param xsdFile xsd文件
     * @param xmlFile xml文件
     * @return
     * @throws Exception
     * @author Tangwenwu
     */
    public static boolean validateXml(File xsdFile, File xmlFile) throws Exception {
        // 建立schema工厂
        SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        // 利用schema工厂，接收验证文档文件对象生成Schema对象
        Schema schema = schemaFactory.newSchema(xsdFile);
        // 通过Schema产生针对于此Schema的验证器，利用schenaFile进行验证
        Validator validator = schema.newValidator();
        // 得到验证的数据源
        Source source = new StreamSource(xmlFile);
        // 开始验证
        validator.validate(source);
        return true;
    }


}
