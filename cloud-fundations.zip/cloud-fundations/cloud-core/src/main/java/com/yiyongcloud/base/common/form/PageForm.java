package com.yiyongcloud.base.common.form;


import com.yiyongcloud.base.common.exception.BusinessException;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.Objects;

/**
 * @author
 */
public class PageForm extends BaseForm {

    @Min(value = 1, message = "页码最小为1")
    private Integer page = 1;

    @Min(value = 0, message = "偏移量最小为0")
    private Integer offset;

    @Max(value = 500, message = "分页大小最大为500")
    private Integer limit = -1;

    public Integer getPage() {
        //page 不为空，就返回page
        if (Objects.nonNull(page)) {
            if (page < 0) {
                throw new BusinessException("页码必须大于0 ");
            }
            return page;
        }
        //兼容offset方式，
        if (Objects.nonNull(offset)) {
            if (offset < 0) {
                throw new BusinessException("偏移量必须大于0 ");
            }
            //计算页码
            page = (offset / limit) + 1;
            return page;
        }
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    /**
     * 审计日志
     *
     * @return
     */
    @Override
    public String auditLogReqParam() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("(");
        if (Objects.nonNull(page)) {
            buffer.append("页码=").append(page).append("，");
        }
        if (Objects.nonNull(limit)) {
            buffer.append("请求条数=").append(limit).append("，");
        }
        buffer.deleteCharAt(buffer.length() - 1);
        buffer.append(")");
        return buffer.toString();
    }

}
