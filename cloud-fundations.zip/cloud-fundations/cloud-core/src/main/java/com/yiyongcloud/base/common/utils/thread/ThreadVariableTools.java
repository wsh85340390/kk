package com.yiyongcloud.base.common.utils.thread;

import java.util.Hashtable;
import java.util.Map;

/**
 * Description: 线程变量工具类<br>
 * Create Date: 2017年11月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class ThreadVariableTools {

    private static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<Map<String, Object>>();

    /**
     * Definition:设置线程变量
     *
     * @param key    变量KEY
     * @param object 变量值
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static void setVariable(String key, Object object) {
        if (object == null) {
            return;
        }
        Map<String, Object> map = threadLocal.get();
        if (map != null) {
            map.put(key, object);
        } else {
            Map<String, Object> initMap = new Hashtable<String, Object>(3);
            initMap.put(key, object);
            threadLocal.set(initMap);
        }
    }

    /**
     * Definition:取出线程变量
     *
     * @param key 变量KEY
     * @return 变量值
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static Object getVariable(String key) {
        Map<String, Object> map = threadLocal.get();
        if (map != null) {
            return map.get(key);
        } else {
            return null;
        }
    }


    public static void removeVariable() {
        threadLocal.remove();
    }
}

