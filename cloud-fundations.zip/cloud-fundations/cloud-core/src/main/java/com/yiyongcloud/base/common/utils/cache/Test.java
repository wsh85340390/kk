package com.yiyongcloud.base.common.utils.cache;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;


public class Test {

    private static void printMap(Map<String, String> map) {
        if (map == null || map.isEmpty()) {
            return;
        }
        for (Iterator<String> it = map.keySet().iterator(); it.hasNext(); ) {
            String key = it.next();
            String value = map.get(key);
            System.out.println(key + "===" + value);
        }
        System.out.println("=====================================");
    }

    public static void test() {
        int TIME = 10; // Map里元素过期时间
        StandaloneMap<String, String> map = new StandaloneMapMaker()
                .expiration(TIME, TimeUnit.SECONDS, new ExpirationCallback() {
                    @Override
                    public void doAfterExpire(Object key, Object value) {
                        System.out.println("remove key " + key + " value " + value);
                    }
                }).makeComputingMap(new ComputingFunction<String, String>() {
                    @Override
                    public String apply(String from) {
                        System.out.println("value of key " + from + " is null, add new value for key, value is " + from);
                        return from;
                    }
                });
        map.put("1", "1");
        map.put("2", "2");
        map.put("3", "3");
        printMap(map);
        try {
            Thread.sleep(4000);
            map.put("4", "4");
            printMap(map);
            Thread.sleep(4000);
            map.put("2", "3");
            printMap(map);
            map.get("5");
            Thread.sleep(4000);
            printMap(map);
            map.get("1");
            Thread.sleep(4000);
            printMap(map);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (!map.isEmpty()) {
        }
    }


    public static void testExpirationForEveryItem() {
        StandaloneMap<String, String> map = new StandaloneMapMaker().expiration(10, TimeUnit.SECONDS)
                .expirationCallback(new ExpirationCallback() {
                    @Override
                    public void doAfterExpire(Object key, Object value) {
                        System.out.println("expiration, key : " + key + ", value : " + value);
                    }
                }).makeMap();
        map.put("1", "1"); //不指定超时时间，使用缓存Map实例时指定的默认超时时间
        map.put("2", "2", 5, TimeUnit.SECONDS); //指定个性化超时时间
        map.put("3", "3");
        map.put("4", "4", 0, null);//如果个性化超时时间参数不合法，使用默认超时时间
        while (!map.isEmpty()) {
        }
    }

}
