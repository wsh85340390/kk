package com.yiyongcloud.base.common.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 上传下载文件属性实体类<br>
 * Create Date: 2018年5月28日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2018 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
@ApiModel(value = "AttachFileEntity", description = "FTP中转文件信息")
public class AttachFileEntity extends BaseEntity {

    private static final long serialVersionUID = -1178507766261644786L;

    /**
     * 文件真实名称
     */
    @ApiModelProperty(value = "文件真实名称")
    private String attachFilename;

    /**
     * 文件存储名称
     */
    @ApiModelProperty(value = "文件存储名称")
    private String attachSaveFilename;

    /**
     * 文件在FTP上的存储路径
     */
    @ApiModelProperty(value = "文件在FTP上的存储路径")
    private String attachSavePath;

    /**
     * 文件大小，单位B
     */
    @ApiModelProperty(value = "文件大小，单位B")
    private Long attachFileSize;

    public String getAttachFilename() {
        return attachFilename;
    }

    public void setAttachFilename(String attachFilename) {
        this.attachFilename = attachFilename;
    }

    public String getAttachSaveFilename() {
        return attachSaveFilename;
    }

    public void setAttachSaveFilename(String attachSaveFilename) {
        this.attachSaveFilename = attachSaveFilename;
    }

    public String getAttachSavePath() {
        return attachSavePath;
    }

    public void setAttachSavePath(String attachSavePath) {
        this.attachSavePath = attachSavePath;
    }

    public Long getAttachFileSize() {
        return attachFileSize;
    }

    public void setAttachFileSize(Long attachFileSize) {
        this.attachFileSize = attachFileSize;
    }


}
