/**
 * @Title: I18NTools.java
 * @Package com.boco.security.base.common.core.config
 * @Description: TODO
 * @author tangwwong
 * @date 2021年4月4日 上午9:18:47
 * @version V1.0
 */
package com.yiyongcloud.base.common.config;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import lombok.extern.slf4j.Slf4j;


/**
 * @author tangwwong
 *
 */

@Configuration
@ConditionalOnProperty(name = "i18n.config-file-name")
@Slf4j
public class I18NTools {

    @Autowired
    private Environment env;

    /**
     * I18N配置内容
     */
    private static Properties i18n;

    /**
     * default message
     */
    private static final String LOCAL_LANGUAGE_NO_MESSAGE = "Without this information for the current language environment";

    /**
     * 是否启动
     */
    private static boolean status = false;

    /**
     * Description: 初始化加载I18N配置<br>
     * Created date: 2017年12月4日
     *
     * @return
     * @author LanChao
     */
    @Bean
    public I18NTools init() {
        String i18nConfigFileName = env.getProperty("i18n.config-file-name");
        //logger.info("====================="+i18nConfigFileName);
        try {
            i18n = PropertiesLoaderUtils.loadAllProperties(i18nConfigFileName);
            status = true;
            log.info("current i18n config is {}", i18nConfigFileName);
            return this;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Description: 根据信息标识取对应的语言的描述<br>
     * Created date: 2017年12月4日
     *
     * @param messageId
     * @return
     * @author LanChao
     */
    public static String getMessage(String messageId) {
        if (status) {
            if ("application_started_msg".equals(messageId)) {
                return "服务启动成功";
            } else {
                return i18n.getProperty(messageId, LOCAL_LANGUAGE_NO_MESSAGE);
            }

        }
        return "i18n environment is not ready!";
    }

}
