package com.yiyongcloud.base.common.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 基础实体类<br>
 * Create Date: 2017年11月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
@JsonNaming(PagingPropertyNamingStrategy.class)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = -9033707907877937177L;

    /**
     * 前台传入的当前操作用户
     */
    @ApiModelProperty(value = "当前操作人账号")
    private String _username;

    /**
     * 分页参数：页大小
     */
    @ApiModelProperty(value = "分页参数：页大小")
    private Integer _limit;

    /**
     * 分页参数：起始条数
     */
    @ApiModelProperty(value = "分页参数：起始条数")
    private Integer _offset;

    public String get_username() {
        return _username;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

    public Integer get_limit() {
        return _limit;
    }

    public void set_limit(Integer _limit) {
        this._limit = _limit;
    }

    public Integer get_offset() {
        return _offset;
    }

    public void set_offset(Integer _offset) {
        this._offset = _offset;
    }


}
