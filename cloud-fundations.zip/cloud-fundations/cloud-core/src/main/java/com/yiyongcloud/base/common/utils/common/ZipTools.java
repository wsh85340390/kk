package com.yiyongcloud.base.common.utils.common;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.yiyongcloud.base.common.Constants;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

/**
 * Description: ZIP压缩包操作工具类<br>
 * Create Date: 2017年12月4日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class ZipTools {

    private static String CHARSET = Constants.CHARSET_GBK;

    /**
     * Definition:将文件集合打ZIP包
     *
     * @param zipOutputPath ZIP输出路径，包含文件名，如/opt/c.zip
     * @param inputFiles    需要打包的文件集合
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean zip(String zipOutputPath, List<File> inputFiles) {
        try {
            if (inputFiles == null || inputFiles.isEmpty()) {
                throw new NullPointerException("no file for add to zip");
            }
            ZipFile zipFile = new ZipFile(zipOutputPath);
            zipFile.setFileNameCharset(CHARSET);
            ArrayList<File> filesToAdd = new ArrayList<File>();
            filesToAdd.addAll(inputFiles);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            zipFile.addFiles(filesToAdd, parameters);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Definition:将文件夹打ZIP包
     *
     * @param zipOutputPath   ZIP输出路径，包含文件名，如/opt/c.zip
     * @param inputFolderPath 需要打包的文件夹
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean zip(String zipOutputPath, String inputFolderPath) {
        try {
            if (inputFolderPath == null || "".equals(inputFolderPath)) {
                throw new NullPointerException("no file for add to zip");
            }
            ZipFile zipFile = new ZipFile(zipOutputPath);
            zipFile.setFileNameCharset(CHARSET);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            zipFile.addFolder(inputFolderPath, parameters);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Definition:将文件集合打ZIP包，并加入压缩密码
     *
     * @param zipOutputPath ZIP输出路径，包含文件名，如/opt/c.zip
     * @param inputFiles    需要打包的文件集合
     * @param password      压缩密码
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean zipWithPwd(String zipOutputPath, List<File> inputFiles, String password) {
        try {
            if (inputFiles == null || inputFiles.isEmpty()) {
                throw new NullPointerException("no file for add to zip");
            }
            ZipFile zipFile = new ZipFile(zipOutputPath);
            zipFile.setFileNameCharset(CHARSET);
            ArrayList<File> filesToAdd = new ArrayList<File>();
            filesToAdd.addAll(inputFiles);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            // 设置密码
            parameters.setEncryptFiles(true);
            parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);
            parameters.setPassword(password);
            zipFile.addFiles(filesToAdd, parameters);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Definition:将文件夹打ZIP包，并加入压缩密码
     *
     * @param zipOutputPath   ZIP输出路径，包含文件名，如/opt/c.zip
     * @param inputFolderPath 需要打包的文件夹
     * @param password        压缩密码
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean zipWithPwd(String zipOutputPath, String inputFolderPath, String password) {
        try {
            if (inputFolderPath == null || "".equals(inputFolderPath)) {
                throw new NullPointerException("no file for add to zip");
            }
            ZipFile zipFile = new ZipFile(zipOutputPath);
            zipFile.setFileNameCharset(CHARSET);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            // 设置密码
            parameters.setEncryptFiles(true);
            parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);
            parameters.setPassword(password);
            zipFile.addFolder(inputFolderPath, parameters);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Definition:解压ZIP文件
     *
     * @param zipFilePath     ZIP压缩包路径，包含文件名，如/opt/c.zip
     * @param outputFilesPath 解压后文件存放的文件夹路径
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean unZip(String zipFilePath, String outputFilesPath) {
        try {
            ZipFile zipFile = new ZipFile(zipFilePath);
            zipFile.setFileNameCharset(CHARSET);
            zipFile.extractAll(outputFilesPath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Definition:解压ZIP文件
     *
     * @param zipFile         ZIP压缩包文件
     * @param outputFilesPath 解压后文件存放的文件夹路径
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean unZip(File zipFile, String outputFilesPath) {
        try {
            ZipFile zipFilea = new ZipFile(zipFile);
            zipFilea.setFileNameCharset(CHARSET);
            zipFilea.extractAll(outputFilesPath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Definition:解压ZIP文件
     *
     * @param zipFilePath     ZIP压缩包路径，包含文件名，如/opt/c.zip
     * @param outputFilesPath 解压后文件存放的文件夹路径
     * @param password        密码
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean unZipWithPwd(String zipFilePath, String outputFilesPath, String password) {
        try {
            ZipFile zipFile = new ZipFile(zipFilePath);
            zipFile.setFileNameCharset(CHARSET);
            if (zipFile.isEncrypted()) {
                zipFile.setPassword(password);
            }
            zipFile.extractAll(outputFilesPath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Definition:解压ZIP文件
     *
     * @param zipFile         ZIP压缩包文件
     * @param outputFilesPath 解压后文件存放的文件夹路径
     * @param password        密码
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static boolean unZipWithPwd(File zipFile, String outputFilesPath, String password) {
        try {
            ZipFile zipFilea = new ZipFile(zipFile);
            zipFilea.setFileNameCharset(CHARSET);
            if (zipFilea.isEncrypted()) {
                zipFilea.setPassword(password);
            }
            zipFilea.extractAll(outputFilesPath);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}

	