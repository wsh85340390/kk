package com.yiyongcloud.base.common.utils.xml;

import com.yiyongcloud.base.common.Constants;
import com.thoughtworks.xstream.XStream;

/**
 * Description:简单格式XML操作工具类
 * 适用于只存在节点，不存在节点属性的XML解析和封装
 * Copyright (C) 2014 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2014年12月3日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class SimpleXmlTools {

    /**
     * 默认编码格式
     */
    private static final String DEFAULT_CHARSET = Constants.CHARSET_UTF8;

    /**
     * XML头部信息
     */
    private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"" + DEFAULT_CHARSET + "\"?>\n";


    /**
     * Definition:根据对象生成对应结构的XML<br>
     * 仅适用于简单的节点类型XML格式，不适用于存在节点属性的XML
     *
     * @param obj      对象
     * @param rootName 根节点名称
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static String makeSimpleXmlFromObject(Object obj, String rootName) {
        XStream xstream = new XStream();
        xstream.alias(rootName, obj.getClass());
        return XML_HEADER + xstream.toXML(obj);
    }

    /**
     * Definition:解析XML，返回填充后的对象<br>
     * 仅适用于简单的节点类型XML格式，不适用于存在节点属性的XML
     *
     * @param xml
     * @param rootName
     * @param clazz
     * @return
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    @SuppressWarnings("unchecked")
    public static <T> T parseSimpleXml(String xml, String rootName, Class<T> clazz) {
        XStream xstream = new XStream();
        xstream.alias(rootName, clazz);
        return (T) xstream.fromXML(xml);
    }

}

	