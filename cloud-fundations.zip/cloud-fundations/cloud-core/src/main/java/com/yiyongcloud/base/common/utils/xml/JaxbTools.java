package com.yiyongcloud.base.common.utils.xml;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * <b>Description: </b>JAXB实现xml和java实体之间的转换工具类<br>
 * <b>ProjectName: </b> cloud-core
 * <br><b>PackageName: </b> com.boco.security.cloud.fundations.utils.xml
 * <br><b>ClassName: </b> JaxbTools
 * <br><b>Date: </b> 2018年12月20日 上午8:49:04
 *
 * @author tangww
 * @version 0.0.1
 */
@SuppressWarnings("all")
public class JaxbTools {
    /**
     * <b>Description: </b>测试样例<br>
     *
     * @param args
     * @For_Example: <?xml version="1.0" encoding="UTF-8"?>
     * <key name="teacher" value="jhon">
     * <sub_node1 age="19" name="student1"/>
     * <sub_node2 age="18" name="student2">我是一个节点下的value</sub_node2>
     * <sub_node2 age="18" name="student2">我是一个节点下的value</sub_node2>
     * </key>
     */
    public static void main(String[] args) {
        DemoSub sub1 = new DemoSub();
        sub1.setAge(19);
        sub1.setName("student1");
        List<DemoSub> sub2List = new ArrayList<DemoSub>();
        DemoSub sub2 = new DemoSub();
        sub2.setAge(18);
        sub2.setName("student2");
        sub2.setValue("我是一个节点下的value");
        sub2List.add(sub2);
        sub2List.add(sub2);
        DemoRoot root = new DemoRoot();
        root.setDemoSub(sub1);
        root.setDemoSubList(sub2List);
        root.setName("teacher");
        root.setValue("jhon");
        //一行输出样例
        //String xml1 = javaToXmlDefault(root);
        String xml1 = javaToXml(root);
        //格式化输出样例
        String xml2 = javaToXml(root, "UTF-8", true);
        System.out.println(xml1);
        System.out.println(xml2);
        try {
            /*
             * 反向解析
             */
            DemoRoot returnRoot = xmlToJava(xml1, DemoRoot.class);
            System.out.println(returnRoot.getName());
            System.out.println(returnRoot.getValue());
            System.out.println(returnRoot.getDemoSub().getName());
            System.out.println(returnRoot.getDemoSubList().get(0).getName());
            System.out.println(returnRoot.getDemoSubList().get(0).getValue());
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    /**
     * The name of the property used to specify the xsi:schemaLocation attribute
     * value to place in the marshalled XML output.
     */
    protected static final String JAXB_SCHEMA_LOCATION = "jaxb.schemaLocation";
    /**
     * 设置字符编码
     */
    protected static final String JAXB_ENCODING = "jaxb.encoding";
    /**
     * 是否格式化输出
     */
    protected static final String JAXB_FORMATTED_OUTPUT = "jaxb.formatted.output";
    /**
     * 修改命名空间
     */
    protected static final String JAXB_NO_NAMESPACE_SCHEMA_LOCATION = "jaxb.noNamespaceSchemaLocation";
    /**
     * 是否生成<?xml version="1.0" encoding="utf-8" standalone="yes"?>
     */
    protected static final String JAXB_FRAGMENT = "jaxb.fragment";
    /**
     * replace = <?xml version=\"1.0\" encoding=\"UTF-8\"?>
     */
    private static final String HEADER_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

    /**
     * <b>Description: </b> java对象转换成xml字符串, jaxb默认方式
     *
     * @param arg0 被转换的java实体
     * @return
     * @throws UnsupportedEncodingException
     * @throws JAXBException
     */
    @Deprecated
    private static <T> String javaToXmlDefault(T arg0) throws UnsupportedEncodingException, JAXBException {
        return new String(javaToBtye(arg0), "utf-8");
    }

    /**
     * <b>Description: </b> 推荐使用, java对象转换成xml字符串, 默认返回一行数据
     *
     * @param arg0 被转换的java实体
     * @param arg1 被转换的java实体类型
     * @return
     */
    public static String javaToXml(Object arg0, Class... arg1) {
        return javaToXml(arg0, null, false, true, arg1);
    }

    /**
     * <b>Description: </b> java对象转换成xml字符串
     *
     * @param arg0 java bean的集合
     * @param arg1 字符编码
     * @param arg2 是否格式化
     * @param arg3 其它子节点的类型
     * @return String
     */
    public static String javaToXml(Object arg0, String arg1, boolean arg2, Class... arg3) {
        return javaToXml(arg0, arg1, arg2, true, arg3);
    }

    /**
     * <b>Description: </b> java对象转换成xml字符串, 返回Base64加密字符串
     *
     * @param arg0 被转换的java实体
     * @param arg1 被转换的java实体类型
     * @return
     */
    public static String javaToXmlBase64(Object arg0, Class... arg1) {
        return encode(javaToXml(arg0, null, false, true, arg1));
    }

    /**
     * <b>Description: </b> java对象转换成xml字符串, 返回Base64加密字符串
     *
     * @param arg0 被转换的java实体
     * @param arg1 生成xml的字符编码
     * @param arg2 是否格式化
     * @param arg3 被转换的java实体类型
     * @return
     */
    public static String javaToXmlBase64(Object arg0, String arg1, boolean arg2, Class... arg3) {
        return encode(javaToXml(arg0, arg1, arg2, true, arg3));
    }

    /**
     * <b>Description: </b>通过包含javabean的集合获得xml报文并加密<br>
     *
     * @param arg0 java实例
     * @param arg1 字符编码(默认系统编码)
     * @param arg2 是否格式化(默认否)
     * @param arg3 是否隐藏jaxb自动生成的xml头部, 包含了standalone=yes字符
     * @param arg4 指定使用的转换类型(优先使用指定类型实例化, 只有当没配置类型(arg4)时, 才默认使用实例(arg0)获取class)
     * @return
     */
    private static String javaToXml(Object arg0, String arg1, boolean arg2, boolean arg3, Class... arg4) {
        try {
            if (arg0 == null) {
                throw new NullPointerException("实例不能为空");
            }
            final String header;
            JAXBContext context = null;
            //优先使用指定类型实例化
            if (arg4 != null && arg4.length != 0) {
                context = JAXBContext.newInstance(arg4);
            } else {
                //只有当没配置类型(arg4)时, 才默认使用实例(arg0)获取class
                context = JAXBContext.newInstance(arg0.getClass());
            }
            Marshaller marshaller = context.createMarshaller();
            if (arg1 != null && !"".equals(arg1)) {
                marshaller.setProperty(JAXB_ENCODING, arg1);
            }
            if (arg2) {
                marshaller.setProperty(JAXB_FORMATTED_OUTPUT, arg2);
            }
            marshaller.setProperty(JAXB_FRAGMENT, arg3);
            if (arg3) {
                if (arg2) {
                    header = HEADER_XML + "\n";
                } else {
                    header = HEADER_XML;
                }
            } else {
                header = "";
            }
            StringWriter writer = new StringWriter();
            marshaller.marshal(arg0, writer);
            return header + writer.toString();
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * <b>Description: </b> xml字符串转化为java实体
     *
     * @param arg0 xml格式字符串
     * @param arg1 生成java实体的类型
     * @return
     * @throws JAXBException
     */
    public static <T> T xmlToJava(String arg0, Class<T> arg1) throws JAXBException {
        return xmlToJava(arg0, arg1, null);
    }

    /**
     * <b>Description: </b> xml字符串转化为java实体
     *
     * @param arg0 xml格式字符串
     * @param arg1 生成java实体的类型(多个)
     * @return
     * @throws JAXBException
     */
    public static <T> T xmlToJava(String arg0, Class<T>... arg1) throws JAXBException {
        return xmlToJava(arg0, null, arg1);
    }

    /**
     * <b>Description: </b> xml字符串转化为java实体
     *
     * @param arg0 xml格式字符串
     * @param arg1 生成java实体的类型
     * @param arg2 生成java实体的类型(多个)
     * @return
     * @throws JAXBException
     */
    public static <T> T xmlToJava(String arg0, Class<T> arg1, Class... arg2) throws JAXBException {
        JAXBContext context = null;
        if (arg2 == null || arg2.length == 0) {
            context = JAXBContext.newInstance(arg1);
        } else {
            context = JAXBContext.newInstance(arg2);
        }
        Unmarshaller unmarshaller = context.createUnmarshaller();
        T t = (T) unmarshaller.unmarshal(new StringReader(arg0));
        return t;
    }

    /**
     * <b>Description: </b>生成xml文件的二进制数据<br>
     *
     * @param arg0 java实体
     * @return
     * @throws JAXBException
     */
    private static <T> byte[] javaToBtye(T arg0) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(arg0.getClass());
        Marshaller m = context.createMarshaller();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        m.setProperty(JAXB_FORMATTED_OUTPUT, Boolean.FALSE);
        m.marshal(arg0, outputStream);
        byte[] returns = outputStream.toByteArray();
        try {
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return returns;
    }

    /**
     * <b>Description: </b>xml字节数组转换成java实体<br>
     *
     * @param arg0 xml的字节数组
     * @param arg1 生成的java实体类型
     * @return
     * @throws JAXBException
     */
    public static <T> T xmlToJava(byte[] arg0, Class<T> arg1) throws JAXBException {
        return unmarshal(arg0, arg1);
    }

    /**
     * <b>Description: </b>xml字节数组转换成java实体<br>
     *
     * @param arg0 xml的字节数组
     * @param arg1 生成的java实体类型
     * @return
     * @throws JAXBException
     */
    private static <T> T unmarshal(byte[] arg0, Class<T> arg1) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(arg1);
        Unmarshaller m = context.createUnmarshaller();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(arg0);
        T t = (T) m.unmarshal(inputStream);
        return t;
    }

    /**
     * <b>Description: </b> Base64加密
     *
     * @param str
     * @return
     */
    public static String encode(String str) {
        try {
            if (str == null || "".equals(str)) {
                return null;
            }
            return (new BASE64Encoder()).encode(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * <b>Description: </b> Base64解密
     *
     * @param str
     * @return
     */
    public static String decode(String str) {
        if (str == null || "".equals(str)) {
            return null;
        }
        try {
            String s = new String(new BASE64Decoder().decodeBuffer(str), "UTF-8");
            return s;
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return null;
    }
}

/**
 * <b>Description: </b>Demo1<br>
 * <b>ProjectName: </b> cloud-core
 * <br><b>PackageName: </b> com.boco.security.cloud.fundations.utils.xml
 * <br><b>ClassName: </b> DemoRoot
 * <br><b>Date: </b> 2018年12月20日 上午10:43:20
 *
 * @author tangww
 * @version 0.0.1
 */
@XmlRootElement(name = "key")
class DemoRoot {
    /**
     * 属性name
     */
    private String name;
    /**
     * 属性value
     */
    private String value;
    /**
     * 属性集合(存在多个子节点的情况使用)
     */
    List<DemoSub> demoSubList;
    /**
     * 属性
     */
    private DemoSub demoSub;

    /**
     * <b>Description: </b>@XmlAttribute指定其为节点的属性, 而不是一个子节点<br>
     *
     * @return
     */
    @XmlAttribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * <b>Description: </b>@XmlAttribute指定其为节点的属性, 而不是一个子节点<br>
     *
     * @return
     */
    @XmlAttribute
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    /**
     * <b>Description: </b>@XmlElement指定其为xml的一个节点, 默认值<br>
     *
     * @return
     */
    @XmlElement(name = "sub_node1")
    public DemoSub getDemoSub() {
        return demoSub;
    }

    public void setDemoSub(DemoSub demoSub) {
        this.demoSub = demoSub;
    }

    /**
     * <b>Description: </b>@XmlElement指定其为xml的一个节点, 默认值<br>
     *
     * @return
     */
    @XmlElement(name = "sub_node2")
    public List<DemoSub> getDemoSubList() {
        return demoSubList;
    }

    public void setDemoSubList(List<DemoSub> demoSubList) {
        this.demoSubList = demoSubList;
    }
}

/**
 * <b>Description: </b>Demo2<br>
 * <b>ProjectName: </b> cloud-core
 * <br><b>PackageName: </b> com.boco.security.cloud.fundations.utils.xml
 * <br><b>ClassName: </b> DemoSub
 * <br><b>Date: </b> 2018年12月20日 上午10:43:08
 *
 * @author tangww
 * @version 0.0.1
 */
class DemoSub {
    /**
     * name
     */
    private String name;
    /**
     * age
     */
    private int age;
    /**
     * value
     */
    private String value;

    /**
     * <b>Description: </b>@XmlAttribute指定其为节点的属性, 而不是一个子节点<br>
     *
     * @return
     */
    @XmlAttribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * <b>Description: </b>@XmlAttribute指定其为节点的属性, 而不是一个子节点<br>
     *
     * @return
     */
    @XmlAttribute
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    /**
     * <b>Description: </b>@XmlValue和XmlEliment不能并存, 并且@XmlValue在一个实体中中只能存在一个<br>
     *
     * @return
     */
    @XmlValue
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
