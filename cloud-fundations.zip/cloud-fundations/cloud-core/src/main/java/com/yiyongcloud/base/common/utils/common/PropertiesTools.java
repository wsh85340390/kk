package com.yiyongcloud.base.common.utils.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

/**
 * Description:资源文本文件操作类
 * Copyright (C) 2014 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu
 * Create Date: 2014年12月3日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class PropertiesTools {

    /**
     * Definition:将文本配置文件信息读入Map
     *
     * @param filePath 文件路径
     * @return Map
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static Map<String, String> readIntoMap(String filePath) {
        try {
            Properties prop = new Properties();
            prop.load(new FileInputStream(new File(filePath)));
            Map<String, String> map = new HashMap<String, String>();
            Set<Entry<Object, Object>> entrySet = prop.entrySet();
            for (Entry<Object, Object> entry : entrySet) {
                if (!entry.getKey().toString().startsWith("#")) {
                    map.put(((String) entry.getKey()).trim(), ((String) entry.getValue()).trim());
                }
            }
            return map;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Definition:将文本配置文件流信息读入Map
     *
     * @param in 文件流
     * @return Map
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static Map<String, String> readIntoMap(InputStream in) {
        try {
            Properties prop = new Properties();
            prop.load(in);
            Map<String, String> map = new HashMap<String, String>();
            Set<Entry<Object, Object>> entrySet = prop.entrySet();
            for (Entry<Object, Object> entry : entrySet) {
                if (!entry.getKey().toString().startsWith("#")) {
                    map.put(((String) entry.getKey()).trim(), ((String) entry.getValue()).trim());
                }
            }
            return map;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Definition:从文本配置文件内读取某一属性
     *
     * @param filePath 文件路径
     * @param key      属性KEY
     * @return 属性VALUE
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static String readProperValue(String filePath, String key) {
        try {
            Properties prop = new Properties();
            prop.load(new FileInputStream(new File(filePath)));
            return prop.getProperty(key, "");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Definition:从文本配置文件流内读取某一属性
     *
     * @param in  文件流
     * @param key 属性KEY
     * @return 属性VALUE
     * @Author: Tangwenwu
     * @Created date: 2014年12月3日
     */
    public static String readProperValue(InputStream in, String key) {
        try {
            Properties prop = new Properties();
            prop.load(in);
            return prop.getProperty(key, "");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Definition:向文本配置文件内写入或更新某属性值
     *
     * @param filePath
     * @param key
     * @param value
     * @Author: Tangwenwu
     * @Created date: 2017-3-23
     */
    public static boolean writeProperValue(String filePath, String key, String value) {
        try {
            InputStream in = new FileInputStream(filePath);
            Properties prop = new Properties();
            prop.load(in);
            in.close();
            prop.setProperty(key, value); //写值，如存在则覆盖原有值
            OutputStream out = new FileOutputStream(filePath);
            prop.store(out, "");
            out.close();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}

	