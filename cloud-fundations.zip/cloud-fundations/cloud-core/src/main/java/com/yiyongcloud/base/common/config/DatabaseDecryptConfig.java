package com.yiyongcloud.base.common.config;

import com.baomidou.dynamic.datasource.provider.DynamicDataSourceProvider;
import com.baomidou.dynamic.datasource.provider.YmlDynamicDataSourceProvider;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDataSourceProperties;

import com.yiyongcloud.base.common.db.encrypt.Encryptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * 用于在数据源注入前拦截，便于后续的进行解密操作
 *
 * @author tangww
 * @date 2021/4/4
 */
@Slf4j
@Configuration
public class DatabaseDecryptConfig {

    @Autowired
    private DynamicDataSourceProperties properties;

    /**
     * 动态数据源配置,覆盖默认的dynamicDataSourceProvider初始化
     *
     * @return
     */
    @Bean
    public DynamicDataSourceProvider dynamicDataSourceProvider() {
        Map<String, DataSourceProperty> dataSourcePropertiesMap = properties.getDatasource();
        for (Map.Entry<String, DataSourceProperty> item : dataSourcePropertiesMap.entrySet()) {
            DataSourceProperty dataSourceProperty = item.getValue();
            dataSourceProperty.setPublicKey(Encryptor.pubKey);
        }
        return new YmlDynamicDataSourceProvider(dataSourcePropertiesMap);
    }

}
