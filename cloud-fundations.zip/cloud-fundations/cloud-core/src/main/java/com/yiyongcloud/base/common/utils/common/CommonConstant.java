package com.yiyongcloud.base.common.utils.common;

import java.time.format.DateTimeFormatter;

/**
 * @author
 */
public class CommonConstant {

    /**
     * 只允许输入IP地址
     */
    public static final String IPV4_REGEXP =
            "^((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})(\\.((2(5[0-5]|[0-4]\\d))|[0-1]?\\d{1,2})){3}$";

    /**
     * 只允许输入IP地址
     */
    public static final String IPV4_REGEXP_MSG = "IP地址格式不正确";
    /**
     * 允许字母数字下划线
     */
    public static final String WORD_NUMBER_DOWNLINE = "^[A-Za-z0-9_\\.]*$";

    public static final String WORD_NUMBER_DOWNLINE_MSG = "仅允许字母数字下划线";

    /**
     * 只允许汉字的正则
     */
    public static final String ONLY_CHINESE_REGEXP = "^[\\u4E00-\\u9FA5\\*]*$";
    /**
     * 只允许汉字的正则
     */
    public static final String ONLY_CHINESE_REGEXP_MSG = "只允许输入汉字";

    /***
     * 允许汉字，字母，数字，下划线
     */
    public static final String CHINESE_WORDS_NUMBER_DOWNLINE = "^[\\u4E00-\\u9FA5A-Za-z0-9_]*$";

    /***
     * 允许汉字，字母，数字，下划线
     */
    public static final String CHINESE_WORDS_NUMBER_DOWNLINE_MSG = "仅允许汉字，字母，数字，下划线";


    /***
     * 根权限点
     */
    public static final Long ROOT_PARENT_ID = 0L;


    public static final String DATE_TIME_FORMATTER_PATTERN = "yyyy-MM-dd HH:mm:ss";
    /**
     * 日期格式化
     */
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * 日期格式化
     */
    public static final DateTimeFormatter backupdate_fromatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    public static final DateTimeFormatter ES_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /**
     * 系统定义的最大分页大小
     */
    public static final int MAX_PAGE_SIZE = 500;

    /**
     * redis中如果存放token信息，这个为统一的前缀
     */
    public static final String REDIS_TOKEN_PREFIX = "TOKEN_";
}
