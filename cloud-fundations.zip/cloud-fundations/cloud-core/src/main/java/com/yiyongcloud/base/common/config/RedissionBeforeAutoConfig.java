package com.yiyongcloud.base.common.config;

import com.alibaba.cloud.nacos.NacosPropertySourceRepository;
import com.yiyongcloud.base.common.db.encrypt.Encryptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.config.Config;
import org.redisson.spring.starter.RedissonProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisOperations;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.Objects;

/**
 * redission连接配置,在RedissonAutoConfiguration之前配置，保证RedissonProperties是在这里被设置值
 * 这里的密码解密采用encryptor里边提供的加解密工具，这样可以只给运维人员提供一套加解密工具。
 *
 * @author tangww
 * @date 2021/4/5
 */
@Slf4j
@Configuration
@ConditionalOnClass({Redisson.class, RedisOperations.class})
@AutoConfigureBefore(MyRedissonAutoConfiguration.class)
@EnableConfigurationProperties({RedissonProperties.class, RedisProperties.class})
public class RedissionBeforeAutoConfig extends Config {

    @Autowired
    private RedissonProperties redissonProperties;


    /**
     * 使用mybatisplus提供的加解密来解密redis密码
     *
     * @throws Exception
     */
    @PostConstruct
    public void init() throws Exception {
        Map<String, Object> pro = NacosPropertySourceRepository
                .getNacosPropertySource("redisson-config.yaml", "DISABLE_REFRESH_GROUP_PRODUCT_SHARED").getSource();
        String redissonConfig = (String) pro.get("spring.redisson.config");
        log.warn("=======redis config====:{}", redissonConfig);
        //TODO redis 密码未加密
//        String[] lines = redissonConfig.split("\n");
//        String oldPwdLine = null;
//        String newPwdLine = null;
//        for (String line : lines) {
//            if (line.trim().startsWith("password:")) {
//                oldPwdLine = line;
//                String pwd = line.split(":")[1].trim();
//                if (StringUtils.isNotBlank(pwd) && !"null".equalsIgnoreCase(pwd)) {
//                    String pwdAfterDecrypt = Encryptor.decrypt(pwd);
//                    newPwdLine = line.split(":")[0] + ": " + pwdAfterDecrypt;
//                }
//                break;
//            }
//        }
//        if (Objects.nonNull(newPwdLine)) {
//            redissonConfig = redissonConfig.replace(oldPwdLine, newPwdLine);
//        }
        this.redissonProperties.setConfig(redissonConfig);
    }

}
