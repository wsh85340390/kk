package com.yiyongcloud.base.common.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author
 */
@Data
public class BaseForm implements Serializable {


    /**
     * 审计日志
     *
     * @return
     */
    protected String auditLogReqParam() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("(");
        buffer.append(")");
        return buffer.toString();
    }

}
