package com.yiyongcloud.base.client.account.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yiyongcloud.base.common.entity.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;

/**
 * UserBaseInfoExtendEntity<br>
 * Create Date: 2019年4月19日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2019 boco.com.cn All Right Reserved.<br>
 *
 * @author LiuJianli
 * @version 1.0
 */
@ApiModel(value = "UserBaseInfoExtendEntity")
public class UserBaseInfoExtendEntity extends BaseEntity {
    /**
     * ID
     */
    @ApiModelProperty(value = "ID")
    private Integer id;

    /**
     * 用户基础表ID
     */
    @ApiModelProperty(value = "用户基础表ID")
    private String pubUidid;
    /**
     * 民族
     */
    @ApiModelProperty(value = "民族")
    private String iamNation;

    /**
     * 用户性别(男/女)
     */
    @ApiModelProperty(value = "用户性别(男/女)")
    private String iamGender;
    /**
     * 用户出生日期
     */
    @ApiModelProperty(value = "用户出生日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date iamBirthday;

    /**
     * 用户国籍
     */
    @ApiModelProperty(value = "用户国籍")
    private String iamNationalitynationality;

    /**
     * 用户政治面貌
     */
    @ApiModelProperty(value = "用户政治面貌")
    private String iamReligion;

    /**
     * 用户办公电话
     */
    @ApiModelProperty(value = "用户办公电话")
    private String iamTelephone;

    /**
     * 用户通讯地址
     */
    @ApiModelProperty(value = "用户通讯地址")
    private String iamPostaladdress;

    /**
     * 用户的邮政编码
     */
    @ApiModelProperty(value = "用户的邮政编码")
    private String iamPostalcode;

    /**
     * 用户的传真号码
     */
    @ApiModelProperty(value = "用户的传真号码")
    private String iamFacsimilenumber;

    /**
     * 用户的开始生效时间
     */
    @ApiModelProperty(value = "用户的开始生效时间")
    private Date iamStarttime;

    /**
     * 用户的结束生效时间
     */
    @ApiModelProperty(value = "用户的结束生效时间")
    private Date iamEndtime;

    /**
     * 用户帐号的状态
     */
    @ApiModelProperty(value = "用户帐号的状态  0-正常 1-锁定  2-删除")
    private Integer iamStatus;

    /**
     * 身份证号
     */
    @ApiModelProperty(value = "身份证号")
    private String iamIdcardnumber;

    /**
     * 员工号
     */
    @ApiModelProperty(value = "员工号")
    private String iamEmployeenumber;

    @ApiModelProperty(value = "是否导出字组织机构的用户数据 1:代表是")
    private String exportChild;

    public String getExportChild() {
        return exportChild;
    }

    public void setExportChild(String exportChild) {
        this.exportChild = exportChild;
    }

    private String order;//解决json转化报错
    private String userId;//解决json转化报错
    private String userOrgId;//解决json转化报错
    private String sessionId;//解决json转化报错
    private String userIp;//由于报错显示json转化错误故添加
    private String token;//由于报错显示json转化错误故添加
    private String clientMac;//由于报错显示json转化错误故添加

    public String getClientMac() {
        return clientMac;
    }

    public void setClientMac(String clientMac) {
        this.clientMac = clientMac;
    }

    /**
     * 职级
     */
    @ApiModelProperty(value = "职级")
    private String iamLevel;

    /**
     * 岗位名称
     */
    @ApiModelProperty(value = "岗位名称")
    private String iamLevelname;

    /**
     * 员工套入职级
     */
    @ApiModelProperty(value = "员工套入职级")
    private String iamCategory;

    /**
     * 用户开始工作时间
     */
    @ApiModelProperty(value = "用户开始工作时间")
    private Date iamEntrytime;

    /**
     * 用户层级编码
     */
    @ApiModelProperty(value = "用户层级编码")
    private String iamPositionleven;

    /**
     * 用户归属类型
     */
    @ApiModelProperty(value = "用户归属类型")
    private Integer iamEmployeeBelongType;

    /**
     * 所属省份名称
     */
    @ApiModelProperty(value = "所属省份名称")
    private String iamProvinces;

    /**
     * 所属地市名称
     */
    @ApiModelProperty(value = "所属地市名称")
    private String iamLocationname;

    /**
     * 所在公司名称
     */
    @ApiModelProperty(value = "所在公司名称")
    private String iamSupportrecorpname;

    /**
     * 所在公司部门
     */
    @ApiModelProperty(value = "所在公司部门")
    private String iamSupporterdept;

    /**
     * 所在公司联系人
     */
    @ApiModelProperty(value = "所在公司联系人")
    private String iamSupportercorpcontact;

    /**
     * 负责人
     */
    @ApiModelProperty(value = "负责人")
    private String iamSupervisor;

    /**
     * 锁定原因
     */
    @ApiModelProperty(value = "锁定原因")
    private String iamLockcause;

    /**
     * 创建者
     */
    @ApiModelProperty(value = "创建者")
    private String iamCreateuserkey;

    /**
     * 创建日期
     */
    @ApiModelProperty(value = "创建日期")
    private Date iamCreatedate;

    /**
     * 修改者
     */
    @ApiModelProperty(value = "修改者")
    private String iamModifyuserkey;

    /**
     * 修改日期
     */
    @ApiModelProperty(value = "修改日期")
    private Date iamModifydate;

    /**
     * 定义用户描述
     */
    @ApiModelProperty(value = "定义用户描述")
    private String iamDescr;
    /**
     * 用户锁定策略Id
     */
    @ApiModelProperty(value = "用户锁定策略Id")
    private String iamUserLockPolicyId;
    /**
     * 用户锁定策略名称
     */
    @ApiModelProperty(value = "用户锁定策略名称")
    private String iamUserLockPolicyName;
    /**
     * 用户自维护策略Id
     */
    @ApiModelProperty(value = "用户自维护策略Id")
    private String iamSinceTheMaintenancePolicyId;
    /**
     * 用户自维护策略名称
     */
    @ApiModelProperty(value = "用户自维护策略名称")
    private String iamSinceTheMaintenancePolicyName;
    /**
     * 用户访问策略Id
     */
    @ApiModelProperty(value = "用户访问策略Id")
    private String iamUserAccessPolicyId;
    /**
     * 用户访问策略名称
     */
    @ApiModelProperty(value = "用户访问策略名称")
    private String iamUserAccessPolicyName;
    /**
     * 用户密码策略Id
     */
    @ApiModelProperty(value = "用户密码策略Id")
    private String iamUserPwdPolicyId;
    /**
     * 用户密码策略名称
     */
    @ApiModelProperty(value = "用户密码策略名称")
    private String iamUserPwdPolicyName;
    /**
     * 用户GBA访问策略Id
     */
    @ApiModelProperty(value = "用户GBA访问策略Id")
    private String iamUserLoginGbaPolicyId;
    /**
     * 用户GBA访问策略名称
     */
    @ApiModelProperty(value = "用户GBA访问策略名称")
    private String iamUserLoginGbaPolicyName;
    /**
     * 用户认证策略Id
     */
    @ApiModelProperty(value = "用户认证策略Id")
    private String iamUserAuthenPolicyId;
    /**
     * 用户认证策略名称
     */
    @ApiModelProperty(value = "用户认证策略名称")
    private String iamUserAuthenPolicyName;
    /**
     * 临时手机号
     */
    @ApiModelProperty(value = "临时手机号")
    private String iamTempTelephone;
    /**
     * 临时手机号过期时间
     */
    @ApiModelProperty(value = "临时手机号过期时间")
    private Date iamTempTelephoneExpired;
    /**
     * 内部小号
     */
    @ApiModelProperty(value = "内部小号")
    private String iamInternalTrumpet;
    /**
     * 外部用户类型
     */
    @ApiModelProperty(value = "外部用户类型")
    private String iamemployeeType;

    /**
     * 是否漫游用户，用户漫游使用
     */
    private String isRove;

    public String getIsRove() {
        return isRove;
    }

    public void setIsRove(String isRove) {
        this.isRove = isRove;
    }

    public String getIamemployeeType() {
        return iamemployeeType;
    }

    public void setIamemployeeType(String iamemployeeType) {
        this.iamemployeeType = iamemployeeType;
    }

    public String getIamInternalTrumpet() {
        return iamInternalTrumpet;
    }

    public void setIamInternalTrumpet(String iamInternalTrumpet) {
        this.iamInternalTrumpet = iamInternalTrumpet;
    }

    /**
     * 密码输入错误N次后，才允许用户登录日期，由帐号锁定策略产生
     */
    @ApiModelProperty(value = "密码输入错误N次后，才允许用户登录日期，由帐号锁定策略产生")
    private String iamUserallowlogindate;
    @ApiModelProperty(value = "用户最后登录日期")
    private String iamUserlastlogondate;

    @ApiModelProperty(value = "业务职责编码集合")
    private String functionids;
    @ApiModelProperty(value = "业务职责名称集合")
    private String functionNames;

    /**
     * IAM_USERBASEINFOEXTEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * 人员姓名
     */
    @ApiModelProperty(value = "人员姓名")
    private String userName;

    /**
     * 登录账号
     */
    @ApiModelProperty(value = "登录账号")
    private String userLoginName;

    /**
     * 登录密码
     */
    @ApiModelProperty(value = "登录密码")
    private String userLoginPassword;

    /**
     * VPN验证码
     */
    @ApiModelProperty(value = "VPN验证码")
    private String vpnCode;

    /**
     * 4A主帐号
     */
    @ApiModelProperty(value = "4A主帐号")
    private String userAccount;

    /**
     * 人员类型
     */
    @ApiModelProperty(value = "人员类型  1-内部 2-外部")
    private String userType;

    /**
     * 所属组织ID
     */
    @ApiModelProperty(value = "所属组织ID")
    private String userOrg;

    /**
     * 职位
     */
    @ApiModelProperty(value = "职位")
    private String userPosition;

    /**
     * 电话
     */
    @ApiModelProperty(value = "电话")
    private String userTel;

    /**
     * 邮箱
     */
    @ApiModelProperty(value = "邮箱")
    private String userMail;

    /**
     * 1表示超级管理员；0表示普通用户
     */
    @ApiModelProperty(value = "是否管理员")
    private int isAdmin;

    /**
     * 用户查询范围： 1表示父子组织机构 ；0 或空 表示本组织机构
     */
    @ApiModelProperty(value = "用户查询范围1表示父子组织机构 ；0 或空 表示本组织机构")
    private Integer flag;

    /**
     * 组织机构名称
     */
    @ApiModelProperty(value = "组织机构名称")
    private String orgName;

    /**
     * 用户组名称
     */
    @ApiModelProperty(value = "用户组名称")
    private String userGroupName;
    /**
     * 用户组id集合
     */
    @ApiModelProperty(value = "用户组id集合")
    private String userGroupId;

    /**
     * 风险级别（与职务相对应使用）
     */
    private String iamUserLevel;

    /**
     * 用工属性
     */
    @ApiModelProperty(value = "用工属性")
    private String iamEmployeesAttribute;

    /**
     * 管理序列
     */
    @ApiModelProperty(value = "管理序列")
    private String iamAdministerSequence;

    /**
     * 服务开始时间
     */
    @ApiModelProperty(value = "服务开始时间")

    private Date iamServerStartTime;

    /**
     * 劳动合同单位
     */
    @ApiModelProperty(value = "劳动合同单位")
    private String iamLaborContractUnit;

    /**
     * 最高学历
     */
    @ApiModelProperty(value = "最高学历")
    private String iamHighestEducation;

    /**
     * 最高学历学校
     */
    @ApiModelProperty(value = "最高学历学校")
    private String iamHighestEducationSchool;

    /**
     * 最高学历专业
     */
    @ApiModelProperty(value = "最高学历专业")
    private String iamHighestEducationSpecialty;

    /**
     * 全日制学历
     */
    @ApiModelProperty(value = "全日制学历")
    private String iamFullTimeEducation;

    /**
     * 全日制学校
     */
    @ApiModelProperty(value = "全日制学校")
    private String iamFullTimeSchool;

    /**
     * 全日制专业
     */
    @ApiModelProperty(value = "全日制专业")
    private String iamFullTimeSpecialty;

    /**
     * 是否全日制
     */
    @ApiModelProperty(value = "是否全日制(1: 是, 0: 不是)")
    private Integer iamWhetherFulltime;

    public Integer getIamWhetherFulltime() {
        return iamWhetherFulltime;
    }

    public void setIamWhetherFulltime(Integer iamWhetherFulltime) {
        this.iamWhetherFulltime = iamWhetherFulltime;
    }


    @ApiModelProperty(value = "网格人员所属地市")
    private String gridAreaCode;

    @ApiModelProperty(value = "网格人员所属区县")
    private String gridEeparchyCode;

    @ApiModelProperty(value = "网格人员岗位")
    private String gridPositionCode;

    @ApiModelProperty(value = "网格人员角色")
    private String gridRoleId;

    @ApiModelProperty(value = "网格人员密码")
    private String gridPassword;

    @ApiModelProperty(value = "网格人员职位")
    private String gridPostCode;

    /**
     * 进入联通时间
     */
    @ApiModelProperty(value = "进入联通时间")
    private Date iamInductionTime;

    public String getGridAreaCode() {
        return gridAreaCode;
    }

    public void setGridAreaCode(String gridAreaCode) {
        this.gridAreaCode = gridAreaCode;
    }

    public String getGridEeparchyCode() {
        return gridEeparchyCode;
    }

    public void setGridEeparchyCode(String gridEeparchyCode) {
        this.gridEeparchyCode = gridEeparchyCode;
    }

    public String getGridPositionCode() {
        return gridPositionCode;
    }

    public void setGridPositionCode(String gridPositionCode) {
        this.gridPositionCode = gridPositionCode;
    }

    public String getGridRoleId() {
        return gridRoleId;
    }

    public void setGridRoleId(String gridRoleId) {
        this.gridRoleId = gridRoleId;
    }

    public String getGridPassword() {
        return gridPassword;
    }

    public void setGridPassword(String gridPassword) {
        this.gridPassword = gridPassword;
    }

    public String getGridPostCode() {
        return gridPostCode;
    }

    public void setGridPostCode(String gridPostCode) {
        this.gridPostCode = gridPostCode;
    }


    public String getIamEmployeesAttribute() {
        return iamEmployeesAttribute;
    }

    public void setIamEmployeesAttribute(String iamEmployeesAttribute) {
        this.iamEmployeesAttribute = iamEmployeesAttribute;
    }

    public String getIamAdministerSequence() {
        return iamAdministerSequence;
    }

    public void setIamAdministerSequence(String iamAdministerSequence) {
        this.iamAdministerSequence = iamAdministerSequence;
    }

    public Date getIamServerStartTime() {
        return iamServerStartTime;
    }

    public void setIamServerStartTime(Date iamServerStartTime) {
        this.iamServerStartTime = iamServerStartTime;
    }

    public String getIamLaborContractUnit() {
        return iamLaborContractUnit;
    }

    public void setIamLaborContractUnit(String iamLaborContractUnit) {
        this.iamLaborContractUnit = iamLaborContractUnit;
    }

    public String getIamHighestEducation() {
        return iamHighestEducation;
    }

    public void setIamHighestEducation(String iamHighestEducation) {
        this.iamHighestEducation = iamHighestEducation;
    }

    public String getIamHighestEducationSchool() {
        return iamHighestEducationSchool;
    }

    public void setIamHighestEducationSchool(String iamHighestEducationSchool) {
        this.iamHighestEducationSchool = iamHighestEducationSchool;
    }

    public String getIamHighestEducationSpecialty() {
        return iamHighestEducationSpecialty;
    }

    public void setIamHighestEducationSpecialty(String iamHighestEducationSpecialty) {
        this.iamHighestEducationSpecialty = iamHighestEducationSpecialty;
    }

    public String getIamFullTimeEducation() {
        return iamFullTimeEducation;
    }

    public void setIamFullTimeEducation(String iamFullTimeEducation) {
        this.iamFullTimeEducation = iamFullTimeEducation;
    }

    public String getIamFullTimeSchool() {
        return iamFullTimeSchool;
    }

    public void setIamFullTimeSchool(String iamFullTimeSchool) {
        this.iamFullTimeSchool = iamFullTimeSchool;
    }

    public String getIamFullTimeSpecialty() {
        return iamFullTimeSpecialty;
    }

    public void setIamFullTimeSpecialty(String iamFullTimeSpecialty) {
        this.iamFullTimeSpecialty = iamFullTimeSpecialty;
    }

    public String getIamUserLevel() {
        return iamUserLevel;
    }

    public void setIamUserLevel(String iamUserLevel) {
        this.iamUserLevel = iamUserLevel;
    }

    public String getIamUserlastlogondate() {
        return iamUserlastlogondate;
    }

    public void setIamUserlastlogondate(String iamUserlastlogondate) {
        this.iamUserlastlogondate = iamUserlastlogondate;
    }

    public String getIamTempTelephone() {
        return iamTempTelephone;
    }

    public void setIamTempTelephone(String iamTempTelephone) {
        this.iamTempTelephone = iamTempTelephone;
    }


    public Date getIamTempTelephoneExpired() {
        return iamTempTelephoneExpired;
    }

    public void setIamTempTelephoneExpired(Date iamTempTelephoneExpired) {
        this.iamTempTelephoneExpired = iamTempTelephoneExpired;
    }

    public String getFunctionids() {
        return functionids;
    }

    public void setFunctionids(String functionids) {
        this.functionids = functionids;
    }

    public String getFunctionNames() {
        return functionNames;
    }

    public void setFunctionNames(String functionNames) {
        this.functionNames = functionNames;
    }

    public String getIamUserallowlogindate() {
        return iamUserallowlogindate;
    }

    public void setIamUserallowlogindate(String iamUserallowlogindate) {
        this.iamUserallowlogindate = iamUserallowlogindate;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLoginName() {
        return userLoginName;
    }

    public void setUserLoginName(String userLoginName) {
        this.userLoginName = userLoginName;
    }

    public String getUserLoginPassword() {
        return userLoginPassword;
    }

    public void setUserLoginPassword(String userLoginPassword) {
        this.userLoginPassword = userLoginPassword;
    }

    public String getVpnCode() {
        return vpnCode;
    }

    public void setVpnCode(String vpnCode) {
        this.vpnCode = vpnCode;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserOrg() {
        return userOrg;
    }

    public void setUserOrg(String userOrg) {
        this.userOrg = userOrg;
    }

    public String getUserPosition() {
        return userPosition;
    }

    public void setUserPosition(String userPosition) {
        this.userPosition = userPosition;
    }

    public String getUserTel() {
        return userTel;
    }

    public void setUserTel(String userTel) {
        this.userTel = userTel;
    }

    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public int getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(int isAdmin) {
        this.isAdmin = isAdmin;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getUserGroupName() {
        return userGroupName;
    }

    public void setUserGroupName(String userGroupName) {
        this.userGroupName = userGroupName;
    }

    public String getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(String userGroupId) {
        this.userGroupId = userGroupId;
    }

    /**
     * ID
     *
     * @return ID ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * ID
     *
     * @param id ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 用户基础表ID
     *
     * @return PUB_UIDID 用户基础表ID
     */
    public String getPubUidid() {
        return pubUidid;
    }

    /**
     * 用户基础表ID
     *
     * @param pubUidid 用户基础表ID
     */
    public void setPubUidid(String pubUidid) {
        this.pubUidid = pubUidid;
    }

    /**
     * 民族
     *
     * @return IAM_NATION 民族
     */
    public String getIamNation() {
        return iamNation;
    }

    /**
     * 民族
     *
     * @param iamNation 民族
     */
    public void setIamNation(String iamNation) {
        this.iamNation = iamNation;
    }

    /**
     * 用户性别(男/女)
     *
     * @return IAM_GENDER 用户性别(男/女)
     */
    public String getIamGender() {
        return iamGender;
    }

    /**
     * 用户性别(男/女)
     *
     * @param iamGender 用户性别(男/女)
     */
    public void setIamGender(String iamGender) {
        this.iamGender = iamGender;
    }

    /**
     * 用户出生日期
     *
     * @return IAM_BIRTHDAY 用户出生日期
     */
    public Date getIamBirthday() {
        return iamBirthday;
    }

    /**
     * 用户出生日期
     *
     * @param iamBirthday 用户出生日期
     */
    public void setIamBirthday(Date iamBirthday) {
        this.iamBirthday = iamBirthday;
    }

    /**
     * 用户国籍
     *
     * @return IAM_NATIONALITYNATIONALITY 用户国籍
     */
    public String getIamNationalitynationality() {
        return iamNationalitynationality;
    }

    /**
     * 用户国籍
     *
     * @param iamNationalitynationality 用户国籍
     */
    public void setIamNationalitynationality(String iamNationalitynationality) {
        this.iamNationalitynationality = iamNationalitynationality;
    }

    /**
     * 用户政治面貌
     *
     * @return IAM_RELIGION 用户政治面貌
     */
    public String getIamReligion() {
        return iamReligion;
    }

    /**
     * 用户政治面貌
     *
     * @param iamReligion 用户政治面貌
     */
    public void setIamReligion(String iamReligion) {
        this.iamReligion = iamReligion;
    }

    /**
     * 用户办公电话
     *
     * @return IAM_TELEPHONE 用户办公电话
     */
    public String getIamTelephone() {
        return iamTelephone;
    }

    /**
     * 用户办公电话
     *
     * @param iamTelephone 用户办公电话
     */
    public void setIamTelephone(String iamTelephone) {
        this.iamTelephone = iamTelephone;
    }

    /**
     * 用户通讯地址
     *
     * @return IAM_POSTALADDRESS 用户通讯地址
     */
    public String getIamPostaladdress() {
        return iamPostaladdress;
    }

    /**
     * 用户通讯地址
     *
     * @param iamPostaladdress 用户通讯地址
     */
    public void setIamPostaladdress(String iamPostaladdress) {
        this.iamPostaladdress = iamPostaladdress;
    }

    /**
     * 用户的邮政编码
     *
     * @return IAM_POSTALCODE 用户的邮政编码
     */
    public String getIamPostalcode() {
        return iamPostalcode;
    }

    /**
     * 用户的邮政编码
     *
     * @param iamPostalcode 用户的邮政编码
     */
    public void setIamPostalcode(String iamPostalcode) {
        this.iamPostalcode = iamPostalcode;
    }

    /**
     * 用户的传真号码
     *
     * @return IAM_FACSIMILENUMBER 用户的传真号码
     */
    public String getIamFacsimilenumber() {
        return iamFacsimilenumber;
    }

    /**
     * 用户的传真号码
     *
     * @param iamFacsimilenumber 用户的传真号码
     */
    public void setIamFacsimilenumber(String iamFacsimilenumber) {
        this.iamFacsimilenumber = iamFacsimilenumber;
    }

    /**
     * 用户的开始生效时间
     *
     * @return IAM_STARTTIME 用户的开始生效时间
     */
    public Date getIamStarttime() {
        return iamStarttime;
    }

    /**
     * 用户的开始生效时间
     *
     * @param iamStarttime 用户的开始生效时间
     */
    public void setIamStarttime(Date iamStarttime) {
        this.iamStarttime = iamStarttime;
    }

    /**
     * 用户的结束生效时间
     *
     * @return IAM_ENDTIME 用户的结束生效时间
     */
    public Date getIamEndtime() {
        return iamEndtime;
    }

    /**
     * 用户的结束生效时间
     *
     * @param iamEndtime 用户的结束生效时间
     */
    public void setIamEndtime(Date iamEndtime) {
        this.iamEndtime = iamEndtime;
    }

    /**
     * 用户帐号的状态
     *
     * @return IAM_STATUS 用户帐号的状态
     */
    public Integer getIamStatus() {
        return iamStatus;
    }

    /**
     * 用户帐号的状态
     *
     * @param iamStatus 用户帐号的状态
     */
    public void setIamStatus(Integer iamStatus) {
        this.iamStatus = iamStatus;
    }

    /**
     * 身份证号
     *
     * @return IAM_IDCARDNUMBER 身份证号
     */
    public String getIamIdcardnumber() {
        return iamIdcardnumber;
    }

    /**
     * 身份证号
     *
     * @param iamIdcardnumber 身份证号
     */
    public void setIamIdcardnumber(String iamIdcardnumber) {
        this.iamIdcardnumber = iamIdcardnumber;
    }

    /**
     * 员工号
     *
     * @return IAM_EMPLOYEENUMBER 员工号
     */
    public String getIamEmployeenumber() {
        return iamEmployeenumber;
    }

    /**
     * 员工号
     *
     * @param iamEmployeenumber 员工号
     */
    public void setIamEmployeenumber(String iamEmployeenumber) {
        this.iamEmployeenumber = iamEmployeenumber;
    }

    /**
     * 职级
     *
     * @return IAM_LEVEL 职级
     */
    public String getIamLevel() {
        return iamLevel;
    }

    /**
     * 职级
     *
     * @param iamLevel 职级
     */
    public void setIamLevel(String iamLevel) {
        this.iamLevel = iamLevel;
    }

    /**
     * 岗位名称
     *
     * @return IAM_LEVELNAME 岗位名称
     */
    public String getIamLevelname() {
        return iamLevelname;
    }

    /**
     * 岗位名称
     *
     * @param iamLevelname 岗位名称
     */
    public void setIamLevelname(String iamLevelname) {
        this.iamLevelname = iamLevelname;
    }

    /**
     * 员工套入职级
     *
     * @return IAM_CATEGORY 员工套入职级
     */
    public String getIamCategory() {
        return iamCategory;
    }

    /**
     * 员工套入职级
     *
     * @param iamCategory 员工套入职级
     */
    public void setIamCategory(String iamCategory) {
        this.iamCategory = iamCategory;
    }

    /**
     * 用户开始工作时间
     *
     * @return IAM_ENTRYTIME 用户开始工作时间
     */
    public Date getIamEntrytime() {
        return iamEntrytime;
    }

    /**
     * 用户开始工作时间
     *
     * @param iamEntrytime 用户开始工作时间
     */
    public void setIamEntrytime(Date iamEntrytime) {
        this.iamEntrytime = iamEntrytime;
    }

    /**
     * 用户层级编码
     *
     * @return IAM_POSITIONLEVEN 用户层级编码
     */
    public String getIamPositionleven() {
        return iamPositionleven;
    }

    /**
     * 用户层级编码
     *
     * @param iamPositionleven 用户层级编码
     */
    public void setIamPositionleven(String iamPositionleven) {
        this.iamPositionleven = iamPositionleven;
    }

    /**
     * 用户归属类型
     *
     * @return IAM_EMPLOYEE_BELONG_TYPE 用户归属类型
     */
    public Integer getIamEmployeeBelongType() {
        return iamEmployeeBelongType;
    }

    /**
     * 用户归属类型
     *
     * @param iamEmployeeBelongType 用户归属类型
     */
    public void setIamEmployeeBelongType(Integer iamEmployeeBelongType) {
        this.iamEmployeeBelongType = iamEmployeeBelongType;
    }

    /**
     * 所属省份名称
     *
     * @return IAM_PROVINCES 所属省份名称
     */
    public String getIamProvinces() {
        return iamProvinces;
    }

    /**
     * 所属省份名称
     *
     * @param iamProvinces 所属省份名称
     */
    public void setIamProvinces(String iamProvinces) {
        this.iamProvinces = iamProvinces;
    }

    /**
     * 所属地市名称
     *
     * @return IAM_LOCATIONNAME 所属地市名称
     */
    public String getIamLocationname() {
        return iamLocationname;
    }

    /**
     * 所属地市名称
     *
     * @param iamLocationname 所属地市名称
     */
    public void setIamLocationname(String iamLocationname) {
        this.iamLocationname = iamLocationname;
    }

    /**
     * 所在公司名称
     *
     * @return IAM_SUPPORTRECORPNAME 所在公司名称
     */
    public String getIamSupportrecorpname() {
        return iamSupportrecorpname;
    }

    /**
     * 所在公司名称
     *
     * @param iamSupportrecorpname 所在公司名称
     */
    public void setIamSupportrecorpname(String iamSupportrecorpname) {
        this.iamSupportrecorpname = iamSupportrecorpname;
    }

    /**
     * 所在公司部门
     *
     * @return IAM_SUPPORTERDEPT 所在公司部门
     */
    public String getIamSupporterdept() {
        return iamSupporterdept;
    }

    /**
     * 所在公司部门
     *
     * @param iamSupporterdept 所在公司部门
     */
    public void setIamSupporterdept(String iamSupporterdept) {
        this.iamSupporterdept = iamSupporterdept;
    }

    /**
     * 所在公司联系人
     *
     * @return IAM_SUPPORTERCORPCONTACT 所在公司联系人
     */
    public String getIamSupportercorpcontact() {
        return iamSupportercorpcontact;
    }

    /**
     * 所在公司联系人
     *
     * @param iamSupportercorpcontact 所在公司联系人
     */
    public void setIamSupportercorpcontact(String iamSupportercorpcontact) {
        this.iamSupportercorpcontact = iamSupportercorpcontact;
    }

    /**
     * 负责人
     *
     * @return IAM_SUPERVISOR 负责人
     */
    public String getIamSupervisor() {
        return iamSupervisor;
    }

    /**
     * 负责人
     *
     * @param iamSupervisor 负责人
     */
    public void setIamSupervisor(String iamSupervisor) {
        this.iamSupervisor = iamSupervisor;
    }

    /**
     * 锁定原因
     *
     * @return IAM_LOCKCAUSE 锁定原因
     */
    public String getIamLockcause() {
        return iamLockcause;
    }

    /**
     * 锁定原因
     *
     * @param iamLockcause 锁定原因
     */
    public void setIamLockcause(String iamLockcause) {
        this.iamLockcause = iamLockcause;
    }

    /**
     * 创建者
     *
     * @return IAM_CREATEUSERKEY 创建者
     */
    public String getIamCreateuserkey() {
        return iamCreateuserkey;
    }

    /**
     * 创建者
     *
     * @param iamCreateuserkey 创建者
     */
    public void setIamCreateuserkey(String iamCreateuserkey) {
        this.iamCreateuserkey = iamCreateuserkey;
    }

    /**
     * 创建日期
     *
     * @return IAM_CREATEDATE 创建日期
     */
    public Date getIamCreatedate() {
        return iamCreatedate;
    }

    /**
     * 创建日期
     *
     * @param iamCreatedate 创建日期
     */
    public void setIamCreatedate(Date iamCreatedate) {
        this.iamCreatedate = iamCreatedate;
    }

    /**
     * 修改者
     *
     * @return IAM_MODIFYUSERKEY 修改者
     */
    public String getIamModifyuserkey() {
        return iamModifyuserkey;
    }

    /**
     * 修改者
     *
     * @param iamModifyuserkey 修改者
     */
    public void setIamModifyuserkey(String iamModifyuserkey) {
        this.iamModifyuserkey = iamModifyuserkey;
    }

    /**
     * 修改日期
     *
     * @return IAM_MODIFYDATE 修改日期
     */
    public Date getIamModifydate() {
        return iamModifydate;
    }

    /**
     * 修改日期
     *
     * @param iamModifydate 修改日期
     */
    public void setIamModifydate(Date iamModifydate) {
        this.iamModifydate = iamModifydate;
    }

    /**
     * 定义用户描述
     *
     * @return IAM_DESCR 定义用户描述
     */
    public String getIamDescr() {
        return iamDescr;
    }


    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserOrgId() {
        return userOrgId;
    }

    public void setUserOrgId(String userOrgId) {
        this.userOrgId = userOrgId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }


    /**
     * 定义用户描述
     *
     * @param iamDescr 定义用户描述
     */
    public void setIamDescr(String iamDescr) {
        this.iamDescr = iamDescr;
    }

    public String getIamUserLockPolicyId() {
        return iamUserLockPolicyId;
    }

    public void setIamUserLockPolicyId(String iamUserLockPolicyId) {
        this.iamUserLockPolicyId = iamUserLockPolicyId;
    }

    public String getIamUserLockPolicyName() {
        return iamUserLockPolicyName;
    }

    public void setIamUserLockPolicyName(String iamUserLockPolicyName) {
        this.iamUserLockPolicyName = iamUserLockPolicyName;
    }

    public String getIamSinceTheMaintenancePolicyId() {
        return iamSinceTheMaintenancePolicyId;
    }

    public void setIamSinceTheMaintenancePolicyId(String iamSinceTheMaintenancePolicyId) {
        this.iamSinceTheMaintenancePolicyId = iamSinceTheMaintenancePolicyId;
    }

    public String getIamSinceTheMaintenancePolicyName() {
        return iamSinceTheMaintenancePolicyName;
    }

    public void setIamSinceTheMaintenancePolicyName(String iamSinceTheMaintenancePolicyName) {
        this.iamSinceTheMaintenancePolicyName = iamSinceTheMaintenancePolicyName;
    }

    public String getIamUserAccessPolicyId() {
        return iamUserAccessPolicyId;
    }

    public void setIamUserAccessPolicyId(String iamUserAccessPolicyId) {
        this.iamUserAccessPolicyId = iamUserAccessPolicyId;
    }

    public String getIamUserAccessPolicyName() {
        return iamUserAccessPolicyName;
    }

    public void setIamUserAccessPolicyName(String iamUserAccessPolicyName) {
        this.iamUserAccessPolicyName = iamUserAccessPolicyName;
    }

    public String getIamUserPwdPolicyId() {
        return iamUserPwdPolicyId;
    }

    public void setIamUserPwdPolicyId(String iamUserPwdPolicyId) {
        this.iamUserPwdPolicyId = iamUserPwdPolicyId;
    }

    public String getIamUserPwdPolicyName() {
        return iamUserPwdPolicyName;
    }

    public void setIamUserPwdPolicyName(String iamUserPwdPolicyName) {
        this.iamUserPwdPolicyName = iamUserPwdPolicyName;
    }

    public String getIamUserLoginGbaPolicyId() {
        return iamUserLoginGbaPolicyId;
    }

    public void setIamUserLoginGbaPolicyId(String iamUserLoginGbaPolicyId) {
        this.iamUserLoginGbaPolicyId = iamUserLoginGbaPolicyId;
    }

    public String getIamUserLoginGbaPolicyName() {
        return iamUserLoginGbaPolicyName;
    }

    public void setIamUserLoginGbaPolicyName(String iamUserLoginGbaPolicyName) {
        this.iamUserLoginGbaPolicyName = iamUserLoginGbaPolicyName;
    }

    public String getIamUserAuthenPolicyId() {
        return iamUserAuthenPolicyId;
    }

    public void setIamUserAuthenPolicyId(String iamUserAuthenPolicyId) {
        this.iamUserAuthenPolicyId = iamUserAuthenPolicyId;
    }

    public String getIamUserAuthenPolicyName() {
        return iamUserAuthenPolicyName;
    }

    public void setIamUserAuthenPolicyName(String iamUserAuthenPolicyName) {
        this.iamUserAuthenPolicyName = iamUserAuthenPolicyName;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Date getIamInductionTime() {
        return iamInductionTime;
    }

    public void setIamInductionTime(Date iamInductionTime) {
        this.iamInductionTime = iamInductionTime;
    }

    @Override
    public String toString() {
        return "UserBaseInfoExtendEntity{" +
                "id=" + id +
                ", pubUidid='" + pubUidid + '\'' +
                ", iamNation='" + iamNation + '\'' +
                ", iamGender='" + iamGender + '\'' +
                ", iamBirthday=" + iamBirthday +
                ", iamNationalitynationality='" + iamNationalitynationality + '\'' +
                ", iamReligion='" + iamReligion + '\'' +
                ", iamTelephone='" + iamTelephone + '\'' +
                ", iamPostaladdress='" + iamPostaladdress + '\'' +
                ", iamPostalcode='" + iamPostalcode + '\'' +
                ", iamFacsimilenumber='" + iamFacsimilenumber + '\'' +
                ", iamStarttime=" + iamStarttime +
                ", iamEndtime=" + iamEndtime +
                ", iamStatus=" + iamStatus +
                ", iamIdcardnumber='" + iamIdcardnumber + '\'' +
                ", iamEmployeenumber='" + iamEmployeenumber + '\'' +
                ", iamLevel='" + iamLevel + '\'' +
                ", iamLevelname='" + iamLevelname + '\'' +
                ", iamCategory='" + iamCategory + '\'' +
                ", iamEntrytime=" + iamEntrytime +
                ", iamPositionleven='" + iamPositionleven + '\'' +
                ", iamEmployeeBelongType=" + iamEmployeeBelongType +
                ", iamProvinces='" + iamProvinces + '\'' +
                ", iamLocationname='" + iamLocationname + '\'' +
                ", iamSupportrecorpname='" + iamSupportrecorpname + '\'' +
                ", iamSupporterdept='" + iamSupporterdept + '\'' +
                ", iamSupportercorpcontact='" + iamSupportercorpcontact + '\'' +
                ", iamSupervisor='" + iamSupervisor + '\'' +
                ", iamLockcause='" + iamLockcause + '\'' +
                ", iamCreateuserkey='" + iamCreateuserkey + '\'' +
                ", iamCreatedate=" + iamCreatedate +
                ", iamModifyuserkey='" + iamModifyuserkey + '\'' +
                ", iamModifydate=" + iamModifydate +
                ", iamDescr='" + iamDescr + '\'' +
                ", iamUserLockPolicyId='" + iamUserLockPolicyId + '\'' +
                ", iamUserLockPolicyName='" + iamUserLockPolicyName + '\'' +
                ", iamSinceTheMaintenancePolicyId='" + iamSinceTheMaintenancePolicyId + '\'' +
                ", iamSinceTheMaintenancePolicyName='" + iamSinceTheMaintenancePolicyName + '\'' +
                ", iamUserAccessPolicyId='" + iamUserAccessPolicyId + '\'' +
                ", iamUserAccessPolicyName='" + iamUserAccessPolicyName + '\'' +
                ", iamUserPwdPolicyId='" + iamUserPwdPolicyId + '\'' +
                ", iamUserPwdPolicyName='" + iamUserPwdPolicyName + '\'' +
                ", iamUserLoginGbaPolicyId='" + iamUserLoginGbaPolicyId + '\'' +
                ", iamUserLoginGbaPolicyName='" + iamUserLoginGbaPolicyName + '\'' +
                ", iamUserAuthenPolicyId='" + iamUserAuthenPolicyId + '\'' +
                ", iamUserAuthenPolicyName='" + iamUserAuthenPolicyName + '\'' +
                ", iamTempTelephone='" + iamTempTelephone + '\'' +
                ", iamTempTelephoneExpired=" + iamTempTelephoneExpired +
                ", iamInternalTrumpet='" + iamInternalTrumpet + '\'' +
                ", iamemployeeType='" + iamemployeeType + '\'' +
                ", isRove='" + isRove + '\'' +
                ", iamUserallowlogindate='" + iamUserallowlogindate + '\'' +
                ", iamUserlastlogondate='" + iamUserlastlogondate + '\'' +
                ", functionids='" + functionids + '\'' +
                ", functionNames='" + functionNames + '\'' +
                ", userName='" + userName + '\'' +
                ", userLoginName='" + userLoginName + '\'' +
                ", userLoginPassword='" + userLoginPassword + '\'' +
                ", vpnCode='" + vpnCode + '\'' +
                ", userAccount='" + userAccount + '\'' +
                ", userType='" + userType + '\'' +
                ", userOrg='" + userOrg + '\'' +
                ", userPosition='" + userPosition + '\'' +
                ", userTel='" + userTel + '\'' +
                ", userMail='" + userMail + '\'' +
                ", isAdmin=" + isAdmin +
                ", orgName='" + orgName + '\'' +
                ", userGroupName='" + userGroupName + '\'' +
                ", userGroupId='" + userGroupId + '\'' +
                ", iamUserLevel='" + iamUserLevel + '\'' +
                ", iamEmployeesAttribute='" + iamEmployeesAttribute + '\'' +
                ", iamAdministerSequence='" + iamAdministerSequence + '\'' +
                ", iamServerStartTime=" + iamServerStartTime +
                ", iamLaborContractUnit='" + iamLaborContractUnit + '\'' +
                ", iamHighestEducation='" + iamHighestEducation + '\'' +
                ", iamHighestEducationSchool='" + iamHighestEducationSchool + '\'' +
                ", iamHighestEducationSpecialty='" + iamHighestEducationSpecialty + '\'' +
                ", iamFullTimeEducation='" + iamFullTimeEducation + '\'' +
                ", iamFullTimeSchool='" + iamFullTimeSchool + '\'' +
                ", iamFullTimeSpecialty='" + iamFullTimeSpecialty + '\'' +
                ", iamWhetherFulltime='" + iamWhetherFulltime + '\'' +
                ", exportChild=" + exportChild + '\'' +
                ", iamInductionTime=" + iamInductionTime +
                '}';
    }
}