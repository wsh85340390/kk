package com.yiyongcloud.base.common.apilog.entity;

import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 日志实体类，方便后续接入ELK
 */
@Data
@ToString
public class ApiAccessLog {

    ////////// Info，日志基本信息//////////
    /**
     * 会话ID,目前为随机生成-- 原sessionId
     */
    private String logid;
    /**
     * 请求ID,事务跟踪ID,当多个  ---原 requestId
     */
    private String logtrans;

    /**
     * 租户ID
     */
    private String tenant;


    /**
     * 日志类型枚举 Request
     */
    private ApiAccessLog.TYPE log_type;

    ///////// Gather，日志产生或者采集者信息
    /**
     * 日志产生时间
     */
    private String gather_time;

    /**
     * 日志产生者名称或类型
     * 网关为：api_gateway
     * 其他为：项目组件名称，如portal
     */
    private String logger_type;

    /**
     * // 日志产生者地址
     */
    private String logger_ip;

    ///////When，日志发生时间
    /**
     * 日志创建时间
     */
    private String logtime;
    /**
     * 请求开始时间
     */
    private String request_time;
    /**
     * 请求结束时间
     */
    private String response_time;
    /**
     * 请求开始时间 long类型的时间戳  --用于 外部接口调用，统一时间格式
     */
    private Long request_time_sec;
    /**
     * 请求结束时间 long类型的时间戳   --用于 外部接口调用，统一时间格式
     */
    private Long response_time_sec;
    /**
     * 接口耗时，请求和响应（调用和返回直接的时间差，单位毫秒）
     */
    private Long taken_ms;

    // Who，调用者信息
    /**
     * 调用者APP信息  --- 补全引擎根据 此字段补全调用者信息
     * iam 前端调用：填写 JWT中的subject
     * rest 后端接口：填写 X-Auth-Param 的值
     */
    private String caller_id;

    /**
     * 调用者类型： 浏览器： browser    接口调用： restApi
     */
    private String caller_type;
    /**
     * 调用者扩展信息  ，浏览器时，填写浏览器的信息      接口调用时，填写调用方信息
     */
    private String caller_info;

    /**
     * 如果是操作日志，则调用者主帐号信息
     */
    private String user_id;


    //////// Where, 被调用者信息, 被访问者信息
    /**
     * 请求的服务名称,  被调用服务信息，类型和调用者一样都是APP结构
     */
    private String service_id;
    /**
     * 调用者或发起者源IP地址
     */
    private String sip;

    /**
     * 被调用者或访问目标IP地址
     */
    private String dip;
    /**
     * // 代理、中继、堡垒机IP地址，地址数组表示可以有多个代理
     */
    private List<String> proxy;

    /**
     * // 被调用者URI, 完整的uri 如： http://10.1.1.1:7100/auth
     */
    private String uri;

    ///////	// What，发生什么事
    /**
     * 如果有事务，则填写相同的事务ID值,如：JSESSION=1ABBCCDD
     */
    private String session_id;
    /**
     * // 协议，包括http, https, ssh
     */
    private String protocol;

    /**
     * 命令参数,  get 请求时，附加的参数
     */
    private String params;
    /**
     * 命令， 请求方式：GET,POST,PUT,
     */
    private String cmd;

    /**
     * 操作对象， 请求地址
     */
    private String obj;
    /**
     * 操作结果，http 响应状态码
     */
    private Integer result;
    /**
     * 请求参数，请求报文内容，json
     */
    private String request_body;
    /**
     * 响应参数，返回报文内容 ，json
     */
    private String response_body;


    /**
     * 真实的服务地址
     */
    private String real_access_url;


    public String pringProcessTimeCost() {
        StringBuilder costSB = new StringBuilder().append("==本次耗时：").append(this.taken_ms)
                .append(", 请求时间：").append(this.request_time).append(",返回时间：").append(this.response_time);
        return costSB.toString();
    }


    public ApiAccessLog() {
        this(ApiAccessLog.TYPE.api_log);
    }

    public ApiAccessLog(ApiAccessLog.TYPE log_type) {
        this.log_type = log_type;
        this.response_time_sec = System.currentTimeMillis();
    }

    /**
     * 日志级别枚举类
     */
    public static enum LEVEL {
        OFF,
        ERROR,
        WARN,
        INFO,
        DEBUG,
        TRACE,
        ALL;

        private LEVEL() {
        }
    }

    /**
     * 日志类型枚举
     */
    public static enum TYPE {
        REQUEST,
        RESPONSE,
        api_log,// 网关日志类型统一为api_log
        api_reverse_log,// 外部接口统一为api_reverse_log
        OUT;

        private TYPE() {
        }
    }
}
