package com.yiyongcloud.base.util.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import org.springframework.util.StringUtils;


/**
 * Description: 文件操作工具类<br>
 * Create Date: 2017年12月4日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author LanChao
 * @version 1.0
 */
public class FileOperateTools {

    /**
     * UTF-8编码
     */
    public static final String CHARSET_UTF8 = "UTF-8";

    /**
     * GBK编码
     */
    public static final String CHARSET_GBK = "GBK";

    private static String DEFAULT_CHARSET = CHARSET_GBK;

    /**
     * Definition:删除文件或文件夹以下所有的文件
     *
     * @param file 文件类
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static void deleteFile(File file) {
        if (file.exists()) {
            if (file.isFile()) {
                file.delete();
            }
            if (file.isDirectory()) {
                File[] files = file.listFiles();
                if (files != null && files.length > 0) {
                    for (File f : files) {
                        deleteFile(f);
                    }
                }
                file.delete();
            }
        }
    }

    /**
     * Definition:删除文件或文件夹以下所有的文件
     *
     * @param filePath 文件路径
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static void deleteFile(String filePath) {
        if (!filePath.endsWith(File.separator)) {
            filePath = filePath.concat(File.separator);
        }
        File file = new File(filePath);
        deleteFile(file);
    }


    /**
     * Definition:根据指定路径的文件夹遍历该文件下的所有文件 并放入fileList中
     *
     * @param folderPath
     * @param fileList
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static void listFile(String folderPath, List<File> fileList) {
        File dir = new File(folderPath);
        File[] files = dir.listFiles();
        if (files == null) {
            return;
        }
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                listFile(files[i].getAbsolutePath(), fileList);
            } else {
                fileList.add(files[i]);
            }
        }
    }


    /**
     * Definition:复制整个文件夹内容
     *
     * @param oldPath
     * @param newPath
     * @throws IOException
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static void copyFolder(String oldPath, String newPath) throws IOException {
        (new File(newPath)).mkdirs(); // 如果新文件夹不存在 则建立新文件夹
        String[] file = new File(oldPath).list(); // 旧路径下所有文件名 包括文件夹名
        File temp = null;
        if (file == null || file.length == 0) {
            return;
        }
        for (int i = 0; i < file.length; i++) {
            if (oldPath.endsWith(File.separator)) {
                temp = new File(oldPath + file[i]);
            } else {
                temp = new File(oldPath + File.separator + file[i]);
            }
            if (temp.isFile()) { // 如果是文件则拷贝到新路径下
                FileInputStream input = new FileInputStream(temp);
                FileOutputStream output = new FileOutputStream(newPath + File.separator + (temp.getName()).toString());
                byte[] b = new byte[1024 * 5];
                int len;
                while ((len = input.read(b)) != -1) {
                    output.write(b, 0, len);
                }
                output.flush();
                output.close();
                input.close();
            }
            if (temp.isDirectory()) {// 如果是文件夹 则递归调用该方法继续拷贝文件 直至全部拷贝完毕
                copyFolder(oldPath + File.separator + file[i], newPath + File.separator + file[i]);
            }
        }
    }


    /**
     * Definition:读取文本文件内容
     *
     * @param filePath    文本文件路径
     * @param charsetName 编码格式，默认GBK
     * @return
     * @throws Exception
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static String readTxtFileContent(String filePath, String charsetName) throws Exception {
        FileInputStream fis = new FileInputStream(filePath);
        return readTxtFileContent(fis, charsetName);
    }

    /**
     * Definition:读取文本文件内容
     *
     * @param file        文本文件
     * @param charsetName 编码格式，默认GBK
     * @return
     * @throws IOException
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static String readTxtFileContent(File file, String charsetName) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        return readTxtFileContent(fis, charsetName);
    }

    /**
     * Definition:读取文本文件内容
     *
     * @param in          FileInputStream流
     * @param charsetName 编码格式，默认GBK
     * @return
     * @throws IOException
     * @Author: LanChao
     * @Created date: 2014年12月2日
     */
    public static String readTxtFileContent(InputStream in, String charsetName) throws IOException {
        charsetName = StringUtils.isEmpty(charsetName) ? DEFAULT_CHARSET : charsetName;
        Reader reader = new BufferedReader(new InputStreamReader(in, charsetName));
        char[] readBuffer = new char[2048];
        StringBuffer buffer = new StringBuffer();
        int n;
        while ((n = reader.read(readBuffer)) > 0) {
            buffer.append(readBuffer, 0, n);
        }
        reader.close();
        return buffer.toString();
    }

    /**
     * Definition:写文本文件
     *
     * @param content     文本内容
     * @param destFile    目标文件
     * @param charsetName 文本编码
     * @throws Exception
     * @Author: LanChao
     * @Created date: 2017-8-9
     */
    public static void writeTxtFileContent(String content, File destFile, String charsetName) throws IOException {
        charsetName = StringUtils.isEmpty(charsetName) ? DEFAULT_CHARSET : charsetName;
        FileOutputStream output = new FileOutputStream(destFile);
        content = content == null ? "" : content;
        output.write(content.getBytes(charsetName));
        output.flush();
        output.close();
    }
}

	