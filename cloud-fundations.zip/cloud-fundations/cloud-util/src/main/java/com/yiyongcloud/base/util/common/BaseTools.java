package com.yiyongcloud.base.util.common;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.UUID;
import java.util.*;

/**
 * Description: 常用工具<br>
 * Create Date: 2019年8月22日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2018 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class BaseTools {
    private static Map<String, Boolean> checkStatusMap = new HashMap<String, Boolean>();

    private static DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.CHINA);
    private static SimpleDateFormat formatterT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    private static SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd");
    ;
    public static final int ascNum = 65;

    public static char num2Char(int num) {

        return (char) (num + ascNum);
    }

    static {
        checkStatusMap.put("1", true);
        checkStatusMap.put("true", true);
        checkStatusMap.put("开", true);
        checkStatusMap.put("开启", true);
    }

    /**
     * 将字符串用中括号括起来
     *
     * @param s 字符串
     * @return [s]
     */
    public static String wrapStringWithBracket(String s) {
        return "[" + s + "] ";
    }


    /**
     * 使用UUID生成RequestId
     *
     * @return RequestId
     */
    public static String requestIdWithUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * @param temp
     * @return
     */
    public static boolean isNull(Object temp) {
        if (temp == null) {
            return true;
        }
        if (temp instanceof String) {
            return isNull((String) temp);
        } else if (temp instanceof List) {
            return isNull((List) temp);
        } else if (temp instanceof Map) {
            return isNull((Map) temp);
        } else if (temp instanceof String[]) {
            return isNull((String[]) temp);
        }
        return false;
    }

    /**
     * @param temp
     * @return
     */
    public static boolean isNull(String[] temp) {
        if (temp == null) {
            return true;
        }
        if (temp.length == 0) {
            return true;
        }
        boolean isNullB = true;
        for (String item : temp) {
            if (!isNull(item)) {
                isNullB = false;
                break;
            }
        }
        return isNullB;
    }

    /**
     * 判断空字符串
     *
     * @param temp
     * @return
     */
    public static boolean isNull(String temp) {
        if (temp == null) {
            return true;
        }
        if ("null".equals(temp.toLowerCase())) {
            return true;
        }
        if ("".equals(temp.trim())) {
            return true;
        }
        return false;
    }

    /**
     * @param temp
     * @return
     */
    public static boolean isNull(List temp) {
        if (temp == null) {
            return true;
        }

        return (temp == null || temp.isEmpty());
    }

    /**
     * @param temp
     * @return
     */
    public static boolean isNull(Map temp) {
        return (temp == null || temp.isEmpty());
    }

    public static boolean isTrue(String temp) {
        if (checkStatusMap.containsKey(temp)) {
            return checkStatusMap.get(temp);
        } else {
            return false;
        }
    }

    /**
     * 拆分字符串
     *
     * @param str
     * @param split
     * @return
     */
    public static List<String> splistStr(String str, String splitIndex, boolean isRemoveSame) {
        List<String> rs = new ArrayList<String>();
        if (isNull(str) || isNull(splitIndex)) {
            return rs;
        }
        if (str.indexOf(splitIndex) >= 0) {
            String[] splitMul = str.split(splitIndex);
            if (isRemoveSame) {
                Map<String, String> keyMap = new HashMap<String, String>();
                for (String item : splitMul) {
                    if (keyMap.containsKey(item)) {
                        continue;
                    }
                    keyMap.put(item, null);
                    rs.add(item);
                }
            } else {
                for (String item : splitMul) {
                    rs.add(item);
                }
            }
        } else {
            rs.add(str);
        }

        return rs;
    }

    /**
     * 去掉前后空格字符串
     *
     * @param temp
     * @return
     */
    public static String getDefStr(Object temp) {
        if (temp == null) {
            return "";
        }
        String tempS = null;
        if (temp instanceof BigDecimal) {
            BigDecimal dbTemp = (BigDecimal) temp;
            tempS = dbTemp.toString();
        } else if (temp instanceof Date) {
            tempS = formatter.format(temp);
        } else {
            tempS = "" + temp;
        }

        if (tempS == null || "".equals(tempS.trim()) || "null".equals(tempS.trim().toLowerCase())) {
            return "";
        }
        return tempS.trim();
    }

    /**
     * @param temp
     * @return
     */
    public static Integer getIntDef0(Object temp) {
        if (isNull(temp)) {
            return 0;
        }
        if (temp instanceof BigDecimal) {
            return ((BigDecimal) temp).intValue();
        } else if (temp instanceof String) {
            String num = (String) temp;
            if (isNull(num)) {
                return 0;
            }
            num = num.trim();
            return Integer.parseInt(num);
        } else if (temp instanceof Double) {
            Double db = Double.parseDouble("" + temp);
            int b = db.intValue();
            return Integer.valueOf(b);

        } else if (temp instanceof Float) {
            Float db = Float.parseFloat("" + temp);
            int b = db.intValue();
            return Integer.valueOf(b);
        }
        return (Integer) temp;

    }

    /**
     * 判断两个字符串是否相等
     *
     * @param str1
     * @param str2
     * @return
     */
    public static boolean isSameStr(String str1, String str2, boolean isUp) {
        if (str1 == null && str2 == null) {
            return true;
        }
        if (str1 == null) {
            if (str2 != null) {
                return false;
            }

        }
        if (str2 == null) {
            if (str1 != null) {
                return false;
            }
        }
        if (isUp) {
            str1 = str1.toUpperCase();
            str2 = str2.toUpperCase();
        }
        return str1.equals(str2);
    }

    public static void linkMsg(StringBuffer msgSb, String msgContent, String splitIndex) {
        if (msgSb.length() > 0) {
            msgSb.append(splitIndex);
        }
        msgSb.append(msgContent);
    }

    public static String getEPrintStackTraceContent(Exception e) {
        String rs = null;
        if (isNull(e.getMessage())) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw, true));
            rs = sw.toString();
        } else {
            rs = e.getMessage();
        }
        rs = getDefStr(rs);
        return rs;
    }

    /**
     * Description: 将 map 的Key 转换为大写 再返回Map
     *
     * @param map
     * @return
     * @author Tangwenwu
     * @date 2021/04/06
     */
    public static Map<String, Object> mapToUpperKey(Map<String, Object> map) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            if (map == null || map.isEmpty()) {
                return resultMap;
            }
            map.keySet().stream().forEach(key -> resultMap.put(key.toUpperCase(), map.get(key)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultMap;
    }
}
