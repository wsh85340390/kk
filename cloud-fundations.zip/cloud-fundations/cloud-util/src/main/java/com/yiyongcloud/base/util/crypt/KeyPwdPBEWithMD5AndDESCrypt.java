package com.yiyongcloud.base.util.crypt;

import javax.crypto.*;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: 基于口令保护 实现文件加解密</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author liaowufeng
 * @version 1.0
 */

public class KeyPwdPBEWithMD5AndDESCrypt {
    /**
     * 构造函数
     */
    public KeyPwdPBEWithMD5AndDESCrypt() {
    }

    public static void main(String[] args) throws UnsupportedEncodingException {

//		KeyPwdPBEWithMD5AndDESCrypt pwdCrypt = CryptFactory
//				.createKeyPwdPBEWithMD5AndDESCrypt(CryptFactory.KEY_PWD_PBEWithMD5AndDES);
//
//		String s = "#$%^%&^$#$%^&$$qwetyyuttrr123468ujghhjuu5ythfrrdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"; // 密文只能是非汉字
//		String pwd = "liaolAb123445&*^$%^^gghhf+_)^%RE#FFGGfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffsssssssssssssssssssssssssssssssf"; //密码只能是非汉字
//
//		String s2 = pwdCrypt.cryptoDES(pwd, s);
//		String s3 = pwdCrypt.deCryptoDES(pwd, s2);
        //
        //         byte []data = s.getBytes();
        //
        //         byte []data2 = pwdCrypt.cryptoDES(pwd,data);
        //
        //         String s2 = new String(data2);
        //
        //         byte []data3 = s2.getBytes();
        //
        //
        //        byte []data4 = pwdCrypt.deCryptoDES(pwd,data3);
        //
        //        String   s4 = new String(data4);

        //           String st = "123lawf  去afdjsakdfjakdjdkasjfkasfs";
        //           byte []data1 = st.getBytes();
        //
        //           byte []data2 = (new String(data1)).getBytes();
        //
    }

    /**
     * 解密字符串
     *
     * @param key  String key字符串 , 只能为非汉字字符串
     * @param data String 要解密的字符串
     * @return String　成功，返回，解密后的字符串，失败，返回null
     */
    public String deCryptoDES(String key, String data) {
        //参数不正确，返回null
        if (data == null || key == null) {
            return null;
        }
        // 下面的过程为
        // String >> CharBuffer >> (编码处理)>> ByteBuffer >> byte[]数组 >> (加/解密处理) >> byte[]数组 >>(解码处理) >>CharBuffer>>char[]数组>>String
        // 编码
        byte[] datab = EncodeUtils.encode(data, "ISO-8859-1");
        if (datab == null) {
            return null;
        }
        // 解密
        byte[] datad = this.deCryptoDES(key, datab);
        if (datad == null) {
            return null;
        }
        // 解码
        String datae = DecodeUtils.decode(datad, "ISO-8859-1");
        return datae;
    }

    /**
     * 加密字符串
     *
     * @param key  String key字符串 , 只能为非汉字字符串
     * @param data String 要加密的字符串，只能为非汉字字符串
     * @return String 成功，返回，加密后的字符串，失败，返回null
     */
    public String cryptoDES(String key, String data) {
        if (key == null || data == null) {
            return null;
        }
        // 下面的过程为
        // String >> CharBuffer >> (编码处理)>> ByteBuffer >> byte[]数组 >> (加/解密处理) >> byte[]数组 >>(解码处理) >>CharBuffer>>char[]数组>>String
        // 编码
        byte[] datab = EncodeUtils.encode(data, "ISO-8859-1");
        if (datab == null) {
            return null;
        }
        byte[] datad = this.cryptoDES(key, datab);
        if (datad == null) {
            return null;
        }
        // 解码
        String datae = DecodeUtils.decode(datad, "ISO-8859-1");
        return datae;
    }

    /**
     * 加密byte数组
     *
     * @param key  String
     * @param data byte[]
     * @return byte[]
     */
    public byte[] cryptoDES(String key, byte[] data) {
        // 参数不正确，返回 null
        if (data == null || key == null) {
            return null;
        }
        char[] passwd = key.toCharArray();

        PBEKeySpec pbks = new PBEKeySpec(passwd);
        try {
            //获取加密key
            SecretKeyFactory kf = SecretKeyFactory
                    .getInstance("PBEWithMD5AndDES");
            SecretKey k = kf.generateSecret(pbks);
            //产生一个随机盐，为了使相同的密码，每个产生不同的加密串
            byte[] salt = new byte[8];
            Random r = new Random();
            r.nextBytes(salt);
            Cipher cp = null;
            //取加密算法
            cp = Cipher.getInstance("PBEWithMD5AndDES");
            PBEParameterSpec ps = new PBEParameterSpec(salt, 1000);
            cp.init(Cipher.ENCRYPT_MODE, k, ps);
            byte[] ctext = null;
            //加密
            ctext = cp.doFinal(data);
            //将随机盐放入加字串中保存，解密需要此随机盐
            byte[] cdata = new byte[salt.length + ctext.length];
            System.arraycopy(salt, 0, cdata, 0, salt.length);
            System.arraycopy(ctext, 0, cdata, salt.length, ctext.length);
            return cdata;
        } catch (NoSuchPaddingException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (NoSuchAlgorithmException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (InvalidKeySpecException ex1) {
            ex1.printStackTrace();
            return null;
        } catch (InvalidAlgorithmParameterException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (InvalidKeyException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (BadPaddingException ex) {
            ex.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException ex) {
            ex.printStackTrace();
            return null;
        } catch (IllegalStateException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * 解密byte数组
     *
     * @param key  String
     * @param data byte[]
     * @return byte[]
     */
    public byte[] deCryptoDES(String key, byte[] data) {
        //参数不正确，返回null
        if (data == null || key == null) {
            return null;
        }
        char[] passwd = key.toCharArray();
        PBEKeySpec pbks = new PBEKeySpec(passwd);
        try {
            //取解密key
            SecretKeyFactory kf = SecretKeyFactory
                    .getInstance("PBEWithMD5AndDES");
            SecretKey k = null;
            k = kf.generateSecret(pbks);
            //从加密串中取随机盐
            byte[] salt = new byte[8];
            byte[] cdata = new byte[data.length - salt.length];
            System.arraycopy(data, 0, salt, 0, salt.length);
            System.arraycopy(data, salt.length, cdata, 0, cdata.length);
            //取解密算法
            Cipher cp = null;
            cp = Cipher.getInstance("PBEWithMD5AndDES");
            PBEParameterSpec ps = new PBEParameterSpec(salt, 1000);
            cp.init(Cipher.DECRYPT_MODE, k, ps);
            byte[] ddata = null;
            //解密
            ddata = cp.doFinal(cdata);
            return ddata;
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
            return null;
        } catch (InvalidKeySpecException ex1) {
            ex1.printStackTrace();
            return null;
        } catch (NoSuchPaddingException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (InvalidAlgorithmParameterException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (InvalidKeyException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (BadPaddingException ex4) {
            ex4.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException ex4) {
            ex4.printStackTrace();
            return null;
        } catch (IllegalStateException ex4) {
            ex4.printStackTrace();
            return null;
        }
    }
}
