package com.yiyongcloud.base.util.crypt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;


/**
 * Description: 加解密工具类<br>
 * Create Date: 2022年1月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
@Component
public class CryptoTools {

    /**
     * 配置中心配置的加解密方式
     */
    @Value("AES")
    private String cryptType;

    /**
     * 访问认证信息配置的加解密密钥
     */
    @Value("T1NiZVBJNHAyRHd3ZFg5b0hjZWs2Zz09")
    private String key;


    /**
     * 秘钥链表更新接口
     */
    private SyskeyCollector syskeyCollector;


    public CryptoTools() {

    }

    /**
     * Description: 使用配置中心配置的加解密算法及密钥加密<br>
     * Created date: 2017年12月14日
     *
     * @param ori
     * @return
     * @author LanChao
     */
    public String encode(String ori) {
        //对密钥进行解密
        String decodeKey = SecetKeyUtils.decodeKey(key);
        return encode(cryptType, decodeKey, ori);
    }

    /**
     * Description: 使用配置中心配置的加解密算法及密钥解密<br>
     * Created date: 2017年12月14日
     *
     * @param ori
     * @return
     * @author LanChao
     */
    public String decode(String ori) {
        //对密钥进行解密
        String decodeKey = SecetKeyUtils.decodeKey(key);
        return decode(cryptType, decodeKey, ori);
    }

    /**
     * Description: 使用指定的加解密算法及密钥加密<br>
     * Created date: 2017年12月14日
     *
     * @param cryptType
     * @param key
     * @param ori
     * @return
     * @author LanChao
     */
    public String encode(String cryptType, String key, String ori) {
        Crypto c = CryptoFactory.createCrypto(cryptType);
        return c.desgo(ori, key, true);
    }

    /**
     * Description: 使用指定的加解密算法及密钥解密<br>
     * Created date: 2017年12月14日
     *
     * @param cryptType
     * @param key
     * @param ori
     * @return
     * @author LanChao
     */
    public String decode(String cryptType, String key, String ori) {
        Crypto c = CryptoFactory.createCrypto(cryptType);
        return c.desgo(ori, key, false);
    }

}
