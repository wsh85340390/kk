package com.yiyongcloud.base.util.crypt;

import java.util.Map;

/**
 * Description: 字符串加解密接口类<br>
 * Create Date: 2022年1月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public interface Crypto {


    /**
     * Definition: 字符串加解密方法
     *
     * @param in   要加密/解密的字符串
     * @param key  密钥（如算法不需要密钥则传空值）
     * @param type true为加密/false为解密
     * @return 加密或解密后的字符串
     * @Author: Tangwenwu
     * @Created date: 2014年12月12日
     */
    public String desgo(String in, String key, boolean type);

    /**
     * 初始化密钥
     * Definition:
     * author: Tangwenwu
     * Created date: May 16, 2013
     *
     * @param inMap
     * @param collector
     */
    public void init(Map<Integer, String> inMap, SyskeyCollector collector);


}

	