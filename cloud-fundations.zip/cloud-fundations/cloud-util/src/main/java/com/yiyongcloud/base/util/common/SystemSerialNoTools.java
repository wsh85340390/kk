package com.yiyongcloud.base.util.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Description:获取系统唯一标识工具类
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：LanChao
 * Create Date: 2016-9-12
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class SystemSerialNoTools {

    private static Logger logger = LoggerFactory.getLogger(SystemSerialNoTools.class);

    private static final String OS = System.getProperties().getProperty("os.name");

    /**
     * Definition:获得操作系统SN值
     *
     * @return
     * @Author: LanChao
     * @Created date: 2016-9-12
     */
    public static String getSn() {
        String sn = "";
        String cmd = null;
        if (OS.toLowerCase().contains("windows")) {
            cmd = "wmic bios get serialnumber /value";
        } else {
            cmd = "dmidecode -s system-serial-number";
        }
        logger.info("current os is " + OS + ", get sn cmd : " + cmd);
        BufferedReader in = null;
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            if (p == null) {
                return null;
            }
            in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String tmp = null;
            while ((tmp = in.readLine()) != null) {
                if (!"".equals(tmp)) {
                    sn += tmp;
                }
            }
            if (OS.toLowerCase().contains("windows")) {
                sn = sn.replace("SerialNumber=", "");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sn;
    }

}
