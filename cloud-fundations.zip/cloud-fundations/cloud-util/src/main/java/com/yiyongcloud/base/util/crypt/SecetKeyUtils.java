package com.yiyongcloud.base.util.crypt;

import java.util.Random;

/**
 * Description: 密钥操作类<br>
 * Create Date: 2017年12月15日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class SecetKeyUtils {

    private static final String KEY = "yycloud_ych#1hbl3qt";

    private static Crypto crypto = CryptoFactory.createCrypto(CryptoFactory.AES);

    /**
     * Description: 生成随机密钥<br>
     * Created date: 2017年12月15日
     *
     * @param length 密钥长度
     * @return
     * @author Tangwenwu
     */
    public static String generateKey(int length) {
        String val = "";
        char charOrNum = 'c';
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            charOrNum = random.nextInt(2) % 2 == 0 ? 'c' : 'n';
            if ('c' == charOrNum) {
                int upperOrletter = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char) (random.nextInt(26) + upperOrletter);
            } else {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }

    /**
     * Description: 对密钥进行加密<br>
     * Created date: 2017年12月15日
     *
     * @param ori
     * @return
     * @author Tangwenwu
     */
    public static String encodeKey(String ori) {
        return crypto.desgo(ori, KEY, true);
    }

    /**
     * Description: 对密钥解密<br>
     * Created date: 2017年12月15日
     *
     * @param ori
     * @return
     * @author Tangwenwu
     */
    public static String decodeKey(String ori) {
        return crypto.desgo(ori, KEY, false);
    }

    public static void main(String[] args) {
        String key = "1";
        String encodeKey = SecetKeyUtils.encodeKey(key);
        System.out.println("====对密钥加密=====" + encodeKey);
        System.out.println("====对密钥解密=====" + SecetKeyUtils.decodeKey(encodeKey));
    }
}
