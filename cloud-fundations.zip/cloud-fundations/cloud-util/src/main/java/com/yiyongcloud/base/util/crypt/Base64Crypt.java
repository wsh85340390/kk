package com.yiyongcloud.base.util.crypt;

import com.yiyongcloud.base.util.Constants;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Map;

/**
 * Description: BASE64字符串加解密 <br>
 * Create Date: 2017年11月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class Base64Crypt implements Crypto {

    private String decode(String str, String key) {
        if (str == null || "".equals(str)) {
            return null;
        }
        try {
            return new String(Base64.getDecoder().decode(str), Constants.CHARSET_UTF8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String encode(String str, String key) {
        if (str == null || "".equals(str)) {
            return null;
        }
        try {
            return Base64.getEncoder().encodeToString(str.getBytes(Constants.CHARSET_UTF8));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String desgo(String in, String key, boolean type) {
        if (type) {
            return this.encode(in, key);
        } else {
            return this.decode(in, key);
        }
    }

    @Override
    public void init(Map<Integer, String> inMap, SyskeyCollector collector) {
        // TODO Auto-generated method stub

    }

}