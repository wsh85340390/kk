package com.yiyongcloud.base.util.crypt;

import java.util.Map;

/**
 * Syskey收集器
 *
 * @author tanghedong
 */
public interface SyskeyCollector {

    /**
     * 收集Syskey,key 为sid,value 为syskey
     *
     * @return
     */
    public Map<Integer, String> collectSyskey();

}
