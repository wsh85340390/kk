package com.yiyongcloud.base.consumer.recognp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@ComponentScan(value = {
        "com.yiyongcloud.base.consumer.recognp",
        "com.yiyongcloud.base.client"})
@EnableFeignClients(basePackages = "com.yiyongcloud.base.client.psidecar") // 开启feign做远程调用

@SpringBootApplication
@EnableDiscoveryClient
public class StartRecognizeCallApp {

    private static Logger logger = LoggerFactory.getLogger(StartRecognizeCallApp.class);

    private static Environment env;

    @Autowired
    public void setEnv(Environment env) {
        StartRecognizeCallApp.env = env;
    }

    public static void main(String[] args) {
        SpringApplication.run(StartRecognizeCallApp.class, args);
        logger.info(String.format("application %s started on port %s", env.getProperty("spring.application.name"), env.getProperty("server.port")));
    }

    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/test/{token}")
    public String test(@PathVariable("token") String userName) {
        System.out.println("===========userName=="+userName);
        String templateForObjectt= restTemplate.getForObject("http://template/apilog/sidecar_tmp/tokendddd", String.class,userName);
        System.out.println("=========templateForObjectt========="+templateForObjectt);
        String result= restTemplate.getForObject("http://recogn-p-sidecar/apilog/sidecar_tmp/tokendddd", String.class,userName);
        System.out.println("=======sidecar==result========="+result);
        return result;
    }


    @GetMapping("/side_call")
    public String side_call() {
        String userName="汤文武====";
        System.out.println("===========userName=="+userName);
        String templateForObjectt= restTemplate.getForObject("http://template/apilog/sidecar_tmp/tokendddd", String.class,userName);
        System.out.println("=========templateForObjectt========="+templateForObjectt);
        String result= restTemplate.getForObject("http://recogn-p-sidecar/apilog/sidecar_tmp/tokendddd", String.class,userName);
        System.out.println("=======sidecar==result========="+result);
        return result;
    }

}
