package com.yiyongcloud.base.common.db.encrypt;

import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.RSA;

/**
 * 单要独打包出来，给现场部署使用。这个主就是拿到core包的密钥，然后进行加解密操作。
 * 现场的数据库/redis等信息的配置文件使用该加解密工具，该加解密工具无法加解密数据库存储的密码字段。
 * 数据库存储的值根据各产品定义的密钥来进行加解密
 *
 * @author tangww
 * @date 2021/4/7
 */
public class Encryptor {

    public final static String pubKey = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAIE7bjcCyvBZCkXIx6Imq1dv041oIRH6Dn+KFVHqY2sPiNfEUW5OnnHRJrWghVr5wITg+IxWf/ulfytfisHJAKMCAwEAAQ==";
    public final static String priKey = "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAgTtuNwLK8FkKRcjHoiarV2/TjWghEfoOf4oVUepjaw+I18RRbk6ecdEmtaCFWvnAhOD4jFZ/+6V/K1+KwckAowIDAQABAkA8g/jzd7JSZE+kKAYbz2HS2wHEqOs7gM4DOUUMi+asPfo6/JhEAP3gkWxncIWcw62hrao3C1aTnvYIa3OwoFahAiEAw3ztA577mPROytXnFpm/phKPi4go1p4aQrucGAbtTDMCIQCpPC/B/SBwJKrEPRxhzlZ4ZY+hlILVgqKarbJp1CAJ0QIhALoyRTZLuWzIVjwQXRlDvC0cRKksOWmiEXU6aMTh5CfNAiBzXbggwfHPAO/4fsBOXF7ODE3xlE/sRPWcBDTPt+9vQQIgOGj4YyOGenL/Rnm7/flr7ULPtWMZ09I6RUP6mxhgeDQ=";

    private final static RSA rsa = new RSA(priKey, pubKey);

    /**
     * 解密密码，解密失败返回null
     * 返回null更合理？
     *
     * @param text
     * @return
     */
    public static String decrypt(String text) {
        try {
            return rsa.decryptStr(text, KeyType.PublicKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 加密密码，加密失败返回原文
     *
     * @param text
     * @return
     */
    public static String encrypt(String text) {
        try {
            return rsa.encryptBase64(text, KeyType.PrivateKey);
        } catch (Exception e) {
            e.printStackTrace();
            return text;
        }
    }

    public static void main(String[] args) throws Exception {
        String mode = args[0];
        String text = args[1];
        if (mode.toLowerCase().startsWith("en")) {
            //加密
            String encodePassword = encrypt(text);
            System.out.println("encode rst:");
            System.out.println(encodePassword);
        } else {
            //解密
            String decodeResult = decrypt(text);
            System.out.println("decode rst:");
            System.out.println(decodeResult);
        }
    }
}
