# Changelog

这个项目的所有显著变化都将被记录在这个文件中。

## [1.0.2] - 2019-11-11

### 新增

* cloud-starters
	* cloud-core，AlarmEngineConfig加入配置
* cloud-gateway
	* 新增跨站脚本过滤规则
	
### 修复

* cloud-starters
	* cloud-core，修复动态数据源断网后重连报错问题
* cloud-license
	* 修复客户端在部分linux系统上无法正常获取硬件信息问题
	

### 修改

无


## [1.0.1] - 2019-10-28

### 新增

* cloud-starters
	* cloud-core，字典下拉框数据结构加入ID，以兼容审计要求
* cloud-license，新增License管理，包括验证端及License生成服务端
* cloud-gateway
	* 新增手机端登录接口白名单配置
	* 新增跨站脚本过滤规则

### 修复

* cloud-starters
	* cloud-core，EsSearchConfig加入自启动配置
	* cloud-starter-grayupgrade，修复灰度策略在k8s部署环境下失效问题
* cloud-gateway
	* 修复header过大导致无法正常请求的问题
	

### 修改

* cloud-starters
	* cloud-core，修改以jar包引用时，sigar lib库问题
* 其他
	* 修改helm chart脚本，以兼容NodePort服务类型


## [1.0] - 2019-10-08

### 新增

* cloud-starters
	* 告警引擎通用配置类文件
	* PoiUtils工具类，增加针对行的样式方法
    * 添加灰度策略自研框架cloud-starter-grayupgrade
    * 添加数据库自动初始化及版本控制框架cloud-starter-liquibase

* cloud-configserver，新增灰度策略配置界面及初始化表结构

### 修复

* cloud-starters
    * DateTools 修复不同操作系统下，日期格式化不一致问题


### 修改

* cloud-starters
    * cloud-starter-liquibase工具禁用命令行启动，防止部分工程重复执行数据初始化动作