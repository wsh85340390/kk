package com.yiyongcloud.base.consumer.recognp;


import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.yiyongcloud.base.client.psidecar.IRecognPmodeClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
@RequestMapping(value = "/tsc")
public class TestSideCarController {

    @Autowired
    IRecognPmodeClient iRecognPmodeClient;


    @RequestMapping(value = "/sidecarTmp", method = {RequestMethod.POST,RequestMethod.GET})
    public Map<String,String> sidecarTmp(){

        Map<String,String> statMap = iRecognPmodeClient.sidecarTmp("YYCloud");
        return statMap;
    }


    @RequestMapping(value = "/sidecar", method = {RequestMethod.POST,RequestMethod.GET})
    public Map<String,String> sidecar(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("uid","99999999");
        Map<String,String> statMap = iRecognPmodeClient.sidecarJson(jsonObject);
        return statMap;
    }

}
