package com.yiyongcloud.base.util.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.*;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.lang.NonNull;

/**
 * Description:IP操作工具类 Copyright (C) 2015 1yongcloud.com All Right Reserved.
 * Author：Tangwenwu Create Date: 2015年12月1日 Modified By： Modified Date： Why & What
 * is modified： Version 1.0
 */
public class IPHelper {

    private static Logger logger = LoggerFactory.getLogger(IPHelper.class);

    private static final String LOCALHOST = "127.0.0.1";

    private static final String ANYHOST = "0.0.0.0";

    private static final Pattern LOCAL_IP_PATTERN = Pattern.compile("127(\\.\\d{1,3}){3}$");

    private static final Pattern IP_PATTERN = Pattern.compile("\\d{1,3}(\\.\\d{1,3}){3,5}$");

    private static volatile InetAddress LOCAL_ADDRESS = null;

    private static final int RND_PORT_START = 30000;

    private static final int RND_PORT_RANGE = 10000;

    private static final Random RANDOM = new Random(System.currentTimeMillis());

    private static boolean isLocalHost(String host) {
        return host == null || host.length() == 0 || host.equalsIgnoreCase("localhost") || host.equals("0.0.0.0")
                || host.equals("0:0:0:0:0:0:0:1") || (LOCAL_IP_PATTERN.matcher(host).matches());
    }

    private static boolean isValidAddress(InetAddress address) {
        if (address == null || address.isLoopbackAddress()) {
            return false;
        }
        String name = address.getHostAddress();
        return (name != null && !ANYHOST.equals(name) && !LOCALHOST.equals(name) && IP_PATTERN.matcher(name).matches());
    }

    private static InetAddress getLocalAddress0() {
        InetAddress localAddress = null;
        try {
            localAddress = InetAddress.getLocalHost();
            if (isValidAddress(localAddress)) {
                return localAddress;
            }
        } catch (Throwable e) {
            logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
        }
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces != null) {
                while (interfaces.hasMoreElements()) {
                    try {
                        NetworkInterface network = interfaces.nextElement();
                        Enumeration<InetAddress> addresses = network.getInetAddresses();
                        if (addresses != null) {
                            while (addresses.hasMoreElements()) {
                                try {
                                    InetAddress address = addresses.nextElement();
                                    if (isValidAddress(address)) {
                                        return address;
                                    }
                                } catch (Throwable e) {
                                    logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
                                }
                            }
                        }
                    } catch (Throwable e) {
                        logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
                    }
                }
            }
        } catch (Throwable e) {
            logger.warn("Failed to retriving ip address, " + e.getMessage(), e);
        }
        logger.error("Could not get local host ip address, will use 127.0.0.1 instead.");
        return localAddress;
    }

    private static InetAddress getLocalAddress() {
        if (LOCAL_ADDRESS != null) {
            return LOCAL_ADDRESS;
        }
        InetAddress localAddress = getLocalAddress0();
        LOCAL_ADDRESS = localAddress;
        return localAddress;
    }

    private static String getLocalHost() {
        InetAddress address = getLocalAddress();
        return address == null ? LOCALHOST : address.getHostAddress();
    }


    private static int getRandomPort() {
        return RND_PORT_START + RANDOM.nextInt(RND_PORT_RANGE);
    }

    /**
     * Definition:获得可用端口
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2015年12月22日
     */
    public static int getAvailablePort() {
        ServerSocket ss = null;
        try {
            ss = new ServerSocket();
            ss.bind(null);
            return ss.getLocalPort();
        } catch (IOException e) {
            return getRandomPort();
        } finally {
            if (ss != null) {
                try {
                    ss.close();
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     * Definition:获取请求IP地址
     *
     * @param request
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年2月1日
     */
    public static String getRequestIp(HttpServletRequest request) {
        if (request == null) {
            return "request is null ";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (isLocalHost(ip)) {
            return LOCALHOST;
        }
        return ip;
    }

    public static String getIpAddress(ServerHttpRequest request) {
        HttpHeaders headers = request.getHeaders();
        String ip = headers.getFirst("x-forwarded-for");
        if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
            // 多次反向代理后会有多个ip值，第一个ip才是真实ip
            if (ip.indexOf(",") != -1) {
                ip = ip.split(",")[0];
            }
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddress().getAddress().getHostAddress();
        }
        return ip;
    }

    /**
     * Definition:ping一个地址是否网络可达<br>
     * 目前兼容windows和linux系统
     *
     * @param ip      IP地址或域名
     * @param count   要ping的次数
     * @param timeout 超时时间(s)
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月3日
     */
    public static boolean ping(String ip, int count, int timeout) {
        String os = System.getProperties().getProperty("os.name");
        StringBuffer cmdSb = new StringBuffer("ping ");
        if (os.toLowerCase().contains("windows")) {
            cmdSb.append(ip).append(" -n ").append(count).append(" -w ").append(timeout);
        } else {
            cmdSb.append(" -c ").append(count).append(" -w ").append(timeout).append(" ").append(ip);
        }
        logger.info("current os is " + os + ", ping cmd : " + cmdSb.toString());
        BufferedReader in = null;
        Runtime r = Runtime.getRuntime();
        try {
            Process p = r.exec(cmdSb.toString());
            if (p == null) {
                return false;
            }
            in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            int okCount = 0;
            String line = null;
            while ((line = in.readLine()) != null) {
                okCount += checkPingResult(line);
            }
            return okCount == count;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    /**
     * 增加是否打印日志
     *
     * @param ip
     * @param count
     * @param timeout
     * @param isLog
     * @return
     */
    public static boolean ping(String ip, int count, int timeout, boolean isLog) {
        String os = System.getProperties().getProperty("os.name");
        StringBuffer cmdSb = new StringBuffer("ping ");
        if (os.toLowerCase().contains("windows")) {
            cmdSb.append(ip).append(" -n ").append(count).append(" -w ").append(timeout);
        } else {
            cmdSb.append(" -c ").append(count).append(" -w ").append(timeout).append(" ").append(ip);
        }
        if (isLog) {
            logger.info("current os is " + os + ", ping cmd : " + cmdSb.toString());
        }
        BufferedReader in = null;
        Runtime r = Runtime.getRuntime();
        try {
            Process p = r.exec(cmdSb.toString());
            if (p == null) {
                return false;
            }
            in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            int okCount = 0;
            String line = null;
            while ((line = in.readLine()) != null) {
                okCount += checkPingResult(line, isLog);
            }
            return okCount == count;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    private static int checkPingResult(String line, boolean isLog) {
        if (isLog) {
            logger.info("ping result : " + line);
        }

        boolean matched = RegexTools.isMatched(line, "(?i)([\\d\\.]+ms\\s+ttl=\\d+)|(ttl=\\d+\\s+.+=[\\d\\.]+\\s*ms)");
        return matched ? 1 : 0;
    }

    private static int checkPingResult(String line) {
        logger.info("ping result : " + line);
        boolean matched = RegexTools.isMatched(line, "(?i)([\\d\\.]+ms\\s+ttl=\\d+)|(ttl=\\d+\\s+.+=[\\d\\.]+\\s*ms)");
        return matched ? 1 : 0;
    }

    /**
     * Definition:解析IPv4区间内所有的IP地址
     *
     * @param startIp 起始IP
     * @param endIp   结束IP
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月3日
     */
    public static List<String> parseIpv4Range(String startIp, String endIp) {
        List<String> list = new ArrayList<String>();
        int start = ip2int(startIp);
        int end = ip2int(endIp);
        for (int i = 0; i <= (end - start); i++) {
            list.add(int2ip(start + i));
        }
        return list;
    }

    /**
     * Definition:将IPv4转为网络字节序
     *
     * @param ip
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月3日
     */
    public static int ip2int(String ip) {
        if (ip == null || "".equals(ip) || !ip.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")) {
            return 0;
        }
        try {
            byte[] ips = InetAddress.getByName(ip).getAddress();
            return bytesToInt(ips);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private static int bytesToInt(byte[] bytes) {
        int a = 0;
        for (int i = bytes.length - 1; i >= 0; i--) {
            byte b = bytes[i];
            a += (b & 0xFF) << (8 * (3 - i));
        }
        return a;
    }

    /**
     * Definition:将网络字节序转换为IP地址
     *
     * @param ip
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月3日
     */
    public static String int2ip(int ip) {
        byte[] bytes = intToBytes(ip);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(bytes[i] & 0xFF);
            if (i < 3) {
                sb.append(".");
            }
        }
        return sb.toString();
    }

    private static byte[] intToBytes(int num) {
        byte[] b = new byte[4];
        for (int i = 0; i < 4; i++) {
            b[i] = (byte) (num >>> (24 - i * 8));
        }
        return b;
    }

    /**
     * Definition:验证IP区间是否合法，起始IP是否小于结束IP
     *
     * @param startIp 起始IP
     * @param endIp   结束IP
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月3日
     */
    public static boolean validateIpRange(String startIp, String endIp) {
        int start = ip2int(startIp);
        int end = ip2int(endIp);
        return start < end;
    }

    /**
     * Definition:判断一个IP是否在起始IP和结束IP之间
     *
     * @param startIp
     * @param endIp
     * @param validateIp
     * @return
     * @Author: Tangwenwu
     * @Created date: 2021年6月23日
     */
    public static boolean validateIpInRange(String startIp, String endIp, String validateIp) {
        int start = ip2int(startIp);
        int end = ip2int(endIp);
        int middle = ip2int(validateIp);
        return start < middle && middle < end;
    }


    public static final String IP_UNKNOWN = "unknown ip";


    /**
     * Definition:获取本机IP地址
     * --支持区分操作系统
     *
     * @return
     * @Author: Tangwenwu
     * @Created date: 2015年12月1日
     */

    public static String getLocalIp() {
        String os = System.getProperty("os.name");
        return os.toLowerCase().startsWith("win") ? getLocalIpFromWindows() : getLocalIpFromLinux();
    }

    public static String getMacAddr() {
        String MacAddress = "";
        StringBuilder str = new StringBuilder();

        try {
            NetworkInterface nic = NetworkInterface.getByName("eth0");
            byte[] buf = nic.getHardwareAddress();
            int length = buf.length;

            for (int i = 0; i < length; ++i) {
                byte aBuf = buf[i];
                str.append(byteHEX(aBuf));
            }

            MacAddress = str.toString().toUpperCase();
        } catch (SocketException e) {
            e.printStackTrace();
        }

        return MacAddress;
    }

    /**
     * 获取Linux服务器的本地IP
     *
     * @return IP
     */
    private static String getLocalIpFromLinux() {
        String ip = IP_UNKNOWN;

        try {
            Enumeration enumeration = NetworkInterface.getNetworkInterfaces();

            while (enumeration.hasMoreElements()) {
                NetworkInterface ni = (NetworkInterface) enumeration.nextElement();
                if (ni.getName().equals("eth0")) {
                    Enumeration addresses = ni.getInetAddresses();
                    while (true) {
                        if (!addresses.hasMoreElements()) {
                            break;
                        }

                        InetAddress ia = (InetAddress) addresses.nextElement();
                        if (!(ia instanceof Inet6Address)) {
                            ip = ia.getHostAddress();
                        }
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }

        if (IP_UNKNOWN.equals(ip)) {
            ip = getLocalIpFromWindows();
        }

        return ip;
    }

    private static String byteHEX(byte ib) {
        char[] Digit = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        char[] ob = new char[]{Digit[ib >>> 4 & 15], Digit[ib & 15]};
        return new String(ob);
    }

    /**
     * 获取Windows服务器的本地IP
     *
     * @return IP
     */
    private static String getLocalIpFromWindows() {
        String localIp;
        try {
            localIp = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            localIp = IP_UNKNOWN;
        }

        return localIp;
    }

    /**
     * 获取主机名
     *
     * @return 主机名
     */
    public static String getHostName() {
        String hostName;
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            hostName = "hostname";
        }
        return hostName;
    }

    /**
     * 获取客户端IP
     *
     * @param request ServerHttpRequest
     * @return 客户端IP
     */
    public static String getClientIp(@NonNull ServerHttpRequest request) {
        String result = null;
        HttpHeaders headers = request.getHeaders();
        if (headers.getFirst("X-Forwarded-For") != null) {
            result = headers.getFirst("X-Forwarded-For");
        } else if (headers.getFirst("Proxy-Client-IP") != null) {
            result = headers.getFirst("Proxy-Client-IP");
        } else if (headers.getFirst("WL-Proxy-Client-IP") != null) {
            result = headers.getFirst("WL-Proxy-Client-IP");
        } else if (headers.getFirst("HTTP_CLIENT_IP") != null) {
            result = headers.getFirst("HTTP_CLIENT_IP");
        } else if (headers.getFirst("X-Real-IP") != null) {
            result = headers.getFirst("X-Real-IP");
        }
        if (StringUtils.isBlank(result) || "unknown".equalsIgnoreCase(result)) {
            result = Objects.requireNonNull(request.getRemoteAddress()).getAddress().getHostAddress();
        }
        return result;
    }

    /**
     * 获取IP+主机名
     *
     * @return [IP+,+主机名]
     */
    public static String getIpWithBracketWrap() {
        return BaseTools.wrapStringWithBracket(getLocalIp() + "," + getHostName());
    }

    public static void main(String[] args) {
        System.out.println(getLocalIpFromWindows());
        System.out.println(getLocalIpFromLinux());
    }

}
