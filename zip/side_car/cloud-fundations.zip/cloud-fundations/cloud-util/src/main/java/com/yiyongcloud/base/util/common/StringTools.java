package com.yiyongcloud.base.util.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Description: 字符串校验类<br>
 * Create Date: 2018年12月26日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author YanXiufeng
 * @version 1.0
 */
public class StringTools {
    private static Logger logger = LoggerFactory.getLogger(StringTools.class.getName());

    /**
     * Description: 判断字符串中是否为数字<br>
     * Created date: 2018年12月26日
     *
     * @param str
     * @return
     * @author YanXiufeng
     */
    public static boolean isNumeric(String str) {
        String t = "[0-9]*";
        Pattern pattern = Pattern.compile(t);
        Matcher isNum = pattern.matcher(str);
        if (isNum.matches()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Description: 判断字符串是否为日期格式<br>
     * Created date: 2018年12月26日
     *
     * @param strDate
     * @return
     * @author YanXiufeng
     */
    public static boolean isDate(String strDate) {
        String t = "^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))(\\s(((0?[0-9])|([1-2][0-3]))\\:([0-5]?[0-9])((\\s)|(\\:([0-5]?[0-9])))))?$";
        Pattern pattern = Pattern
                .compile(t);
        Matcher m = pattern.matcher(strDate);
        if (m.matches()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Description: 验证字符串中是否含有中文<br>
     * Created date: 2018年12月26日
     *
     * @param s
     * @return
     * @author YanXiufeng
     */
    public static boolean chineseValid(String s) {
        int length = s.length();
        byte[] b;
        for (int i = 0; i < length; i++) {
            b = s.substring(i).getBytes();
            if ((b[0] & 0xff) > 128) {
                return true;
            }
        }
        return false;
    }

    /**
     * Definition: 验证手机号码、电话号码是否有效 手机号前面加86的情况也考虑 新联通 （中国联通+中国网通）手机号码开头数字
     * 130、131、132、145、155、156、185、186 新移动 （中国移动+中国铁通）手机号码开头数字
     * 134、135、136、137、138、139、147、150、151、152、157、158、159、182、183、187、188 新电信
     * 178、198
     * （中国电信 <http://baike.baidu.com/view/3214.htm>+中国卫通）手机号码开头数字
     * 133、153、189、180 座机： 3/4位区号（数字）+ “-” + 7/8位（数字）+ “-”+数字位数不限
     * 说明：“-”+数字位数不限；这段可有可无 author: yangfan Created date: Jul 24, 2012
     *
     * @param photo
     * @return
     */
    public static boolean checkphoto(String photo) {
        boolean isfirst = false;
        isfirst = false;
        if (photo
                .matches("(^[0-9]{3,4}-[0-9]{3,8}$)|^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|2|3|5|6|7|8|9]|178|198)\\d{8}$")) {
            isfirst = true;
        }
        // 第二规则 “-”+数字位数不限 和手机号前面加86的情况也考虑
        if (!isfirst) {
            if (photo
                    .matches("(^[0-9]{3,4}-[0-9]{3,8}-[0-9]{0,100}$)|^((\\+86)|(86))?(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|2|3|5|6|7|8|9]|178|198)\\d{8}$")) {
                isfirst = true;
            }
        }
        return isfirst;
    }
}
