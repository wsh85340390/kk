package com.yiyongcloud.base.util.common;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * Description: 工作日工具类<br>
 * Create Date: 2018年1月29日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.<br>
 *
 * @author LanChao
 * @version 1.0
 */
public class WorkDayTools {

    private static Logger logger = LoggerFactory.getLogger(WorkDayTools.class.getName());

    /**
     * Description: 获取指定年内的所有日期<br>
     * Created date: 2018年1月29日
     *
     * @param year
     * @return
     * @author LanChao
     */
    private static List<String> getYearDate(int year) {
        List<String> days = new ArrayList<String>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        // 指定年的开始天
        Calendar start = Calendar.getInstance();
        start.set(year, 0, 1);
        Long startTime = start.getTimeInMillis();
        // 指定年的结束天
        Calendar end = Calendar.getInstance();
        end.set(year, 11, 31);
        Long endTime = end.getTimeInMillis();
        // 每天的毫秒数
        Long oneDay = 1000 * 60 * 60 * 24L;
        Long time = startTime;
        while (time <= endTime) {
            days.add(df.format(new Date(time)));
            time += oneDay;
        }
        return days;
    }

    /**
     * Description: 调用API获取休息日和法定假日<br>
     * Created date: 2018年1月29日
     *
     * @param days
     * @return
     * @author LanChao
     */
    private static List<String> getRestDay(List<String> days) {
        List<String> restDays = new ArrayList<String>();
        for (String str : days) {
            String url = "http://api.goseek.cn/Tools/holiday?date=" + str.replaceAll("-", "");
            String result = request(url);
            if (StringUtils.isEmpty(result)) {
                continue;
            }
            System.out.println(str + " == " + result);
            JSONObject jo = JSON.parseObject(result);
            Integer flag = jo.getInteger("data");
            if (flag == 1 || flag == 2) {
                restDays.add(str);
            }
        }
        return restDays;
    }

    /**
     * Description: 调用接口查询<br>
     * Created date: 2018年1月29日
     *
     * @param httpUrl
     * @return
     * @author LanChao
     */
    private static String request(String httpUrl) {
        BufferedReader reader = null;
        String result = null;
        StringBuffer sbf = new StringBuffer();
        try {
            URL url = new URL(httpUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            InputStream is = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String strRead = null;
            while ((strRead = reader.readLine()) != null) {
                sbf.append(strRead);
                sbf.append("\r\n");
            }
            reader.close();
            result = sbf.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * Description: 生成某年的休息日json<br>
     * Created date: 2018年1月29日
     *
     * @param year
     * @return
     * @author LanChao
     */
    private static String getRestDaysJson(int year) {
        List<String> days = getYearDate(year);
        List<String> restDays = getRestDay(days);
        return JsonTools.obj2json(restDays);
    }

    /**
     * Description: 获取当年的休息日集合<br>
     * Created date: 2018年1月29日
     *
     * @return
     * @author LanChao
     */
    public static List<String> getCurrentYearRestDays() {
        DateFormat df = new SimpleDateFormat("yyyy");
        String year = df.format(new Date());
        String jsonFile = "restdays-" + year + ".json";
        try {
            InputStream in = WorkDayTools.class.getResourceAsStream(jsonFile);
            if (in == null) {
                logger.error("can`t find restdays file for year {}", year);
                return null;
            }
            String restDaysJson = FileOperateTools.readTxtFileContent(in, "UTF-8");
            return JsonTools.jsonarray2list(restDaysJson, String.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Description: 获得当前天前几个工作日日期<br>
     * Created date: 2018年1月29日
     *
     * @param last            前几个工作日
     * @param specialWorkDays 特殊工作日，比如统一窜休
     * @param specialRestDays 特殊休息日，比如统一窜休
     * @return yyyy-MM-dd日期集合
     * @author LanChao
     */
    public static List<String> getLastWorkDayStr(int last, List<String> specialWorkDays, List<String> specialRestDays) {
        List<String> restDaysOfYear = getCurrentYearRestDays();
        List<String> workDays = new ArrayList<>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        for (int i = 0; i < last; i++) {
            Date date = cal.getTime();
            String dateStr = df.format(date);
            if (checkIsRestDay(dateStr, restDaysOfYear, specialWorkDays, specialRestDays)) {
                i--;
            } else {
                workDays.add(dateStr);
            }
            cal.add(Calendar.DATE, -1);
        }
        return workDays;
    }

    /**
     * Description: 获得当前天前几个工作日日期<br>
     * Created date: 2018年1月29日
     *
     * @param last            前几个工作日
     * @param specialWorkDays 特殊工作日，比如统一窜休
     * @param specialRestDays 特殊休息日，比如统一窜休
     * @return 日期集合
     * @author LanChao
     */
    public static List<Date> getLastWorkDayDate(int last, List<String> specialWorkDays, List<String> specialRestDays) {
        List<String> restDaysOfYear = getCurrentYearRestDays();
        List<Date> workDays = new ArrayList<>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        for (int i = 0; i < last; i++) {
            Date date = cal.getTime();
            String dateStr = df.format(date);
            if (checkIsRestDay(dateStr, restDaysOfYear, specialWorkDays, specialRestDays)) {
                i--;
            } else {
                workDays.add(date);
            }
            cal.add(Calendar.DATE, -1);
        }
        return workDays;
    }

    /**
     * Description: 判断是否为休息日<br>
     * Created date: 2018年1月29日
     *
     * @param dateStr
     * @param restDaysOfYear
     * @param specialWorkDays
     * @param specialRestDays
     * @return
     * @author LanChao
     */
    private static boolean checkIsRestDay(String dateStr, List<String> restDaysOfYear,
                                          List<String> specialWorkDays, List<String> specialRestDays) {
        if (restDaysOfYear.contains(dateStr)) {
            if (specialWorkDays != null && specialWorkDays.contains(dateStr)) {
                return false;
            } else {
                //如果是法定休息日，且不是特殊加班日，则为休息日
                return true;
            }
        } else {
            if (specialRestDays != null && specialRestDays.contains(dateStr)) {
                //如果不是法定休息日，且是特殊休息日，则为休息日
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * Description: 获取当前天前几个工作日日期，供前端日期组件使用<br>
     * Created date: 2018年1月29日
     *
     * @param last            前几个工作日
     * @param specialWorkDays 特殊工作日，比如统一窜休
     * @param specialRestDays 特殊休息日，比如统一窜休
     * @return
     * @author LanChao
     */
    public static String getLastWorkDayForDatePicker(int last, List<String> specialWorkDays, List<String> specialRestDays) {
        Calendar cal = Calendar.getInstance();
        return getLastWorkDayForDatePicker(last, specialWorkDays, specialRestDays, cal);
    }

    /**
     * Description: 获取某天前几个工作日日期，供前端日期组件使用<br>
     * Created date: 2018年1月29日
     *
     * @param last            前几个工作日
     * @param specialWorkDays 特殊工作日，比如统一窜休
     * @param specialRestDays 特殊休息日，比如统一窜休
     * @param cal             指定日期起始值
     * @return
     * @author LanChao
     */
    public static String getLastWorkDayForDatePicker(int last, List<String> specialWorkDays, List<String> specialRestDays, Calendar cal) {
        List<String> restDaysOfYear = getCurrentYearRestDays();
        TreeSet<String> workDays = new TreeSet<>();
        TreeSet<String> restDays = new TreeSet<>();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        for (int i = 0; i < last; i++) {
            Date date = cal.getTime();
            String dateStr = df.format(date);
            if (checkIsRestDay(dateStr, restDaysOfYear, specialWorkDays, specialRestDays)) {
                i--;
                restDays.add(dateStr);
            } else {
                workDays.add(dateStr);
            }
            cal.add(Calendar.DATE, -1);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("startDate", workDays.first());
        map.put("endDate", workDays.last());
        map.put("datesDisabled", restDays);
        return JsonTools.obj2json(map);
    }

    public static void main(String[] args) {
//		String json = getRestDaysJson(2018);
        List<String> specialWorkDays = new ArrayList<>();
        specialWorkDays.add("2018-02-10");
        List<String> specialRestDays = new ArrayList<>();
        specialRestDays.add("2018-02-12");
        specialRestDays.add("2018-02-13");
        specialRestDays.add("2018-02-14");
        specialRestDays.add("2018-02-22");
        specialRestDays.add("2018-02-23");
        specialRestDays.add("2018-02-24");
        specialRestDays.add("2018-02-25");
        Calendar cal = Calendar.getInstance();
        cal.setTime(DateTools.parser("2018-08-27", "yyyy-MM-dd"));
        String json = getLastWorkDayForDatePicker(3, specialWorkDays, specialRestDays, cal);
        System.out.println(json);
    }
}
