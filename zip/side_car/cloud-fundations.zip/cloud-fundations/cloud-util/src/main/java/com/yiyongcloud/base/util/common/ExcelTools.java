package com.yiyongcloud.base.util.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFComment;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFName;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddressList;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

/**
 * Description:操作Excel工具类，采用JXL实现
 * Copyright (C) 2021 1yongcloud.com All Right Reserved.
 * Author：LanChao
 * Create Date: 2014年12月3日
 * Modified By：
 * Modified Date：
 * Why & What is modified：
 * Version 1.0
 */
public class ExcelTools {

    //模版输出支持
    HSSFWorkbook wb;
    //写入数据支持
    WritableWorkbook jxlwb;
    HSSFSheet sheet0;
    HSSFSheet sheet1;
    HSSFCellStyle style;
    String sheetName;
    List<String> titles;
    List<String> keys;

    /**
     * 输出map描述包含内容
     * String title;
     * String comment;
     * String[] dics;
     */
    List<Map<String, Object>> descriptions;
    /**
     * 等待写入的行数据
     */
    List<Map<String, Object>> values;

    public ExcelTools() {
        super();
        this.descriptions = new ArrayList<Map<String, Object>>();
    }

    /**
     * Definition:
     *
     * @param isPoi
     * @return
     * @Author: yaokunshan
     * @Created date: 2015年5月11日
     */
    private boolean init(boolean isPoi) {

        if (!isPoi) {
            return false;
        }
        this.wb = new HSSFWorkbook();

        this.style = wb.createCellStyle();

        this.sheet0 = wb.createSheet("new sheet");

        this.sheet1 = wb.createSheet("ShtDictionary");

        HSSFCellStyle style = wb.createCellStyle();

        HSSFFont font = wb.createFont();

        font.setFontName("宋体");

        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

        font.setFontHeightInPoints((short) 12);

        style.setFont(font);

        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);

        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);

        return true;

    }


    /**
     * 输出模版添加描述文件
     *
     * @param title   标题
     * @param comment 注释
     * @param dics    下拉选字典表
     */
    public void addDescriptions(String title, String comment, String[] dics) {

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("title", title);
        map.put("comment", comment);
        map.put("dics", dics);
        descriptions.add(map);
    }

    /**
     * 标准输出（sheet名称默认为“数据”）
     *
     * @param titles 标题头
     * @param values 行值
     */
    public void addDescriptions(List<String> titles, List<String> keys, List<Map<String, Object>> values) {

        for (String title : titles) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("title", title);
            map.put("comment", "");
            map.put("dics", null);
            descriptions.add(map);
        }
        this.keys = keys;
        this.titles = titles;
        if (sheetName == null) {
            this.sheetName = "data";
        }
        this.values = values;
    }

    public void addDescriptions(List<String> titles, List<String> comments, List<List<String>> dics, String sheetName) {
        for (int i = 0; i < titles.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("title", titles.get(i));
            map.put("comment", comments.get(i));
            map.put("dics", dics.get(i));
            descriptions.add(map);
        }
        this.keys = keys;
        this.titles = titles;
        this.sheetName = sheetName;
        if (sheetName == null) {
            this.sheetName = "data";
        }
    }

    /**
     * 带sheet名称定义
     *
     * @param sheetName sheet名称
     * @param titles    标题头
     * @param values    行值
     */
    public void addDescriptions(String sheetName, List<String> titles, List<String> keys, List<Map<String, Object>> values) {

        this.addDescriptions(titles, keys, values);

        this.sheetName = sheetName;
        if (sheetName == null) {
            this.sheetName = "data";
        }

    }

    /**
     * 导出数据
     *
     * @param os
     * @return
     * @throws IOException
     * @throws WriteException
     * @throws RowsExceededException
     * @throws Exception
     */
    public boolean exportData(OutputStream os)
            throws IOException, WriteException, RowsExceededException,
            Exception {

        init(false);

        jxlwb = Workbook.createWorkbook(os);
        //! 定义sheet名称
        //WritableSheet ws = jxlwb.createSheet(this.sheetName, 0);
        WritableSheet ws = jxlwb.createSheet("data", 0);

        //! 定义Excel行头
        for (int i = 0; i < this.descriptions.size(); i++) {
            WritableCell cell = new Label(i, 0, "" + descriptions.get(i).get("title"));
            WritableFont font1 = new WritableFont(WritableFont.TIMES,
                    12, WritableFont.BOLD);
            WritableCellFormat format1 = new WritableCellFormat(font1);
            cell.setCellFormat(format1);
            ws.addCell(cell);
        }
        //! 设置导出数据
        int i = 0;
        for (Map<String, Object> value : values) {
            for (int j = 0; j < keys.size(); j++) {
                WritableFont font1 = new WritableFont(WritableFont.TIMES,
                        12, WritableFont.NO_BOLD);
                WritableCellFormat format1 = new WritableCellFormat(font1);
                String text = String.valueOf(value.get(keys.get(j)));
                if (null == text || "null".equals(text)) {
                    text = "";
                }
                WritableCell cell = new Label(j, i + 1, text);
                cell.setCellFormat(format1);
                ws.addCell(cell);

            }
            i++;
        }
        jxlwb.write();
        jxlwb.close();
        return true;
    }

    /**
     * 实现模版导出业务逻辑
     *
     * @return
     */
    private boolean expTemp() {

        init(true);

        HSSFRow rowT = sheet0.createRow(0);

        for (int i = 0; i < descriptions.size(); i++) {

            Map msg = (Map) descriptions.get(i);

            String title = (String) msg.get("title");

            String comment = (String) msg.get("comment");

            String[] dics = (String[]) msg.get("dics");

            HSSFCell cell = rowT.createCell(i);

            cell.setCellValue(title);

            cell.setCellStyle(style);

            if (comment != null && !comment.isEmpty()) {
                HSSFComment commentCell = sheet0.createDrawingPatriarch()
                        .createComment(new HSSFClientAnchor(0, 0, 0, 0, (short) 4, 2, (short) 6, 6));

                commentCell.setString(new HSSFRichTextString(comment));
                commentCell.setAuthor("system");
                cell.setCellComment(commentCell);
            }

            sheet0.autoSizeColumn((short) i);

            if (dics == null || dics.length == 0) {
                continue;
            }
            // 生成代理字典
            for (int j = 0; j < dics.length; j++) {
                HSSFRow r = sheet1.getRow(j);
                if (r == null) {
                    r = sheet1.createRow(j);
                }
                HSSFCell c = sheet1.getRow(j).getCell(i);
                if (c == null) {
                    c = r.createCell(i);
                }
                c.setCellValue(dics[j]);
            }
            HSSFName range = wb.createName();
            String s = null;
            if (i < 26) {
                s = "ShtDictionary!$" + (char) (i + 65) + "$1:" + "$"
                        + (char) (i + 65) + "$" + dics.length;
            } else if (i >= 26 && i < 52) {
                s = "ShtDictionary!$A" + (char) (i + 65 - 26) + "$1:"
                        + "$A" + (char) (i + 65 - 26) + "$" + dics.length;
            } else if (i >= 52 && i < 999) {
                s = "ShtDictionary!$B" + (char) (i + 65 - 52) + "$1:"
                        + "$B" + (char) (i + 65 - 52) + "$" + dics.length;
            }
            //range.setReference(s);
            range.setNameName("ShtDictionary" + i);

            // 生成下拉列表
            CellRangeAddressList regions = new CellRangeAddressList(1,
                    65535, i, i);// (起始行序号，终止行序号，起始列序号，终止列序号)

            // 生成下拉框内容
            DVConstraint constraint = DVConstraint
                    .createFormulaListConstraint("ShtDictionary" + i);
            // 绑定下拉框和作用区域
            HSSFDataValidation data_validation = new HSSFDataValidation(
                    regions, constraint);
            // 对sheet页生效
            sheet0.addValidationData(data_validation);

        }
        return true;
    }

    /**
     * 数据导入
     *
     * @return
     */
    public List<Map> importData(InputStream is) {

        PoiUtils pu = new PoiUtils(is);

        return pu.excelToMapList(0);
    }


    /**
     * @return
     */
    public List<Map<String, Object>> getDescriptions() {
        return descriptions;
    }

    /**
     * TODO 未来根据实际使用情况进行添加
     * 添加描述
     *
     * @param titleAndValues 注释
     *                       集合
     */
    public void addDescriptions(LinkedHashMap<String, Collection> titleAndValues) {

    }

    /**
     * 导出模版
     *
     * @param map
     * @param out
     * @return
     */
    public boolean exportTemplate(OutputStream out) throws Exception {

        expTemp();
        try {
            wb.write(out);
            return true;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 模板导出方法-new
     *
     * @param titles    模板头标题
     * @param comments  标题描述，和模板头一一对应，没有描述增加空字符串""
     * @param dics      字典值，和模板头一一对应，没有字典值添加null
     * @param widths    列宽，和模板头一一对应
     * @param sheetName sheet名字
     */
    public void exportTemplate(List<String> titles, List<String> comments, List<List<String>> dics, List<Integer> widths, String sheetName) {
        init(true);
//		HSSFSheet sheet = wb.createSheet(sheetName);
//		HSSFSheet sheet1 = wb.createSheet("ShtDictionary");
        HSSFRow rowTitle = sheet0.createRow(0);
        for (int i = 0; i < titles.size(); i++) {

            String title = titles.get(i);

            String comment = comments.get(i);
//			如果字典值的List是null,则不生成字典下拉框
            List<String> dic = dics == null ? null : dics.get(i);

            HSSFCell cell = rowTitle.createCell(i);

            cell.setCellValue(title);

            cell.setCellStyle(style);

            if (comment != null && !comment.isEmpty()) {
                HSSFComment commentCell = sheet0.createDrawingPatriarch()
                        .createComment(new HSSFClientAnchor(0, 0, 0, 0, (short) 4, 2, (short) 6, 6));

                commentCell.setString(new HSSFRichTextString(comment));
                commentCell.setAuthor("system");
                cell.setCellComment(commentCell);
            }

//			sheet0.autoSizeColumn((short) i);

            if (dic == null || dic.size() == 0) {
                continue;
            }
            // 生成代理字典
            for (int j = 0; j < dic.size(); j++) {
                HSSFRow r = sheet1.getRow(j);
                if (r == null) {
                    r = sheet1.createRow(j);
                }
                HSSFCell c = sheet1.getRow(j).getCell(i);
                if (c == null) {
                    c = r.createCell(i);
                }
                c.setCellValue(dic.get(j));
            }
            HSSFName range = wb.createName();
            String s = null;
            if (i < 26) {
                s = "ShtDictionary!$" + (char) (i + 65) + "$1:" + "$"
                        + (char) (i + 65) + "$" + dic.size();
            } else if (i >= 26 && i < 52) {
                s = "ShtDictionary!$A" + (char) (i + 65 - 26) + "$1:"
                        + "$A" + (char) (i + 65 - 26) + "$" + dic.size();
            } else if (i >= 52 && i < 999) {
                s = "ShtDictionary!$B" + (char) (i + 65 - 52) + "$1:"
                        + "$B" + (char) (i + 65 - 52) + "$" + dic.size();
            }
//			range.setReference(s);
            range.setRefersToFormula(s);
            range.setNameName("ShtDictionary" + i);

            // 生成下拉列表
            CellRangeAddressList regions = new CellRangeAddressList(1,
                    65535, i, i);// (起始行序号，终止行序号，起始列序号，终止列序号)

            // 生成下拉框内容
            DVConstraint constraint = DVConstraint
                    .createFormulaListConstraint("ShtDictionary" + i);
            // 绑定下拉框和作用区域
            HSSFDataValidation data_validation = new HSSFDataValidation(
                    regions, constraint);
            // 对sheet页生效
            sheet0.addValidationData(data_validation);
        }
        if (widths != null && widths.size() == titles.size()) {
            for (int i = 0; i < widths.size(); i++) {
                Integer width = widths.get(i);
                sheet0.setColumnWidth(i, 256 * width);
            }
        }
    }

    /**
     * 导出模板或数据
     *
     * @param out
     * @return
     */
    public void export(OutputStream out) throws Exception {
        try {
            wb.write(out);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

    /**
     * Description: 导出模版或数据方法<br>
     * Created date: 2018年11月12日
     *
     * @param response
     * @param filePath
     * @author YanXiufeng
     */
    public void exportExcelTemp(HttpServletResponse response, String filePath) {
        response.addHeader("Content-disposition", "attachment;filename="
                + filePath.substring(filePath.lastIndexOf("\\") + 1));
        try {
            export(response.getOutputStream());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }


    public static void main(String[] args) {
        ExcelTools excelTools = new ExcelTools();
        System.out.println(excelTools.toString());
    }


}

	