package com.yiyongcloud.base.util.entity;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 操作对象信息<br>
 * Create Date: 2017年11月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
@ApiModel(value = "OperObject", description = "被批量操作的对象")
public class OperObject implements Serializable {

    private static final long serialVersionUID = -3924881193597008448L;

    /**
     * 操作对象ID
     */
    @ApiModelProperty(value = "操作对象ID")
    private String id;

    /**
     * 操作对象名
     */
    @ApiModelProperty(value = "操作对象名")
    private String name;

    public OperObject() {
    }

    public OperObject(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
