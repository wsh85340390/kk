package com.yiyongcloud.base.util.crypt;


/**
 * Created by IntelliJ IDEA.
 * User: liaowufeng
 * Date: 2006-6-15
 * Time: 19:10:02
 * To change this template use File | Settings | File Templates.
 * SDES加密,加密后不编码
 */
public class SDES2 {

    public static final boolean ENCRYPT = true; // 加密
    public static final boolean DECRYPT = false; // 解密

    /**
     * 使用3DES对字符串数据加解密
     *
     * @param in   String
     * @param key  String
     * @param type boolean
     * @return String
     */
    public String desgo(String in, String key, boolean type) {
        if (in == null || "".equals(in.trim())) {
            return "";
        }
        KeyPwdPBEWithMD5AndDESCrypt pwdCrypt = CryptoFactory
                .createKeyPwdPBEWithMD5AndDESCrypt(CryptoFactory.KEY_PWD_PBEWithMD5AndDES);

        if (type) {
            //加密
            return pwdCrypt.cryptoDES(key, in);
        } else {
            //解密
            return pwdCrypt.deCryptoDES(key, in);
        }
    }

    public String desgo(String in, boolean type) {
        if (in == null || "".equals(in.trim())) {
            return "";
        }
        KeyRandomPBEWithMD5AndDESCrypt pwdCrypt = CryptoFactory
                .createKeyRamdomPBEWithMD5AndDESCrypt(CryptoFactory.KEY_RANDOM_PBEWithMD5AndDES);

        if (type) {
            //加密
            return pwdCrypt.cryptoDES(in);
        } else {
            //解密
            return pwdCrypt.deCryptoDES(in);
        }
    }

}