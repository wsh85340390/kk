package com.yiyongcloud.base.util.crypt;

import java.util.Random;

/**
 * <p>Title: 加密与解密</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 *
 * @author unascribed
 * @version 1.0
 */

class EncryptPwd {

    byte pchDefKey[] = {'!', '#', '&', '<', '>', '_', '|', '~'};

    public EncryptPwd() {

    }

    byte byte2Hex(int k) {
        if (k > 9) {
            k = k - 10 + 'A';
        } else {
            k |= 0x30;
        }
        return (byte) k;
    }

    int hex2Byte(int h) {

        if (h < 65) {
            h -= 0x30;
        } else {
            h = h + 10 - 65;
        }
        return h;
    }

	/*public String byte2hex(byte[] b) //二行制转字符串
	  {
	   String hs="";
	   String stmp="";
	   for (int n=0;n<b.length;n++)
	    {
	     stmp=(java.lang.Integer.toHexString(b[n] & 0XFF));
	     if (stmp.length()==1) hs=hs+"0"+stmp;
	     else hs=hs+stmp;
	     if (n<b.length-1)  hs=hs+":";
	    }
	   return hs.toUpperCase();
	  }*/

    // get random key(8 byte)
    private byte[] generateKey() {

        Random ran = new Random();
        byte[] key = new byte[8];
        ran.nextBytes(key);
        return key;
    }

    // pchSrc: source string
    // pchKey: key
    // pchEncode: encoded string (the lenght is (16 + strlen(pchSrc)*2))
    // return:0 - success
    //        other values - failure
    private byte[] encode(byte[] pchSrc, byte[] pchKey) {
        if (pchSrc == null) {
            return null;
        }
        byte[] pchEncode = new byte[pchSrc.length * 2];
        int nLen = 0, nKeyLen = 0, i = 0, j = 0;
        if (pchSrc == null || pchKey == null || pchKey.length <= 0) {
            return null;
        }

        nLen = pchSrc.length;
        nKeyLen = pchKey.length;

        for (i = 0, j = 0; i < nLen; i++) {
            byte ch = pchSrc[i];
            ch += pchKey[i % nKeyLen];
            pchEncode[j++] = byte2Hex((ch >> 4) & 0xf);
            pchEncode[j++] = byte2Hex(ch & 0xf);
        }

        return pchEncode;
    }

    // pchEncoded: the encoded string
    // pchKey: key
    // pchDecoded: the decoded string
    // return:0 - success
    //        other values - failure
    private byte[] decode(byte[] pchEncoded, byte[] pchKey) {
        if (pchEncoded == null) {
            return null;
        }
        int nLen = 0;
        int nKeyLen = 0;
        int i = 0, j = 0;
        int decodedLength = pchEncoded.length / 2;
        byte[] pchDecoded = new byte[decodedLength];
        if (pchEncoded == null || pchKey == null || pchKey.length <= 0) {
            return null;
        }
        nLen = pchEncoded.length;
        nKeyLen = pchKey.length;

        for (i = 0, j = 0; i < nLen; i += 2) {
            int ch = ((hex2Byte(pchEncoded[i]) << 4) & 0xf0)
                    | hex2Byte(pchEncoded[i + 1]);
            int chK = pchKey[j % nKeyLen];
            ch -= chK;
            pchDecoded[j] = (byte) ch;
            j++;
        }

        return pchDecoded;
    }

    // chSrc: the source string
    // chEncoded: the encoded string
    // return:0 - success
    //        other values - failure
    public byte[] encodePwd(byte[] chSrc) {
        byte[] chEncoded = null;
        byte[] temp = null;
        byte[] result = null;
        byte chM[] = new byte[8];

        if (chSrc == null) {
            return null;
        }

        chM = generateKey();
        temp = encode(chM, pchDefKey);
        if (temp != null) {
            chEncoded = encode(chSrc, chM);
            result = new byte[chEncoded.length + 16];
            System.arraycopy(temp, 0, result, 0, temp.length);
            System.arraycopy(chEncoded, 0, result, temp.length,
                    chEncoded.length);
        }
        return result;

    }

    public byte[] decodePwd(byte[] chEncoded) {
        if (chEncoded == null) {
            return null;
        }
        if (chEncoded.length < 16) {
            return null;
        }
        byte temp[] = new byte[chEncoded.length - 16];
        byte chDecoded[] = new byte[(chEncoded.length - 16) / 2];

        byte chEM[] = new byte[16];
        byte chM[] = new byte[8];
        System.arraycopy(chEncoded, 0, chEM, 0, 16);
        chM = decode(chEM, pchDefKey);
        if (chM != null) {
            System.arraycopy(chEncoded, 16, temp, 0, chEncoded.length - 16);
            chDecoded = decode(temp, chM);
        }
        return chDecoded;
    }

}
