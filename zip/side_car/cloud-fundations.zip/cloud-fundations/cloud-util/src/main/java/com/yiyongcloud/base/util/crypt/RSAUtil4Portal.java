package com.yiyongcloud.base.util.crypt;

import java.math.BigInteger;

/**
 * Description: RSA算法，实现针对前端传输敏感数据的加密解密。<br>
 * Create Date: 2018年11月13日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2018 1yongcloud.com All Right Reserved.<br>
 *
 * @author ZhaoHongqun
 * @version 1.0
 */
public class RSAUtil4Portal {
    public static final int N = 2773;
    public static final int E = 63;
    public static final int D = 847;
    public static final String RSA_KEY = "RSA_KEY";
    private static final String SEL_SRC = "GHIJKLMNOPQRSTUVWXYZ_=!@%(){}|<>/?+-";
    private static final String REGEX = "[(G-Z)_\\=\\!@\\%\\(\\)\\{\\}\\|\\<\\>\\/\\?\\+-]{6}";

    /**
     * Description: 解密<br>
     * Created date: 2018年11月13日
     *
     * @param code
     * @return
     * @author ZhaoHongqun
     */
    public static String decrypt(String code) {
        return decrypt(N, E, code);
    }

    private static String decrypt(int n, int e, String code) {
        String result = "";
        String[] hexes = code.trim().split(REGEX);
        for (int i = 1; i < hexes.length; i++) {
            String hex = hexes[i];
            BigInteger b = new BigInteger(hex, 16);
            b = b.pow(e).mod(new BigInteger(String.valueOf(n)));
            int in = bytes2Int(b.toByteArray());
            result += (char) in;
        }
        return result;
    }

    /**
     * Description: 加密<br>
     * Created date: 2018年11月13日
     *
     * @param code
     * @return
     * @author ZhaoHongqun
     */
    public static String encrypt(String code) {
        return encrypt(N, D, code.toCharArray());
    }

    private static String encrypt(int n, int d, char[] chars) {
        String code = "";
        for (char c : chars) {
            BigInteger big = new BigInteger(String.valueOf((int) c));
            big = big.pow(d).mod(new BigInteger(String.valueOf(n)));
            byte[] bs = big.toByteArray();
            int in = bytes2Int(bs);
            for (int i = 0; i < 6; i++) {
                int x = (int) Math.floor(Math.random() * SEL_SRC.length());
                code += SEL_SRC.charAt(x);
            }
            code += Integer.toHexString(in).toUpperCase();
        }
        for (int i = 0; i < 6; i++) {
            int x = (int) Math.floor(Math.random() * SEL_SRC.length());
            code += SEL_SRC.charAt(x);
        }
        return code;
    }

    private static int bytes2Int(byte[] bs) {
        int i = 0;
        for (byte b : bs) {
            i = (i << 8) + (b & 0xff);
        }
        return i;
    }

}