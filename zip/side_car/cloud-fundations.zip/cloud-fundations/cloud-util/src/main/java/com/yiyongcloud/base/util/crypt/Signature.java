package com.yiyongcloud.base.util.crypt;

import org.apache.commons.codec.binary.Hex;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

/**
 * Description: AES加解密算法类
 * Copyright (C) 2013 yiyongcloud.com All Right Reserved.
 * createDate：  2022.1.28
 *
 * @version 1.0
 * @author：Tangwenwu
 */

public class Signature {
    private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";

    private static final String ENCODING = "UTF-8";


    private static final String appSecretKey = "YYCloud1644286723584";

    /**
     * 使用 HmacSHA1 对数据进行加密签名，然后转换为base64格式
     * * @param data
     * The data to be signed.
     *
     * @param key The signing key.
     * @return The Base64-encoded RFC 2104-compliant HMAC signature.
     * @throws java.security.SignatureException when signature generation fails
     */
    public static String calculateRFCHMAC(String key, String data) {
        String result;
        try {
            SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(ENCODING), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes(ENCODING));
            System.out.println(":::::::" + rawHmac);
            result = Base64.getEncoder().encodeToString(rawHmac);
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }

    /**
     * 使用 HmacSHA1 对数据进行加密签名，16进制表示格式的字符串，然后转换为base64格式
     * * @param data
     * The data to be signed.
     *
     * @param key The signing key.
     * @return The Base64-encoded RFC 2104-compliant HMAC signature.
     * @throws java.security.SignatureException when signature generation fails
     */
    public static String calculateRFCHMAC_Hex(String key, String data) {
        String result;
        try {
            SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(ENCODING), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes(ENCODING));
            result = Hex.encodeHexString(rawHmac);
            System.out.println("::::hex after:::" + result);
            result = Base64.getEncoder().encodeToString(result.getBytes());
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate HMAC Hex : " + e.getMessage());
        }
        return result;
    }

    // 与 calculateRFCHMAC_Hex 方法一致
    @Deprecated
    public static String hmacSHA1Encrypt(String encryptText, String encryptKey) throws Exception {
        String result;
        byte[] encryptKeyData = encryptKey.getBytes(ENCODING);//将密钥转换为utf-8编码的byte型数据
        byte[] encryptTextData = encryptText.getBytes(ENCODING);//将加密字符串转换为utf-8编码的byte型数据
        SecretKey secretKey = new SecretKeySpec(encryptKeyData, HMAC_SHA1_ALGORITHM);//公共秘钥指定一个算法名称，生成一个加密秘钥
        Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);//指定算法名称初始化mac算法
        mac.init(secretKey);//用生成的公共秘钥串初始化加密算法
        byte[] hmacsha1Data = mac.doFinal(encryptTextData);//对加密字符串进行加密转换
        result = Hex.encodeHexString(hmacsha1Data);
        System.out.println("::hmacSHA1Encrypt::hex after:::" + result);
        result = Base64.getEncoder().encodeToString(result.getBytes());
        return result;
    }

    public static void main(String[] args) {
        String uri = "/dss/rest/data/recv";

        String url = new StringBuilder().append(uri).append("#").append("1644293958662").toString();
        String signInfo = Signature.calculateRFCHMAC(appSecretKey, url);

        String signInfo_hex = Signature.calculateRFCHMAC_Hex(appSecretKey, url);
        System.out.println(signInfo);

        System.out.println(signInfo_hex);

        try {

            String token = Signature.hmacSHA1Encrypt(url,
                    appSecretKey);
            ;
            System.out.println("---------------" + token);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
