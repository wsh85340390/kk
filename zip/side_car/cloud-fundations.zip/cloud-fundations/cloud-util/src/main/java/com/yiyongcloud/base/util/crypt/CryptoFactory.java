package com.yiyongcloud.base.util.crypt;

import java.util.Map;

/**
 * Description: 加解密算法工厂<br>
 * Create Date: 2017年11月24日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C) 2017 1yongcloud.com All Right Reserved.<br>
 *
 * @author Tangwenwu
 * @version 1.0
 */
public class CryptoFactory {
    /**
     * 采用AES加密算法
     */
    public static String AES = "AES";
    /**
     * 采用sdes加密算法类
     */
    public static String SDES = "SDES";
    /**
     * BASE64编码
     */
    public static final String BASE64 = "BASE64";
    /**
     * 3DES with BASE64
     * 与总线的加解密方式
     */
    public static final String THREE_DES_BASE64 = "3desbase64";

    /**
     * 基于口令保护 实现加解密
     */
    public static String KEY_PWD_PBEWithMD5AndDES = "KEY_PWD_PBEWithMD5AndDES";

    /**
     * 基于随机口令保护 实现加解密
     */
    public static String KEY_RANDOM_PBEWithMD5AndDES = "KEY_RANDOM_PBEWithMD5AndDES";

    /**
     * 基于口令的DES加解密
     */
    private static KeyPwdPBEWithMD5AndDESCrypt keyPwdPBEWithMD5AndDESCrypt = new KeyPwdPBEWithMD5AndDESCrypt();

    /**
     * 基于口令的DES加解密
     */
    private static KeyRandomPBEWithMD5AndDESCrypt keyRandomPBEWithMD5AndDESCrypt = new KeyRandomPBEWithMD5AndDESCrypt();

    /**
     * 创建加密算法的工厂函数
     * Definition:
     * author: Tangwenwu
     * Created date: May 16, 2013
     *
     * @param cryptType 如果类型为空，默认为AES算法加密
     * @return
     */
    public static Crypto createCrypto(String cryptType) {
        if (BASE64.equals(cryptType)) {
            return new Base64Crypt();
        } else if (THREE_DES_BASE64.equals(cryptType)) {
            return new ThreeDesBase64();
        } else if (AES.equals(cryptType)) {
            return new AES();
        } else if (SDES.equals(cryptType)) {
            return new SDES();
        } else {
            return new AES();
        }
    }

    /**
     * Definition:创建带自动加载密钥的加解密工具类
     *
     * @param inMap     密钥MAP
     * @param collector 获取密钥的接口实现
     * @param cryptType 算法类型
     * @return
     * @Author: Tangwenwu
     * @Created date: 2015年6月5日
     */
    public static Crypto createCrypto(Map<Integer, String> inMap,
                                      SyskeyCollector collector, String cryptType) {
        Crypto en = null;
        if (BASE64.equals(cryptType)) {
            en = new Base64Crypt();
        } else if (THREE_DES_BASE64.equals(cryptType)) {
            en = new ThreeDesBase64();
        } else if (AES.equals(cryptType)) {
            en = new AES();
        } else if (SDES.equals(cryptType)) {
            en = new SDES();
        } else {
            en = new AES();
        }
        if (en != null) {
            en.init(inMap, collector);
        }
        return en;
    }


    /**
     * 取基于口令的DES加解密
     *
     * @param type String
     * @return KeyPwdPBEWithMD5AndDESCrypt
     */
    public static KeyPwdPBEWithMD5AndDESCrypt createKeyPwdPBEWithMD5AndDESCrypt(
            String type) {
        if (KEY_PWD_PBEWithMD5AndDES.equals(type)) {
            return keyPwdPBEWithMD5AndDESCrypt;
        }
        return null;
    }

    public static KeyRandomPBEWithMD5AndDESCrypt createKeyRamdomPBEWithMD5AndDESCrypt(
            String type) {
        if (KEY_RANDOM_PBEWithMD5AndDES.equals(type)) {
            return keyRandomPBEWithMD5AndDESCrypt;
        }
        return null;
    }

}
