package com.yiyongcloud.base.util.crypt;

import javax.crypto.*;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: 基于随机口令保护 实现加解密</p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: </p>
 *
 * @author liaowufeng
 * @version 1.0
 */
public class KeyRandomPBEWithMD5AndDESCrypt {
    /**
     * 构造函数
     */
    public KeyRandomPBEWithMD5AndDESCrypt() {
    }

    /**
     * 解密字符串
     *
     * @param key  String key字符串 , 只能为非汉字字符串
     * @param data String 要解密的字符串
     * @return String　成功，返回，解密后的字符串，失败，返回null
     */
    public String deCryptoDES(String data) {

        // 下面的过程为
        // String >> CharBuffer >> (编码处理)>> ByteBuffer >> byte[]数组 >> (加/解密处理) >> byte[]数组 >>(解码处理) >>CharBuffer>>char[]数组>>String
        // 编码
        byte[] datab = EncodeUtils.encode(data, "ISO-8859-1");
        if (datab == null) {
            return null;
        }
        // 解密
        byte[] datad = this.deCryptoDES(datab);
        if (datad == null) {
            return null;
        }
        // 解码
        String datae = DecodeUtils.decode(datad, "ISO-8859-1");
        return datae;
    }

    /**
     * 加密字符串
     *
     * @param key  String key字符串 , 只能为非汉字字符串
     * @param data String 要加密的字符串，只能为非汉字字符串
     * @return String 成功，返回，加密后的字符串，失败，返回null
     */
    public String cryptoDES(String data) {
        // 下面的过程为
        // String >> CharBuffer >> (编码处理)>> ByteBuffer >> byte[]数组 >> (加/解密处理) >> byte[]数组 >>(解码处理) >>CharBuffer>>char[]数组>>String
        // 编码
        byte[] datab = EncodeUtils.encode(data, "ISO-8859-1");
        if (datab == null) {
            return null;
        }
        byte[] datad = this.cryptoDES(datab);
        if (datad == null) {
            return null;
        }
        // 解码
        String datae = DecodeUtils.decode(datad, "ISO-8859-1");
        return datae;
    }

    /**
     * @param len int
     * @return String
     */
    //    private  String generateRandomKey(int len){
    //        Random r = new Random();
    //        byte[] salt = new byte[len];
    //
    //     //   r.nextBytes(salt);
    //    // 33  --- 127   0 ---  94
    //     byte []asciiT = new byte[]{1,2,3};
    //
    //     for(int i=0;i<salt.length;i++){
    //         salt[i] = (byte) (r.nextInt(94)+33);   // generator 33<= n <127
    //     }
    //        return new String(salt);
    //    }
    private String generateRandomKey(int len) {

        return "";
    }

    public static void main(String[] aa) {
        Random r = new Random();
        byte[] salt = new byte[1000];
        for (int i = 0; i < salt.length; i++) {
            salt[i] = (byte) (r.nextInt(94) + 33);
        }
        System.out.print(new String(salt));
    }

    /**
     * 加密byte数组
     *
     * @param key  String
     * @param data byte[]
     * @return byte[]
     */
    public byte[] cryptoDES(byte[] data) {
        if (data == null) {
            return null;
        }
        String key = generateRandomKey(8);

        char[] passwd = (char[]) key.toCharArray();

        PBEKeySpec pbks = new PBEKeySpec(passwd);
        try {
            //获取加密key
            SecretKeyFactory kf = SecretKeyFactory
                    .getInstance("PBEWithMD5AndDES");
            SecretKey k = kf.generateSecret(pbks);
            //产生一个随机盐，为了使相同的密码，每个产生不同的加密串
            byte[] salt = new byte[8];
            Random r = new Random();
            r.nextBytes(salt);
            Cipher cp = null;
            //取加密算法
            cp = Cipher.getInstance("PBEWithMD5AndDES");
            PBEParameterSpec ps = new PBEParameterSpec(salt, 1000);
            cp.init(Cipher.ENCRYPT_MODE, k, ps);
            byte[] ctext = null;
            //加密
            ctext = cp.doFinal(data);
            //将随机盐放入加字串中保存，解密需要此随机盐
            byte[] cdata = new byte[salt.length + ctext.length
                    + key.getBytes().length];
            System.arraycopy(salt, 0, cdata, 0, salt.length);
            System.arraycopy(ctext, 0, cdata, salt.length, ctext.length);
            System.arraycopy(key.getBytes(), 0, cdata, salt.length
                    + ctext.length, key.getBytes().length);
            return cdata;
        } catch (NoSuchPaddingException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (NoSuchAlgorithmException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (InvalidKeySpecException ex1) {
            ex1.printStackTrace();
            return null;
        } catch (InvalidAlgorithmParameterException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (InvalidKeyException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (BadPaddingException ex) {
            ex.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException ex) {
            ex.printStackTrace();
            return null;
        } catch (IllegalStateException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * 解密byte数组
     *
     * @param key  String
     * @param data byte[]
     * @return byte[]
     */
    public byte[] deCryptoDES(byte[] data) {
        //参数不正确，返回null
        if (data == null) {
            return null;
        }
        byte[] keys = new byte[8];
        System.arraycopy(data, data.length - keys.length, keys, 0, keys.length);
        String key = new String(keys);

        char[] passwd = key.toCharArray();
        PBEKeySpec pbks = new PBEKeySpec(passwd);
        try {
            //取解密key
            SecretKeyFactory kf = SecretKeyFactory
                    .getInstance("PBEWithMD5AndDES");
            SecretKey k = null;
            k = kf.generateSecret(pbks);
            //从加密串中取随机盐
            byte[] salt = new byte[8];
            byte[] cdata = new byte[data.length - salt.length - keys.length];
            System.arraycopy(data, 0, salt, 0, salt.length);
            System.arraycopy(data, salt.length, cdata, 0, cdata.length);
            //取解密算法
            Cipher cp = null;
            cp = Cipher.getInstance("PBEWithMD5AndDES");
            PBEParameterSpec ps = new PBEParameterSpec(salt, 1000);
            cp.init(Cipher.DECRYPT_MODE, k, ps);
            byte[] ddata = null;
            //解密
            ddata = cp.doFinal(cdata);
            return ddata;
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
            return null;
        } catch (InvalidKeySpecException ex1) {
            ex1.printStackTrace();
            return null;
        } catch (NoSuchPaddingException ex2) {
            ex2.printStackTrace();
            return null;
        } catch (InvalidAlgorithmParameterException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (InvalidKeyException ex3) {
            ex3.printStackTrace();
            return null;
        } catch (BadPaddingException ex4) {
            ex4.printStackTrace();
            return null;
        } catch (IllegalBlockSizeException ex4) {
            ex4.printStackTrace();
            return null;
        } catch (IllegalStateException ex4) {
            ex4.printStackTrace();
            return null;
        }
    }

}
