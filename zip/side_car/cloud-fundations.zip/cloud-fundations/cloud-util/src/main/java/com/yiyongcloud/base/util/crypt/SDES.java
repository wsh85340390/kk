package com.yiyongcloud.base.util.crypt;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;


/**
 * Created by IntelliJ IDEA.
 * <p>
 * Date: 2006-6-15
 * Time: 19:10:02
 * To change this template use File | Settings | File Templates.
 * SDES加密，加密后的串会经过base64编码
 *
 * @author liaowufeng
 */
public class SDES implements Crypto {

    private Map<Integer, String> cryptMap = new HashMap<Integer, String>();//syskey 集合,key 为sid,value 为syskey
    private Integer[] sids; // sid 集合
    private SyskeyCollector collector;
    private final boolean ENCRYPT = true; // 加密
    private final boolean DECRYPT = false; // 解密

    /**
     * 使用3DES对字符串数据加解密
     *
     * @param in   String
     * @param key  String
     * @param type boolean
     * @return String
     */
    @Override
    public String desgo(String in, String key, boolean type) {
        if (in == null || "".equals(in.trim())) {
            return "";
        }
        String dest = null;
        if (ENCRYPT == type) {
            if (cryptMap.isEmpty() && collector != null) {
                setCryptMap(collector.collectSyskey());
            }
            if (!cryptMap.isEmpty()) {
                dest = encode(in, type);
                if (dest != null) {
                    return dest;
                }
            }
            SDES2 sdes2 = new SDES2();
            //加密
            String src = sdes2.desgo(in, key, ENCRYPT);
            // base64 编码
            byte[] sorData = null;

            try {
                sorData = src.getBytes("ISO-8859-1");
                dest = Base64.getEncoder().encodeToString(sorData);
                dest = dest.replaceAll("\r\n", ""); // base64 以76字符后加自动增加\r\n符
            } catch (UnsupportedEncodingException ex1) {
                ex1.printStackTrace();
                dest = null;
            }
        } else if (DECRYPT == type) {
            if (cryptMap.isEmpty()) {
                setCryptMap(collector.collectSyskey());
            }
            if (!cryptMap.isEmpty()) {
                dest = decode(in, type);
                if (dest != null) {
                    return dest;
                }
            }
            // 解密
            SDES2 sdes2 = new SDES2();
            in = in.replaceAll("\r\n", ""); // base64 以76字符后加自动增加\r\n符
            // base64 解码
            byte[] b = null;
            try {
                b = Base64.getDecoder().decode(in);
                String src = new String(b, "ISO-8859-1");
                int index = src.indexOf("_iam");
                if (index != -1) {
                    String sid = src.substring(0, index);
                    if (sid.matches("[0-9]+")) {
                        src = src.substring(index + 4);
                        dest = sdes2.desgo(src, key, DECRYPT);
                    }
                } else {
                    dest = sdes2.desgo(src, key, DECRYPT);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                dest = null;
            }
        }
        if (dest == null) {
            dest = "";
        }
        return dest;
    }

    /**
     * 利用syskey集合进行加密
     *
     * @param in
     * @param type
     * @return
     */
    public String encode(String in, boolean type) {
        String dest = null;
        try {
            SDES2 sdes2 = new SDES2();
            int id = sids[sids.length - 1];
            String syskey = cryptMap.get(id);
            String src = sdes2.desgo(in, syskey, ENCRYPT);
            src = String.valueOf(id) + "_iam" + src;
            // base64 编码
            byte[] sorData = null;
            try {
                sorData = src.getBytes("ISO-8859-1");
                dest = Base64.getEncoder().encodeToString(sorData);
                dest = dest.replaceAll("\r\n", ""); // base64 以76字符后加自动增加\r\n符
            } catch (UnsupportedEncodingException ex1) {
                ex1.printStackTrace();
                dest = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            dest = null;
        }
        return dest;
    }

    /**
     * 利用syskey集合进行解密
     *
     * @param in
     * @param type
     * @return
     */
    public String decode(String in, boolean type) {
        String dest = null;
        try {
            SDES2 sdes2 = new SDES2();
            in = in.replaceAll("\r\n", ""); // base64 以76字符后加自动增加\r\n符
            byte[] b = null;
            String syskey = "";
            try {
                b = Base64.getDecoder().decode(in);
                String src = new String(b, "ISO-8859-1");
                int index = src.indexOf("_iam");
                if (index != -1) {
                    String sid = src.substring(0, index);
                    if (sid.matches("[0-9]+")) {
                        int id = Integer.valueOf(sid);
                        src = src.substring(index + 4);
                        if (id > sids[sids.length - 1] && collector != null) {
                            Map<Integer, String> syskeyMap = collector
                                    .collectSyskey();
                            setCryptMap(syskeyMap);
                        }
                        syskey = cryptMap.get(id);
                        if (syskey == null) {
                            return null;
                        }
                        dest = sdes2.desgo(src, syskey, DECRYPT);
                        return dest;
                    }
                }
                syskey = cryptMap.get(sids[0]);
                //				log.info("syskey is orginal key!");
                dest = sdes2.desgo(src, syskey, DECRYPT);
            } catch (IOException ex) {
                ex.printStackTrace();
                dest = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            dest = null;
        }
        return dest;

    }

    /**
     * 初始化syskey集合,collector收集器
     *
     * @param inMap
     * @param collector
     */
    @Override
    public void init(Map<Integer, String> inMap, SyskeyCollector collector) {
        setCryptMap(inMap);
        setCollector(collector);
    }

    /**
     * 设置syskey集合
     *
     * @param inMap
     */
    private synchronized void setCryptMap(Map<Integer, String> inMap) {
        if (inMap == null || inMap.isEmpty()) {
            return;
        }
        Set<Integer> set = inMap.keySet();
        for (Integer sid : set) {
            if (!cryptMap.containsKey(sid)) {
                String syskey = inMap.get(sid);
                syskey = syskey.replaceAll("\r\n", "");
                byte[] sorData = null;
                String dest = null;
                try {
                    sorData = Base64.getDecoder().decode(syskey);
                    dest = new String(sorData, "ISO-8859-1");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cryptMap.put(sid, dest);
            }
        }
        set = cryptMap.keySet();
        Integer[] ids = new Integer[set.size()];
        Arrays.sort(set.toArray(ids));
        setSids(ids);

    }

    /**
     * 设置sid集合
     *
     * @param sids
     */
    private synchronized void setSids(Integer[] sids) {
        this.sids = sids;
    }

    /**
     * 设置collector收集器
     *
     * @param collector
     */
    private synchronized void setCollector(SyskeyCollector collector) {
        if (collector == null) {
            return;
        }
        this.collector = collector;
    }


}