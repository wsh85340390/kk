package com.yiyongcloud.base.sidecar.recognp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.core.env.Environment;

@SpringBootApplication
@EnableDiscoveryClient
public class StartRecognizeSideCar {

    private static Logger logger = LoggerFactory.getLogger(StartRecognizeSideCar.class);

    private static Environment env;

    @Autowired
    public void setEnv(Environment env) {
        StartRecognizeSideCar.env = env;
    }

    public static void main(String[] args) {
        SpringApplication.run(StartRecognizeSideCar.class, args);
        logger.info(String.format("application %s started on port %s", env.getProperty("spring.application.name"), env.getProperty("server.port")));
    }

}
