package com.yiyongcloud.base.client.psidecar.fallback;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yiyongcloud.base.client.account.pojo.OrgInfoEntity;
import com.yiyongcloud.base.client.account.pojo.UserBaseInfoExtendEntity;
import com.yiyongcloud.base.client.account.pojo.UserSmartPojo;
import com.yiyongcloud.base.client.psidecar.IRecognPmodeClient;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

/**
 * Description: 用户基本信息客户端<br>
 * Create Date: 2018/11/5<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br>
 * Copyright (C)   All Right Reserved.<br>
 *
 * @author LiuJianli
 * @version 1.0
 */
@Component
public class RecognPmodeClientFallback implements FallbackFactory<IRecognPmodeClient> {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public IRecognPmodeClient create(Throwable arg0) {
        logger.error(arg0.getMessage());
        return new IRecognPmodeClient() {


            @Override
            public Map<String,String>  sidecarTmp(String userloginname) {
                return Maps.newHashMap();
            }

            @Override
            public Map<String,String>  sidecarJson(JSONObject json) {
                return Maps.newHashMap();
            }
        };
    }

}
