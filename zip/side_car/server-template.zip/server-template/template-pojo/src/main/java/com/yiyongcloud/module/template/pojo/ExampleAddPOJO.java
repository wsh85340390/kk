package com.yiyongcloud.module.template.pojo;

import java.io.Serializable;

import lombok.Data;

/**
 * @author   
 * @date 2022/2/08
 */
@Data
public class ExampleAddPOJO implements Serializable {

    private String name;
}
