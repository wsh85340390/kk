package com.yiyongcloud.module.template.pojo;

import java.io.Serializable;

import lombok.Data;

/**
 * @author   
 * @date 2022/2/08
 */
@Data
public class PlusResultPOJO implements Serializable {

    private Long a;
    private Long b;
    private Long result;

    public PlusResultPOJO(long a, long b, long rst) {
        this.a = a;
        this.b = b;
        this.result = rst;
    }
}
