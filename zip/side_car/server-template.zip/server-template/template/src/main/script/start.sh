#!/bin/bash

PWD=$(
  cd $(dirname $0)
  pwd
)
start() {
  # Check if it is already running
  echo "--- {jarName} is starting...$(date) "
  pid=$(ps -ef | grep java | grep {jarName}.jar | awk '{print $2}')
  if [ ! -z "${pid}" ]; then
    echo "--- {jarName} has started already, pid is ${pid}"
    return 1
  fi
  nohup java -jar {jvm} $PWD/lib/{jarName}.jar --spring.config.location=$PWD/conf/bootstrap.properties >/dev/null 2>&1 &
  echo "--- {jarName}  start end..."
  return 0
}

stop() {
  echo -n $"--- The {jarName} is stoping... "
  pid=$(ps -ef | grep java | grep {jarName}.jar | awk '{print $2}')
  if [ ! -z "${pid}" ]; then
    kill -9 $pid
    echo " [ OK ]"
    return 0
  else
    echo " [ FAILED ], {jarName} has stopped already"
    return 0
  fi
}

status() {
  pid=$(ps -ef | grep java | grep {jarName}.jar | awk '{print $2}')
  if [ ! -z "${pid}" ]; then
    echo "--- {jarName} is runnig, pid is ${pid}"
  else
    echo "--- {jarName} is stopped"
  fi
  return 0
}

restart() {
  stop
  start
}

log() {
  status
  if [ ! -z "${pid}" ]; then
    log=$(lsof -p $pid | grep "logs/.*[0-9]*\.log" | awk '{print $NF}')
    tail -f $log
  fi
}

case "$1" in
start)
  start
  ;;
stop)
  stop
  ;;
restart)
  restart
  ;;
status)
  status
  ;;
log)
  log
  ;;
*)
  echo $"Usage: $0 {start|stop|status|restart|log}"
  exit 1
  ;;
esac

exit 0
