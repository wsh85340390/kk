package com.yiyongcloud.module.template;

import com.yiyongcloud.base.common.config.I18NTools;
import com.yiyongcloud.base.common.config.SentinelNacosDatasourceBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.alibaba.cloud.sentinel.custom.SentinelAutoConfiguration;

import lombok.extern.slf4j.Slf4j;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 服务启动入口类
 *
 * @author   
 * @date 2022/2/08
 */
@SpringBootApplication(scanBasePackages = {
        "com.yiyongcloud.base.common",
        "com.yiyongcloud.module.template"}
        , exclude = {SentinelAutoConfiguration.class})

@ComponentScan(value = {
        "com.yiyongcloud.base.common",
        "com.yiyongcloud.module.template"},
        excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
                classes = {SentinelNacosDatasourceBean.class}))
@EnableFeignClients // 开启feign做远程调用
@EnableDiscoveryClient // 开启服务注册与发现
@EnableTransactionManagement
@MapperScan("com.yiyongcloud.module.template.mapper")
@EnableSwagger2
@EnableAsync
@Slf4j
public class TemplateApplication {
    public static void main(String[] args) {
        SpringApplication.run(TemplateApplication.class, args);
        log.info(I18NTools.getMessage("application_started_msg"));
    }
}
