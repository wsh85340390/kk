package com.yiyongcloud.module.template.controller;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.yiyongcloud.base.common.pojo.ResponseResult;
import com.yiyongcloud.base.common.utils.json.JsonTools;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Description: 当产品 各组件调用其他外部系统的接口时，调用此接口记录 外部接口的日志<br>
 * Create Date: 2018年7月31日<br>
 * Modified By：<br>
 * Modified Date：<br>
 * Why & What is modified：<br> 
 * Copyright (C) 2018 1yongcloud.com All Right Reserved.<br>
 * @author Tangwenwu
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping(value = "/apilog")
public class ApiLogController {




	/**
	 * Description: 根据旧token换取新token<br> 
	 * Created date: 2018年7月31日
	 * @param apiAccessLog
	 * @return
	 * @author Tangwenwu
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseResult addApiLog(@RequestBody JSONObject apiAccessLog){


		log.info(apiAccessLog.toJSONString());


		ResponseResult responseResult = new ResponseResult();
		responseResult.ofSuccess(apiAccessLog,"响应正常");
		return responseResult;
    }


	@RequestMapping(value = "/sidecar_tmp/{token}", method = {RequestMethod.POST,RequestMethod.GET})
	public Map<String,String> testSidecar(@PathVariable("token") String userName){
		Map<String,String> statMap = Maps.newHashMap();
		statMap.put("result","hello,test sidecar::::"+userName);
		return statMap;
	}

	/**
	 * Description: 根据旧token换取新token<br>
	 * Created date: 2018年7月31日
	 * @return
	 * @author Tangwenwu
	 */
	@RequestMapping(value = "/sidecar", method = {RequestMethod.POST,RequestMethod.GET})
	public Map<String,String> sidecar(){
		Map<String,String> statMap = Maps.newHashMap();
		statMap.put("status","UP");
		statMap.put("userName","tangwenwu");
		return statMap;
	}


	/**
	 * Description: 根据旧token换取新token<br>
	 * Created date: 2018年7月31日
	 * @return
	 * @author Tangwenwu
	 */
	@RequestMapping(value = "/health", method = {RequestMethod.POST,RequestMethod.GET})
	public Map<String,String> health(){
		Map<String,String> statMap = Maps.newHashMap();
		statMap.put("status","UP");
		return statMap;
	}
}
