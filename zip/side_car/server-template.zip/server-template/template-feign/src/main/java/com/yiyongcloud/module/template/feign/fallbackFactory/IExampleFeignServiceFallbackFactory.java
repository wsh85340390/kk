/**   
* @Title: IExampleFeignServiceFallbackFactory.java 
* @Package com.yiyongcloud.module.template.feign.fallbackFactory
* @Description: TODO
* @author tangwenwu
* @date 2022年2月10日 下午2:31:24
* @version V1.0   
*/
package com.yiyongcloud.module.template.feign.fallbackFactory;

import com.yiyongcloud.module.template.feign.feignServiceFallback.IExampleFeignServiceFallback;
import org.springframework.stereotype.Component;

import com.yiyongcloud.module.template.feign.IExampleFeignService;

import feign.hystrix.FallbackFactory;


@Component
public class IExampleFeignServiceFallbackFactory implements FallbackFactory<IExampleFeignService>{
	 @Override
	    public IExampleFeignServiceFallback create(Throwable throwable) {
	        return new IExampleFeignServiceFallback(throwable);
	    }
}
