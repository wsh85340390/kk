/**   
* @Title: IExampleFeignServiceFallback.java 
* @Package com.yiyongcloud.module.template.feign.feignServiceFallback
* @Description: TODO
* @author tangwenwu
* @date 2022年2月10日 下午2:33:24
* @version V1.0   
*/
package com.yiyongcloud.module.template.feign.feignServiceFallback;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;

import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeException;
import com.yiyongcloud.module.template.feign.IExampleFeignService;
import com.yiyongcloud.module.template.pojo.ExampleAddPOJO;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author tangwenwu
 *
 */
@Slf4j
public class IExampleFeignServiceFallback implements IExampleFeignService{
	private Throwable throwable;

    public IExampleFeignServiceFallback(Throwable throwable) {
        this.throwable = throwable;
    }


    /**
     * @param addForm
     * @return
     */
    @Override
    public boolean feignCreate(@Valid ExampleAddPOJO addForm) {
        if (throwable instanceof FeignException) {
            FeignException fe = (FeignException) throwable;
            if (fe.status() == HttpStatus.TOO_MANY_REQUESTS.value()) {
                log.error("远端服务被限流，请稍后再试！");
            } else if (fe.status() == HttpStatus.SERVICE_UNAVAILABLE.value()) {
                log.error("远端服务被熔断，服务不可用，请稍后再试！");
            }
            log.warn("deduct处理", throwable);
        } else if (throwable instanceof DegradeException) {//熔断异常特殊处理
            log.error("客户端主动熔断远端create接口，服务不可用，请稍后再试！");
        } else if (throwable instanceof BlockException) {
            log.error("客户端主动限流远端create接口务，请稍后再试！");
        }
        throw new IllegalStateException(throwable);//包装异常并抛出
    }
}
