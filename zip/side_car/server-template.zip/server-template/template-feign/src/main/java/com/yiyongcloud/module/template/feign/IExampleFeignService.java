package com.yiyongcloud.module.template.feign;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yiyongcloud.module.template.pojo.ExampleAddPOJO;

/**
 * @author   
 * @date 2022/2/08
 */
@FeignClient("consumer")
@RequestMapping("/storage")
public interface IExampleFeignService {


    /**
     * @param addForm
     * @return
     */
    @RequestMapping(value = "feign/create", method = {RequestMethod.POST})
    boolean feignCreate(@Valid @RequestBody ExampleAddPOJO addForm);


}


