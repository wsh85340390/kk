package com.yiyongcloud.module.template.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;

/**
 * 例子，enetiy字段必须和表一一对应。关联查询可以使用dto类返回，entity是严格的单表返回
 *
 * @author   
 * @date 2022/2/08
 */

@Data
@TableName("t_example")
public class TExampleEntity implements Serializable {

    private Long id;

    private String name;

    public static class Field{
        public static final String name = "name";
    }
}
