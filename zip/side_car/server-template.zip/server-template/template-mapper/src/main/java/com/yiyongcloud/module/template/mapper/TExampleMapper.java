package com.yiyongcloud.module.template.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yiyongcloud.module.template.entity.TExampleEntity;

/**
 * mapper继承basemapper获得基础sql能力
 *
 * @author   
 * @date 2022/2/08
 */
public interface TExampleMapper extends BaseMapper<TExampleEntity> {
}
